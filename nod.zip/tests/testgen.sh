#!/bin/bash

# Compute gcd
gcd() {
    local a=$1 b=$2
    while [ $b -ne 0 ]; do
        local t=$b
        b=$(( a % b ))
        a=$t
    done
    echo $a
}

# Generate non-coprime numbers <= max_val (not just multiples)
gen_non_coprime() {
    local max_val=$1
    local a b d candidates

    while true; do
        # pick a random common factor <= max_val/2 or max_val if small
        local max_d=$(( max_val/2 > 1 ? max_val/2 : 2 ))
        d=$(shuf -i 2-$max_d -n 1)

        # make array of multiples of d
        candidates=()
        for ((i=1;i<=max_val;i++)); do
            if (( i % d == 0 )); then
                candidates+=($i)
            fi
        done

        # need at least two candidates
        if [ ${#candidates[@]} -lt 2 ]; then
            continue
        fi

        # pick two independent numbers
        idx1=$(shuf -i 0-$((${#candidates[@]}-1)) -n 1)
        idx2=$(shuf -i 0-$((${#candidates[@]}-1)) -n 1)
        a=${candidates[$idx1]}
        b=${candidates[$idx2]}

        # avoid duplicates for tiny ranges
        if [ $max_val -le 7 ] && [ $a -eq $b ]; then
            continue
        fi

        # sanity check
        if [ $(gcd $a $b) -gt 1 ]; then
            echo "$a $b"
            return
        fi
    done
}

# Generate coprime numbers <= max_val
gen_coprime() {
    local max_val=$1
    local a b
    while true; do
        a=$(shuf -i 1-$max_val -n 1)
        b=$(shuf -i 1-$max_val -n 1)
        if [ $(gcd $a $b) -eq 1 ]; then
            echo "$a $b"
            return
        fi
    done
}

# Select ~7 random coprime files from 2..69
coprime_files=( $(shuf -i 2-69 -n 7) )

# 1.in: "1 <random up to 1e5>"
echo "1 $(shuf -i 1-100000 -n 1)" > 1.in
: > 1.out

# Loop through 2..69
for i in {2..69}; do
    
    : > "$i.out"
done
# the second subtasks tests are manually modified