#include "cheshma.h"
void solve(int n) {
	
}
