#include "cheshma.h"
void solve(int n) {
	for (int i = 1; i <= n*n*n*n; i++) {open();}
	setCountry("russia");
	drink(n);
}
