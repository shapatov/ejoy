#include "cheshma.h"
void solve(int n) {
	open();
	store(n);
	drinkCup(n);
}
