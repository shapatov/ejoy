#include "cheshma.h"
void solve(int n) {
	open();
	drink(n);
}
// okaza se che tova e za 50
