#include "cheshma.h"
void solve(int n) {
	open();
	setCountry("russia");
	store(n);
	drinkCup(n);
}
// realno tva e za 50
