#include "cheshma.h"
void solve(int n) {
	open();
	setCountry("russia");
	drink(n);
}
