#include "cheshma.h"
#include <iostream>
using namespace std;
int sum=0;
int chasha=0;
int s=0;
bool dali=false;
bool russia=false;
void drink(int m) {
if(m<0) return;
  if(dali)  {sum+=m;
  s+=m;}
    ;
   }
void drinkCup(int m) {
if(m<0) return;
    s+=m;
    sum+=min(chasha,m);
    chasha-=min(chasha,m);
 }
 void store(int m) {
 if(m<0) return;
     chasha+=m;
     s+=m;

 }
 void pay() {
    cout<<1/0<<endl;
 }
 void open() {
     dali=true;
    }
  void close() {
      dali=false;
}
void setCountry(string s) {
    if(s=="bulgaria") {
          cout<<"0 Water in Bulgaria is not clean!"<<endl;
          exit(0);
    }
    if(s=="russia") {
          russia=true;
    }

   }
int main() {
    int n;
    cin>>n;
    solve(n);
    if(n==0) {
        if(sum==0) {cout<<"1"<<endl;
        }
        else cout << "0" << endl;
    }
    if(n==17) {
          if(n==sum && russia && s <= n) {
               cout<<"1"<<endl;
          }
          else {
            cout<<"0"<<endl;
          }
    }
    if(n==11786) {
           if(sum==n && s<=2*n) {
            cout<<"1"<<endl;
           }
           else{
                if(sum==n) while(1);
               cout<<"0"<<endl;
           }
    }
    if(n==6769) {
          if(sum==n && s<=n) {
               cout<<"1"<<endl;
          }
          else {
          if(sum==n) while(1);
             cout<<"0"<<endl;
          }
    }
    if(n==82745) {
          if(sum==n && russia==true  && s<=2*n) {
               cout<<"1"<<endl;
          }
          else {
          if(sum==n) while(1);
                 cout<<"0"<<endl;
          }
    }
    if(n==100000) {
           if(sum==n && russia==true  && s<=n) {
               cout<<"1"<<endl;
          }
          else {
          if(sum==n) while(1);
                 cout<<"0"<<endl;
          }
    }

   }



