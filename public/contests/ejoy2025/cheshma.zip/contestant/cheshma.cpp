#include "cheshma.h"
void solve(int n) {
	open();
	drink(n);
}
