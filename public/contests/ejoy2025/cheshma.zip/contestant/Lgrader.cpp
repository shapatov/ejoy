/// ako otvorish tozi graider si gej kojto ne znae za ruskite buferi
/// :)

#include<bits/stdc++.h>
#include "cheshma.h"
#include "cheshma.cpp"
using namespace std;
int sum=0;
int chasha=0;
int s=0;
bool dali=false;
bool russia=false;
void drink(int m) {
if(m<0) return;
  if(dali)  {sum+=m;
  s+=m;}
    ;
   }
void drinkCup(int m) {
if(m<0) return;
    s+=m;
    sum+=min(chasha,m);
    chasha-=min(chasha,m);
 }
 void store(int m) {
 if(m<0) return;
     chasha+=m;
     s+=m;

 }
 void pay() {
    cout << "RE";
    exit(0);
 }
 void open() {
     dali=true;
    }
  void close() {
      dali=false;
}
void setCountry(string s) {
    if(s=="bulgaria") {
          cout<<"0 Water in Bulgaria is not clean!"<<endl;
          exit(0);
    }
    if(s=="russia") {
          russia=true;
    }

   }


int main() {
    cout << "Enter N:";
    int n;
    cin>>n;
    solve(n);
    if(n==0) {
        if(sum==0) cout << "OK" << endl;
        else cout << "WA" << endl;
    }
    if(n==17) {
          if(n==sum) {
               cout<<"OK"<<endl;
          }
          else {
            cout<<"WA"<<endl;
          }
    }
    if(n==11786) {
           if(sum==n && s<=2*n) {
            cout<<"OK"<<endl;
           }
           else {
               cout<<(sum==n?"TL":"WA")<<endl;
           }
    }
    if(n==6769) {
          if(sum==n && s<=n) {
               cout<<"OK"<<endl;
          }
          else {
             cout<<(sum==n?"TL":"WA")<<endl;
          }
    }
    if(n==82745) {
          if(russia==true  && s<=2*n) {
               cout<<"OK"<<endl;
          }
          else {
                 cout<<(sum==n?"TL":"WA")<<endl;
          }
    }
    if(n==100000) {
           if(russia==true  && s<=n) {
               cout<<"OK"<<endl;
          }
          else {
                 cout<<(sum==n?"TL":"WA")<<endl;
          }
    }

   }

