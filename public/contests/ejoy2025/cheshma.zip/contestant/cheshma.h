#include <iostream>

void pay();
void drink(int m);
void drinkCup(int m);
void setCountry(std::string s);
void open();
void close();
void store(int m);
void solve(int n);
