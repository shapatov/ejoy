#include <iostream>
#include "tree.h"
using namespace std;
namespace grader {
    static const string password = "f2e222336a24c66c1dd6a5b374c43637ebaf946ad6c68627505aaf4eb9d89046";
}
using namespace grader;
int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    
    int type; cin >> type;
    if(type==0) {
        int n; cin >> n;
        vector<pair<int,int>> v;
        for(int i = 0; i < n-1; i++) {
            int a,b; cin >> a >> b;
            v.push_back({a, b});
        }
        string ans=encode(n, v);
        for(int i = 0; i < ans.size(); i++) {
            if(ans[i]!='0' && ans[i]!='1') {
                cout << password << endl << -1 << endl;
                cout << flush;
                exit(0);
            }
        }
        cout << password << endl << ans << endl;
        cout << flush;
    }
    else {
        int n; cin >> n;
        string v; cin >> v;
        vector<pair<int,int>> ans=decode(n, v);
        cout << password << endl;
        if(ans.size()!=n-1) {
            cout << "-1 -1" << endl;
            cout << flush;
            return 0;
        }
        for(auto &x : ans) cout << x.first << " " << x.second << endl;
        cout << endl;
        cout << flush;
    }
}