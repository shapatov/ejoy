#pragma once
#include <iostream>
#include <vector>

std::string encode(int, std::vector<std::pair<int, int>>);
std::vector<std::pair<int, int>> decode(int, std::string);