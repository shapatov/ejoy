#include <iostream>
#include "tree.h"
using namespace std;

int main() {
    int n; cin >> n;
    vector<pair<int,int>> v, ans2;
    for(int i = 0; i < n-1; i++) {
        int a,b; cin >> a >> b;
        v.push_back({a, b});
    }
    string ans = encode(n, v);
    cout << "Encoded: " << ans << endl;
    cout << "Decoded: " << endl;
    ans2=decode(n, ans);
    for(auto &x : ans2) {
        cout << x.first << ' ' << x.second << endl;
    }
}