#!/bin/bash

task="tree"
stack_size=268435456  # 256 GB

ulimit -s "${stack_size}"
"./${task}"

