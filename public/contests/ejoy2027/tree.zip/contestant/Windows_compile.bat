@echo off
set "task=tree"

g++ -Wl,--stack,268435456 -std=gnu++17 -Wall -O2 -pipe -static -g -o "%task%.exe" Lgrader.cpp "%task%.cpp"
if errorlevel 1 (
    echo.
    echo Compilation failed. Press any key to continue...
    pause >nul
)

