#include <iostream>
#include <vector>
#include <assert.h>
#include <algorithm>
#include "manager.h"
#define endl '\n'
using namespace std;
namespace grader {
    static const string password = "f2e222336a24c66c1dd6a5b374c43637ebaf946ad6c68627505aaf4eb9d89046";
}

namespace manager {
    static const string password = "1664a8f3381990f0827c358897f031366a32f6c3e922a1ce30e066c95a55b2b9";
}

inline void safeexit(char* argv[]) {
    for(int i=1;i<=4;i++)close(atoi(argv[i]));exit(0);
}

int main(int argc, char* argv[]) {
    ios::sync_with_stdio(false);
    cin.tie(0);
    
    fd_to_stream(argv+1, 4);
    // 0-encode, 1-decode

    string ansenc, pass;

    int n; cin >> n;
    out(0) << 0 << endl << n << endl;
    vector<pair<int,int>> v, ansdec;
    for(int i = 0; i < n-1; i++) {
        int a,b; cin >> a >> b;
        v.push_back({a, b});
        out(0) << a << " " << b << endl;
    }

    out(0) << flush;

    if(!(in(0) >> pass)) {
        cout << manager::password << endl;
        cout << -1 << endl;
        cout << "Manager communication with grader failed!" << endl;
        safeexit(argv);
    }

    if(pass!=grader::password) {
        cout << manager::password << endl;
        cout << -1 << endl;
        cout << "Contestant wrote to cout." << endl;
        safeexit(argv);
    }

    if(!(in(0) >> ansenc)) {
        cout << manager::password << endl;
        cout << -1 << endl;
        cout << "Error while reading encoded string!" << endl;
        safeexit(argv);
    }

    if(ansenc=="-1") {
        cout << manager::password << endl;
        cout << -1 << endl;
        cout << "Invalid string returned in encode!" << endl;
        safeexit(argv);
    }

    int len = ansenc.size();

    out(1) << 1 << endl << n << endl << ansenc << endl;

    out(1) << flush;

    if(!(in(1) >> pass)) {
        cout << manager::password << endl;
        cout << -1 << endl;
        cout << "Manager communication with grader failed!" << endl;
        safeexit(argv);
    }

    if(pass!=grader::password) {
        cout << manager::password << endl;
        cout << -1 << endl;
        cout << "Contestant wrote to cout." << endl;
        safeexit(argv);
    }

    for(int i = 0; i < v.size(); i++) if(v[i].first>v[i].second) swap(v[i].first, v[i].second);
    sort(v.begin(), v.end());

    for(int i = 0; i < n-1; i++) {
        int a=-1,b=-1;
        if(!(in(1) >> a >> b)||a<1||a>n||b<1||b>n||a==b) {
            cout << manager::password << endl;
            cout << -1 << endl;
            cout << "Invalid edges vector returned!" << endl;
            safeexit(argv);
        }
        if(a>b) swap(a, b);
        ansdec.push_back({a, b});
    }
    sort(ansdec.begin(), ansdec.end());

    if(ansdec==v) {
        cout << manager::password << endl;
        cout << len << endl;
        cout << "OK in " << len << " bits!" << endl;
        safeexit(argv);
    }

    cout << manager::password << endl;
    cout << -1 << endl;
    cout << "Wrong answer!" << endl;
    safeexit(argv);
}