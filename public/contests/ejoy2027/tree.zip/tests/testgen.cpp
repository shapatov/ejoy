#include <iostream>
#include <random>
#include <fstream>
#include <algorithm>
using namespace std;
mt19937 mt(random_device{}());
int main() {
    for(int t = 1; t <= 10; t++) {
        int n = mt()%(100000-1)+2;
        ofstream in("test."+string(t<=9?"0":"")+to_string(t)+".in");
        ofstream out("test."+string(t<=9?"0":"")+to_string(t)+".out");
        in << n << endl;
        vector<pair<int,int>> tree;
        for(int i = 2; i <= n; i++) {
            int p=mt()%(i-1)+1;
            if(mt()%2) tree.push_back({i, p});
            else tree.push_back({p, i});
        }
        shuffle(tree.begin(), tree.end(), mt);
        for(auto &x : tree) in << x.first << " " << x.second << endl;
        in.close();
        out.close();
    }
}