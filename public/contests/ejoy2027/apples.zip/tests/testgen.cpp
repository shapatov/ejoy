#include <iostream>
#include <fstream>
#include <random>
#include <time.h>
#include <assert.h>
#include <limits.h>
using namespace std;
int main() {
    mt19937_64 mt(random_device{}());
    
    // subtask 1
    for(int i = 1; i <= 5; i++) {
        ofstream in("apples." + (string)(i<10?"0":"") + to_string(i) + ".in");
        ofstream out("apples." + (string)(i<10?"0":"") + to_string(i) + ".out");
        unsigned long long a,b;
        do {
            a = mt();
            b = mt() & ~a;
        } while (a > ULLONG_MAX - b);

        in << a << endl << b;
        out << a+b;
        in.close();
        out.close();
    }
    
    // subtask 2
    for(int i = 6; i <= 25; i++) {
        ofstream in("apples." + (string)(i<10?"0":"") + to_string(i) + ".in");
        ofstream out("apples." + (string)(i<10?"0":"") + to_string(i) + ".out");
        unsigned long long a = mt();
        unsigned long long b = mt() % (ULLONG_MAX - a + 1);
        in << a << endl << b;
        out << a+b;
        in.close();
        out.close();
    }
}