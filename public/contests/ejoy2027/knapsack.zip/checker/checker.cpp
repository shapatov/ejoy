#include <bits/stdc++.h>
using namespace std;
using ll = long long;

struct Sol { ll val = -1, sw = 0, sv = 0, cnt = 0; bool ok = false; };

static Sol readSol(const char *path, int n, ll W, const vector<ll> &w, const vector<ll> &v){
    Sol s;
    FILE *f = fopen(path, "r");
    if(!f){ fprintf(stderr, "Cannot open %s\n", path); return s; }
    if(fscanf(f, "%lld", &s.val) != 1){ fprintf(stderr, "%s: No value\n", path); fclose(f); return s; }
    vector<char> seen(n, 0);
    ll id;
    while(fscanf(f, "%lld", &id) == 1){
        if(id < 1 || id > n){ fprintf(stderr, "%s: Index %lld out of range\n", path, id); fclose(f); return s; }
        if(seen[id - 1]){ fprintf(stderr, "%s: Duplicate index %lld\n", path, id); fclose(f); return s; }
        seen[id - 1] = 1;
        s.sw += w[id - 1]; s.sv += v[id - 1]; s.cnt++;
    }
    fclose(f);
    if(s.sw > W){ fprintf(stderr, "%s: Overweight, %lld > %lld\n", path, s.sw, W); return s; }
    if(s.sv != s.val){ fprintf(stderr, "%s: Claimed %lld, actual %lld\n", path, s.val, s.sv); return s; }
    s.ok = true;
    return s;
}

int main(int argc, char **argv){
    const int ARG_ANSWER = 2, ARG_OUTPUT = 3;
    if(argc < 4){ fprintf(stderr, "Usage: %s <input> <answer> <output>\n", argv[0]); return 2; }
    FILE *fi = fopen(argv[1], "r");
    if(!fi){ fprintf(stderr, "Cannot open input\n"); return 2; }
    int n; ll W;
    if(fscanf(fi, "%d %lld", &n, &W) != 2){ fprintf(stderr, "Bad input\n"); return 2; }
    vector<ll> w(n), v(n);
    for(int i = 0; i < n; i++)
        if(fscanf(fi, "%lld %lld", &w[i], &v[i]) != 2){ fprintf(stderr, "Bad input\n"); return 2; }
    fclose(fi);

    Sol auth = readSol(argv[ARG_ANSWER], n, W, w, v);
    if(!auth.ok || auth.sv <= 0){ fprintf(stderr, "Author answer invalid\n"); return 2; }
    Sol out = readSol(argv[ARG_OUTPUT], n, W, w, v);
    if(!out.ok){ printf("0.000000\n"); return 0; }

    long long gap = auth.sv - out.sv; if(gap < 0) gap = 0;
    long double base = 1.0L - log1pl((long double)gap) / log1pl((long double)(auth.sv));
    if(base < 0) base = 0;
    long double score = powl(base, 3.0L);            // exponent = ceil(e)
    printf("%.6Lf\n", score);
    //fprintf(stderr, "V=%lld author=%lld gap=%lld\n", out.sv, auth.sv, gap);
    return 0;
}