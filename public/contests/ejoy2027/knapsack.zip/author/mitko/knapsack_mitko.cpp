#pragma GCC optimize("Ofast")
#pragma GCC target("avx2")

#include <iostream>
#include <cstring>
#include <random>
#include <ctime>
#include <fstream>
#include <stack>
#include <algorithm>
#include <unordered_set>
#include <set>
#include <unordered_map>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;

long long a[100005];
long long b[100005];
pair<double, int> c[100005];
bool used[100005];

template<class T>
using ordered_set = __gnu_pbds::tree<T, __gnu_pbds::null_type, less<T>, __gnu_pbds::rb_tree_tag, __gnu_pbds::tree_order_statistics_node_update>;
mt19937 mt(random_device{}());

long long dp[3000000];
vector<bool> back[3000000];

void solve() {    
    int n;
    long long w;
    cin >> n >> w;
    for(int i = 1; i <= n; i++) {
        cin >> a[i] >> b[i]; // weight, val
        used[i]=0;
        back[i].clear();
        if((long long)n*w<=500000000) back[i].resize(w+5);
        c[i]={(long double)a[i]/(long double)b[i], i};
    }
    
    if((long long)n*w<=500000000) {
        memset(dp, 0, sizeof(dp));
        for(int i = 1; i <= n; i++) {
            for(int j = w; j >= a[i]; j--) {
                if(dp[j-a[i]]+b[i]>dp[j]) {
                    dp[j]=dp[j-a[i]]+b[i];
                    back[i][j]=1;
                }
            }
        }
        int mx=0;
        for(int i = 1; i <= w; i++) if(dp[i]>dp[mx]) mx=i;
        cout << dp[mx] << endl;
        for(int i = n; i >= 1; i--) {
            if(back[i][mx]) {cout << i << " "; mx-=a[i];}
        }
        cout<<endl;
        return;
    }

    sort(c+1, c+1+n);
    long long ans=0, currW=0;
    ordered_set<int> take, notake;
    for(int i = 1; i <= n; i++) {
        if(currW+a[c[i].second]<=w) {
            ans+=b[c[i].second];
            currW += a[c[i].second];
            used[c[i].second]=1;
            take.insert(c[i].second);
        }
        else notake.insert(c[i].second);
    }
    for(long long iter = 0; iter < 1000000000; iter++) {
        if(iter%3==0 && !(take.empty() || notake.size()<2)) {
            // delim edin na dva
            int a = *take.find_by_order(mt()%take.size());
            int b1 = *notake.find_by_order(mt()%notake.size());
            int b2 = *notake.find_by_order(mt()%notake.size());
            while(b1==b2) b2 = *notake.find_by_order(mt()%notake.size());
            int br=0;
            while(currW-::a[a]+::a[b1]+::a[b2]>w && br<20) {
                b1 = *notake.find_by_order(mt()%notake.size());
                b2 = *notake.find_by_order(mt()%notake.size());
                while(b1==b2) b2 = *notake.find_by_order(mt()%notake.size());
                br++;
            }
            if(br==20) continue;
            if(ans-b[a]+b[b1]+b[b2]>ans) {
                ans=ans-b[a]+b[b1]+b[b2];
                take.erase(a);
                notake.erase(b1);
                notake.erase(b2);
                take.insert(b1);
                take.insert(b2);
                notake.insert(a);
                used[a]=0;
                used[b1]=1;
                used[b2]=1;
                currW=currW-::a[a]+::a[b1]+::a[b2];
            }
        }
        else if(iter%3==1 && !(notake.empty() || take.size()<2)) {
            // delim dva na edin
            int a = *notake.find_by_order(mt()%notake.size());
            int b1 = *take.find_by_order(mt()%take.size());
            int b2 = *take.find_by_order(mt()%take.size());
            while(b1==b2) b2 = *take.find_by_order(mt()%take.size());
            int br = 0;
            while(currW+::a[a]-::a[b1]-::a[b2]>w && br<20) {
                b1 = *take.find_by_order(mt()%take.size());
                b2 = *take.find_by_order(mt()%take.size());
                while(b1==b2) b2 = *take.find_by_order(mt()%take.size());
                br++;
            }
            if(br==20) continue;
            if(ans+b[a]-b[b1]-b[b2]>ans) {
                ans=ans+b[a]-b[b1]-b[b2];
                notake.erase(a);
                take.erase(b1);
                take.erase(b2);
                notake.insert(b1);
                notake.insert(b2);
                take.insert(a);
                used[a]=1;
                used[b1]=0;
                used[b2]=0;
                currW=currW+::a[a]-::a[b1]-::a[b2];
            }
        }
        else if(!(notake.empty() || take.empty())) {
            // edin s edin
            int a = *notake.find_by_order(mt()%notake.size());
            int b = *take.find_by_order(mt()%take.size());
            int br = 0;
            while(currW+::a[a]-::a[b]>w && br<20) {
                a = *notake.find_by_order(mt()%notake.size());
                b = *take.find_by_order(mt()%take.size());
                br++;
            }
            if(br==20) continue;
            if(ans+::b[a]-::b[b]>ans) {
                ans=ans+::b[a]-::b[b];
                notake.erase(a);
                take.erase(b);
                notake.insert(b);
                take.insert(a);
                used[b]=0;
                used[a]=1;
                currW=currW+::a[a]-::a[b];
            }
        }
    }
    cout << ans << endl;
    vector<int> z;
    for(int i = 1; i <= n; i++) if(used[i]) z.push_back(i);
    for(auto &x : z) cout << x << " ";
    cout << endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    for(int test = 1; test <= 10; test++) {
        string s = (test<10?"0":"") + to_string(test);
        freopen(("test."+s+".in").c_str(), "r", stdin);
        freopen(("test."+s+".out").c_str(), "w", stdout);
        int t=1; while(t--) solve();
    }
}