#include<bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;
using namespace __gnu_pbds;
typedef tree<int, null_type, less<int>, rb_tree_tag, tree_order_statistics_node_update> ordered_set;
mt19937 mt(random_device{}());
const int maxn=1e5+7;
pair<long long int, long long int>c[maxn];
void solve() {
    long long int n,w;
    cin>>n>>w;
    ordered_set s;
    ordered_set left;
    for(int i=1; i<=n; i++) {
        long long int a,b;
        cin>>a>>b;
        c[i]={a,b};
    }


    vector<int> order(n);
    iota(order.begin(), order.end(), 1);
    sort(order.begin(), order.end(), [](int x, int y){

        return c[x].second * c[y].first > c[y].second * c[x].first;
    });

    long long int currw=0;
    long long int currp=0;
    for(int idx : order) {
        if (currw + c[idx].first <= w) {
            s.insert(idx);
            currw += c[idx].first;
            currp += c[idx].second;
        } else {
            left.insert(idx);
        }
    }


    for(int i = 1; i <= n*500; i++) {
        if (left.empty()) break;
        uniform_int_distribution<int> dist_left(0, left.size() - 1);
        int ind = dist_left(mt);
        int k = *left.find_by_order(ind);
        pair<long long int, long long int> curr = c[k];
        if (currw + curr.first <= w) {
            s.insert(k);
            left.erase(k);
            currw += curr.first;
            currp += curr.second;
        }
      else if (!s.empty()) {
    long long needed = curr.first - (w - currw);
    if (needed <= currw) {
        long long freed = 0;
        vector<int> to_remove;
        while (freed < needed && !s.empty()) {
            uniform_int_distribution<int> dist_s(0, s.size() - 1);
            int k2 = *s.find_by_order(dist_s(mt));
            freed += c[k2].first;
            s.erase(k2);
            to_remove.push_back(k2);
        }
        long long removed_p = 0;
        for (int k2 : to_remove) removed_p += c[k2].second;
        if (curr.second > removed_p) {
            s.insert(k);
            left.erase(k);
            currw = currw - freed + curr.first;
            currp = currp - removed_p + curr.second;
            for (int k2 : to_remove) left.insert(k2);
        } else {
            for (int k2 : to_remove) {
                s.insert(k2);
            }
        }
    }
}
    }
    cout << currp << "\n";
    for(auto x : s) {
        cout << x << "\n";
    }
}
int main() {
    for(int test = 1; test <= 10; test++) {
        string s = (test<10?"0":"") + to_string(test);
        freopen(("test."+s+".in").c_str(), "r", stdin);
        freopen(("test."+s+".out").c_str(), "w", stdout);
        solve();
    }
}