// author.cpp — author solution for "Раница"
//
// Usage:  ./author [time_limit_seconds=120] [--greedy] [seed]
//   --greedy  = plain ratio greedy only (baseline for measuring gaps)
//
// Output: line 1 = best total value found, line 2 = chosen item indices (1-based).
//
// Pipeline:
//   n <= 24                          -> exact branch & bound (LP bound)
//   W <= 4e5 and n*W small           -> exact O(nW) DP with bitset reconstruction
//   otherwise:
//     greedy portfolio (ratio / value / weight / randomized-ratio restarts)
//     candidate pool (top ratio + lightest + random)
//     scaled-capacity core DP (weights rounded UP -> always feasible)
//     simulated annealing with swap/add/remove moves + periodic kicks,
//     restarting from the incumbent until the time limit.

#include <bits/stdc++.h>
#include "assert.h"
using namespace std;
using ll = long long;

static int n; static ll W;
static vector<ll> w, v; static vector<double> rat;

static chrono::steady_clock::time_point START;
static double TL = 120.0;
static double el(){ return chrono::duration<double>(chrono::steady_clock::now() - START).count(); }

static mt19937_64 rng(88172645463325252ULL);
static ll RI(ll a, ll b){ return uniform_int_distribution<ll>(a, b)(rng); }
static double RD(){ return uniform_real_distribution<double>(0.0, 1.0)(rng); }
static double RN(){ static normal_distribution<double> N(0, 1); return N(rng); }

static ll bestV = -1; static vector<char> bestIn;
static bool NODP = false, WEAK = false, HILL = false, MULTI = false, KHC = false, GRIND = false;

static void commitIn(const vector<char> &in, ll val){
    if(val > bestV){ bestV = val; bestIn = in; }
}

static ll runOrder(const vector<int> &ord, vector<char> &in){
    in.assign(n, 0); ll cw = 0, cv = 0;
    for(int id : ord) if(w[id] <= W - cw){ in[id] = 1; cw += w[id]; cv += v[id]; }
    return cv;
}

/* ---------- exact: branch & bound (small n) ---------- */
static vector<int> bbOrd; static vector<char> bbCur, bbBest; static ll bbVal;
static ll bbNodes;
static void bbDfs(size_t i, ll cw, ll cv){
    if(++bbNodes > 300000000LL) return;        // budget: fall through to heuristics
    if(cv > bbVal){ bbVal = cv; bbBest = bbCur; }
    if(i == bbOrd.size()) return;
    ll cap = W - cw; long double ub = cv;
    for(size_t j = i; j < bbOrd.size() && cap > 0; j++){
        int id = bbOrd[j];
        if(w[id] <= cap){ cap -= w[id]; ub += v[id]; }
        else { ub += (long double)v[id] * cap / w[id]; cap = 0; }
    }
    if(ub <= (long double)bbVal) return;
    int id = bbOrd[i];
    if(w[id] <= W - cw){ bbCur[id] = 1; bbDfs(i + 1, cw + w[id], cv + v[id]); bbCur[id] = 0; }
    bbDfs(i + 1, cw, cv);
}
static void solveBB(){
    bbOrd.clear();
    for(int i = 0; i < n; i++) if(w[i] <= W) bbOrd.push_back(i);
    sort(bbOrd.begin(), bbOrd.end(), [](int a, int b){
        return (long double)v[a] * w[b] > (long double)v[b] * w[a]; });
    bbCur.assign(n, 0); bbBest = bbCur; bbVal = 0; bbNodes = 0;
    bbDfs(0, 0, 0);
    commitIn(bbBest, bbVal);
}

/* ---------- exact: weight DP with bitset reconstruction ---------- */
static bool solveDP(){
    if(W > 400000) return false;
    if((long double)n * (W + 1) > 2.0e9) return false;
    size_t words = (size_t)(W >> 6) + 1;
    if((long double)n * words * 8.0 > 1.2e9) return false;
    vector<ll> dp(W + 1, 0);
    vector<uint64_t> bit((size_t)n * words, 0ULL);
    for(int i = 0; i < n; i++){
        if(w[i] > W) continue;
        uint64_t *row = &bit[(size_t)i * words];
        ll wi = w[i], vi = v[i];
        for(ll c = W; c >= wi; c--){
            ll cand = dp[c - wi] + vi;
            if(cand > dp[c]){ dp[c] = cand; row[c >> 6] |= 1ULL << (c & 63); }
        }
    }
    ll bc = 0; for(ll c = 1; c <= W; c++) if(dp[c] > dp[bc]) bc = c;
    vector<char> in(n, 0); ll c = bc;
    for(int i = n - 1; i >= 0; i--){
        if(w[i] > W) continue;
        const uint64_t *row = &bit[(size_t)i * words];
        if((row[c >> 6] >> (c & 63)) & 1){ in[i] = 1; c -= w[i]; }
    }
    commitIn(in, dp[bc]);
    return true;
}

/* ---------- candidate pool ---------- */
static vector<int> poolByR, poolByW; static vector<ll> poolW;
static void buildPool(){
    vector<int> idx; idx.reserve(n);
    for(int i = 0; i < n; i++) if(w[i] <= W) idx.push_back(i);
    vector<int> byr = idx;
    sort(byr.begin(), byr.end(), [](int a, int b){ return rat[a] > rat[b]; });
    vector<char> take(n, 0);
    for(size_t i = 0; i < min(byr.size(), (size_t)20000); i++) take[byr[i]] = 1;
    vector<int> byw = idx;
    sort(byw.begin(), byw.end(), [](int a, int b){ return w[a] < w[b]; });
    for(size_t i = 0; i < min(byw.size(), (size_t)6000); i++) take[byw[i]] = 1;
    for(int t = 0; t < 3000 && !idx.empty(); t++) take[idx[RI(0, (ll)idx.size() - 1)]] = 1;
    poolByR.clear();
    for(int id : byr) if(take[id]) poolByR.push_back(id);
    poolByW = poolByR;
    sort(poolByW.begin(), poolByW.end(), [](int a, int b){ return w[a] < w[b]; });
    poolW.resize(poolByW.size());
    for(size_t i = 0; i < poolByW.size(); i++) poolW[i] = w[poolByW[i]];
}

static int pickFit(ll cap, const vector<char> &in){
    size_t c = upper_bound(poolW.begin(), poolW.end(), cap) - poolW.begin();
    if(!c) return -1;
    for(int t = 0; t < 24; t++){
        int id = poolByW[RI(0, (ll)c - 1)];
        if(!in[id]) return id;
    }
    return -1;
}

static void fillGreedy(vector<char> &in, ll &cw, ll &cv){
    for(int id : poolByR) if(!in[id] && w[id] <= W - cw){ in[id] = 1; cw += w[id]; cv += v[id]; }
}

/* ---------- greedy portfolio ---------- */
static void greedyPortfolio(double budget){
    vector<int> ord; ord.reserve(n);
    for(int i = 0; i < n; i++) if(w[i] <= W) ord.push_back(i);
    if(ord.empty()){ commitIn(vector<char>(n, 0), 0); return; }
    vector<char> in;
    sort(ord.begin(), ord.end(), [](int a, int b){ return rat[a] > rat[b]; });
    commitIn(in, runOrder(ord, in));
    auto o2 = ord; sort(o2.begin(), o2.end(), [](int a, int b){ return v[a] > v[b]; });
    commitIn(in, runOrder(o2, in));
    auto o3 = ord; sort(o3.begin(), o3.end(), [](int a, int b){ return w[a] < w[b]; });
    commitIn(in, runOrder(o3, in));
    double stop = el() + budget;
    vector<double> key(n);
    vector<int> o = ord; int round = 0;
    static const double SIG[3] = {0.02, 0.05, 0.12};
    while(el() < stop){
        double s = SIG[round++ % 3];
        for(int id : o) key[id] = log(rat[id]) + s * RN();
        sort(o.begin(), o.end(), [&](int a, int b){ return key[a] > key[b]; });
        commitIn(in, runOrder(o, in));
    }
}

/* ---------- scaled-capacity core DP (round weights UP -> feasible) ---------- */
static void scaledDP(int Pcap, ll M){
    if(poolByR.empty()) return;
    vector<int> L;
    {
        vector<char> t(n, 0);
        for(size_t i = 0; i < poolByR.size() && (int)L.size() < Pcap; i++){
            L.push_back(poolByR[i]); t[poolByR[i]] = 1;
        }
        int extra = 0;
        for(size_t i = 0; i < poolByW.size() && extra < 600; i++){
            int id = poolByW[i];
            if(!t[id]){ L.push_back(id); t[id] = 1; extra++; }
        }
    }
    int P = L.size();
    size_t words = (size_t)(M >> 6) + 1;
    if((long double)P * words * 8.0 > 8e8) return;
    vector<ll> dp(M + 1, 0);
    vector<uint64_t> bit((size_t)P * words, 0ULL);
    vector<ll> sw_(P);
    for(int i = 0; i < P; i++){
        ll wi = (ll)(((__int128)w[L[i]] * M + W - 1) / W);   // ceil
        sw_[i] = max(1LL, wi);
    }
    for(int i = 0; i < P; i++){
        ll wi = sw_[i]; if(wi > M) continue;
        ll vi = v[L[i]];
        uint64_t *row = &bit[(size_t)i * words];
        for(ll c = M; c >= wi; c--){
            ll cand = dp[c - wi] + vi;
            if(cand > dp[c]){ dp[c] = cand; row[c >> 6] |= 1ULL << (c & 63); }
        }
    }
    ll bc = 0; for(ll c = 1; c <= M; c++) if(dp[c] > dp[bc]) bc = c;
    vector<char> in(n, 0); ll c = bc, cw = 0, cv = 0;
    for(int i = P - 1; i >= 0; i--){
        if(sw_[i] > M) continue;
        const uint64_t *row = &bit[(size_t)i * words];
        if((row[c >> 6] >> (c & 63)) & 1){ in[L[i]] = 1; c -= sw_[i]; cw += w[L[i]]; cv += v[L[i]]; }
    }
    assert(cw <= W);
    fillGreedy(in, cw, cv);   // top up slack from rounding with real weights
    commitIn(in, cv);
}

/* ---------- simulated annealing ---------- */
struct SAState {
    vector<char> in; vector<int> chosen; ll cw = 0, cv = 0;
    void addI(int id){ in[id] = 1; chosen.push_back(id); cw += w[id]; cv += v[id]; }
    void remK(int k){ int id = chosen[k]; in[id] = 0; cw -= w[id]; cv -= v[id];
                      chosen[k] = chosen.back(); chosen.pop_back(); }
};

static int pickFitBest2(ll cap, const vector<char> &in){   // ratio-biased add
    int a = pickFit(cap, in), b = pickFit(cap, in);
    if(a < 0) return b;
    if(b < 0) return a;
    return rat[a] >= rat[b] ? a : b;
}

static void saRun(double tEnd){
    SAState S; S.in = bestIn; if((int)S.in.size() != n) S.in.assign(n, 0);
    for(int i = 0; i < n; i++) if(S.in[i]){ S.chosen.push_back(i); S.cw += w[i]; S.cv += v[i]; }
    if(!S.chosen.empty() && !GRIND){           // perturb ~12% of the incumbent
        int rm = max<int>(1, S.chosen.size() / 8);
        for(int t = 0; t < rm && !S.chosen.empty(); t++) S.remK(RI(0, (ll)S.chosen.size() - 1));
    }
    fillGreedy(S.in, S.cw, S.cv);
    commitIn(S.in, S.cv);
    double t0 = el(), dur = max(0.5, tEnd - t0);
    double avgv = S.chosen.empty() ? 1e6 : (double)S.cv / S.chosen.size();
    double Thi = GRIND ? 1.0 : max(1.0, 0.08 * avgv);
    double Tlo = GRIND ? 0.005 : 0.02;
    double T = Thi;
    ll it = 0;
    while(true){
        if((it & 2047) == 0){
            double e = el(); if(e >= tEnd) break;
            double f = min(1.0, (e - t0) / dur);
            T = Thi * pow(Tlo / Thi, f);
        }
        it++;
        if(!WEAK && (it & ((1 << 18) - 1)) == 0){ // kick: drop a couple, refill
            int rm = (int)min<ll>((ll)S.chosen.size(), 1 + RI(0, 2));
            for(int t2 = 0; t2 < rm; t2++) S.remK(RI(0, (ll)S.chosen.size() - 1));
            fillGreedy(S.in, S.cw, S.cv);
            if(S.cv > bestV) commitIn(S.in, S.cv);
            continue;
        }
        double r = RD();
        if(r < 0.40){                          // swap 1-out / 1-in
            if(S.chosen.empty()) continue;
            int k = RI(0, (ll)S.chosen.size() - 1); int out = S.chosen[k];
            int inc = pickFit(W - S.cw + w[out], S.in);
            if(inc < 0) continue;
            ll d = v[inc] - v[out];
            if(d >= 0 || RD() < exp((double)d / T)){
                S.remK(k); S.addI(inc);
                if(S.cv > bestV) commitIn(S.in, S.cv);
            }
        } else if(r < 0.54){                   // swap 1-out / 2-in
            if(WEAK || S.chosen.empty()) continue;
            int k = RI(0, (ll)S.chosen.size() - 1); int out = S.chosen[k];
            ll cap = W - S.cw + w[out];
            int i1 = pickFit(cap, S.in); if(i1 < 0) continue;
            S.in[i1] = 1;
            int i2 = pickFit(cap - w[i1], S.in);
            S.in[i1] = 0;
            if(i2 < 0) continue;
            ll d = v[i1] + v[i2] - v[out];
            if(d >= 0 || RD() < exp((double)d / T)){
                S.remK(k); S.addI(i1); S.addI(i2);
                if(S.cv > bestV) commitIn(S.in, S.cv);
            }
        } else if(r < 0.64){                   // swap 2-out / 1-in
            if(WEAK || S.chosen.size() < 2) continue;
            int k1 = RI(0, (ll)S.chosen.size() - 1), k2 = RI(0, (ll)S.chosen.size() - 1);
            if(k1 == k2) continue;
            int o1 = S.chosen[k1], o2 = S.chosen[k2];
            int inc = pickFit(W - S.cw + w[o1] + w[o2], S.in);
            if(inc < 0) continue;
            ll d = v[inc] - v[o1] - v[o2];
            if(d >= 0 || RD() < exp((double)d / T)){
                if(k1 < k2) swap(k1, k2);
                S.remK(k1); S.remK(k2); S.addI(inc);
                if(S.cv > bestV) commitIn(S.in, S.cv);
            }
        } else if(r < 0.84){                   // add (ratio-biased)
            int inc = WEAK ? pickFit(W - S.cw, S.in) : pickFitBest2(W - S.cw, S.in);
            if(inc < 0) continue;
            S.addI(inc);
            if(S.cv > bestV) commitIn(S.in, S.cv);
        } else {                               // remove (metropolis)
            if(S.chosen.empty()) continue;
            int k = RI(0, (ll)S.chosen.size() - 1);
            if(RD() < exp(-(double)v[S.chosen[k]] / T)) S.remK(k);
        }
    }
}

/* targeted polish: exact best 1-1 upgrades + slack top-off via weight binary search */
static void polish(double tEnd){
    if((int)bestIn.size() != n) return;
    vector<char> in = bestIn; vector<int> chosen; ll cw = 0, cv = 0;
    for(int i = 0; i < n; i++) if(in[i]){ chosen.push_back(i); cw += w[i]; cv += v[i]; }
    bool improved = true;
    while(improved && el() < tEnd){
        improved = false;
        // pure adds: repeatedly take the heaviest fitting unchosen item
        while(true){
            ll slack = W - cw;
            size_t idx = upper_bound(poolW.begin(), poolW.end(), slack) - poolW.begin();
            int add = -1;
            for(size_t j = idx; j-- > 0 && j + 64 >= idx; )
                if(!in[poolByW[j]]){ add = poolByW[j]; break; }
            if(add < 0) break;
            in[add] = 1; chosen.push_back(add); cw += w[add]; cv += v[add];
            improved = true;
        }
        // best 1-1 upgrade per chosen item via weight window scan
        for(size_t ci = 0; ci < chosen.size() && el() < tEnd; ci++){
            int c = chosen[ci]; ll cap = w[c] + (W - cw);
            size_t idx = upper_bound(poolW.begin(), poolW.end(), cap) - poolW.begin();
            int bestId = -1; ll bestv = v[c];
            for(size_t j = idx; j-- > 0 && j + 96 >= idx; ){
                int id = poolByW[j];
                if(!in[id] && v[id] > bestv){ bestv = v[id]; bestId = id; }
            }
            if(bestId >= 0){
                in[c] = 0; in[bestId] = 1;
                cw += w[bestId] - w[c]; cv += v[bestId] - v[c];
                chosen[ci] = bestId; improved = true;
            }
        }
    }
    commitIn(in, cv);
}


/* uniform improving-exchange grinder (1->2, 2->1, 1<->1), Mitko-style but
   seeded from the incumbent; collects rounding pennies relentlessly */
static void grindUniform(double tEnd, bool fromGreedy = false){
    vector<char> in;
    if(fromGreedy){
        vector<int> ord;
        for(int i = 0; i < n; i++) if(w[i] <= W) ord.push_back(i);
        sort(ord.begin(), ord.end(), [](int a, int b){ return rat[a] > rat[b]; });
        commitIn(in, runOrder(ord, in));
    } else {
        if((int)bestIn.size() != n) return;
        in = bestIn;
    }
    vector<int> take, rest; vector<int> pos(n);
    ll cw = 0, cv = 0;
    for(int i = 0; i < n; i++){
        if(in[i]){ pos[i] = take.size(); take.push_back(i); cw += w[i]; cv += v[i]; }
        else if(w[i] <= W){ pos[i] = rest.size(); rest.push_back(i); }
        else pos[i] = -1;
    }
    auto moveTo = [&](int id, vector<int>&from, vector<int>&to){
        int p = pos[id]; int last = from.back();
        from[p] = last; pos[last] = p; from.pop_back();
        pos[id] = to.size(); to.push_back(id);
    };
    ll it = 0;
    while(true){
        if((it++ & 4095) == 0 && el() >= tEnd) break;
        int m = it % 3;
        if(m == 0 && take.size() >= 1 && rest.size() >= 2){
            int x = take[RI(0,(ll)take.size()-1)];
            int b1 = -1, b2 = -1;
            for(int r = 0; r < 6; r++){
                b1 = rest[RI(0,(ll)rest.size()-1)]; b2 = rest[RI(0,(ll)rest.size()-1)];
                if(b1 != b2 && cw - w[x] + w[b1] + w[b2] <= W) break;
                b1 = -1;
            }
            if(b1 < 0) continue;
            if(v[b1] + v[b2] >= v[x] && !(v[b1]+v[b2]==v[x])){
                cv += v[b1]+v[b2]-v[x]; cw += w[b1]+w[b2]-w[x];
                in[x]=0; in[b1]=1; in[b2]=1;
                moveTo(x, take, rest); moveTo(b1, rest, take); moveTo(b2, rest, take);
                if(cv > bestV) commitIn(in, cv);
            }
        } else if(m == 1 && take.size() >= 2 && rest.size() >= 1){
            int x = -1, b1 = -1, b2 = -1;
            for(int r = 0; r < 6; r++){
                x = rest[RI(0,(ll)rest.size()-1)];
                b1 = take[RI(0,(ll)take.size()-1)]; b2 = take[RI(0,(ll)take.size()-1)];
                if(b1 != b2 && cw + w[x] - w[b1] - w[b2] <= W) break;
                x = -1;
            }
            if(x < 0) continue;
            if(v[x] > v[b1] + v[b2]){
                cv += v[x]-v[b1]-v[b2]; cw += w[x]-w[b1]-w[b2];
                in[x]=1; in[b1]=0; in[b2]=0;
                moveTo(x, rest, take); moveTo(b1, take, rest); moveTo(b2, take, rest);
                if(cv > bestV) commitIn(in, cv);
            }
        } else if(take.size() >= 1 && rest.size() >= 1){
            int x = -1, y = -1;
            for(int r = 0; r < 6; r++){
                x = rest[RI(0,(ll)rest.size()-1)]; y = take[RI(0,(ll)take.size()-1)];
                if(cw + w[x] - w[y] <= W) break;
                x = -1;
            }
            if(x < 0) continue;
            if(v[x] > v[y]){
                cv += v[x]-v[y]; cw += w[x]-w[y];
                in[x]=1; in[y]=0;
                moveTo(x, rest, take); moveTo(y, take, rest);
                if(cv > bestV) commitIn(in, cv);
            }
        }
    }
    commitIn(in, cv);
}

static void output(){
    printf("%lld\n", max(0LL, bestV));
    bool first = true;
    for(int i = 0; i < n; i++)
        if((int)bestIn.size() == n && bestIn[i]){ printf(first ? "%d" : " %d", i + 1); first = false; }
    printf("\n");
}

int main(int argc, char **argv){
    START = chrono::steady_clock::now();
    bool greedyOnly = false;
    if(argc > 1) TL = atof(argv[1]);
    for(int i = 2; i < argc; i++){
        string s = argv[i];
        if(s == "--greedy") greedyOnly = true;
        else if(s == "--nodp") NODP = true;
        else if(s == "--hill") HILL = true;
        else if(s == "--multi") MULTI = true;
        else if(s == "--khc") KHC = true;
        else if(s == "--grindonly") { NODP = true; GRIND = true; }
        else if(s == "--weak"){ NODP = true; WEAK = true; }
        else rng.seed(strtoull(s.c_str(), nullptr, 10));
    }
    if(scanf("%d %lld", &n, &W) != 2) return 1;
    w.resize(n); v.resize(n); rat.resize(n);
    for(int i = 0; i < n; i++){
        if(scanf("%lld %lld", &w[i], &v[i]) != 2) return 1;
        rat[i] = (double)v[i] / (double)w[i];
    }
    if(greedyOnly){                            // baseline: plain ratio greedy
        vector<int> ord;
        for(int i = 0; i < n; i++) if(w[i] <= W) ord.push_back(i);
        sort(ord.begin(), ord.end(), [](int a, int b){ return rat[a] > rat[b]; });
        vector<char> in; commitIn(in, runOrder(ord, in));
        output(); return 0;
    }
    if(n <= 44){
        solveBB();
        if(bbNodes <= 300000000LL){ output(); return 0; }
    }
    if(solveDP()){ output(); return 0; }
    if(HILL){                              // plain greedy start + 1-1 polish only
        vector<int> ord;
        for(int i = 0; i < n; i++) if(w[i] <= W) ord.push_back(i);
        sort(ord.begin(), ord.end(), [](int a, int b){ return rat[a] > rat[b]; });
        vector<char> in; commitIn(in, runOrder(ord, in));
        buildPool();
        polish(TL - 0.1);
        output(); return 0;
    }
    if(GRIND){                             // grind-from-greedy diagnostic
        vector<int> ord;
        for(int i = 0; i < n; i++) if(w[i] <= W) ord.push_back(i);
        sort(ord.begin(), ord.end(), [](int a, int b){ return rat[a] > rat[b]; });
        vector<char> in; commitIn(in, runOrder(ord, in));
        buildPool();
        grindUniform(TL - 0.2);
        output(); return 0;
    }
    if(KHC){                               // greedy + improving-only kicks
        vector<int> ord;
        for(int i = 0; i < n; i++) if(w[i] <= W) ord.push_back(i);
        sort(ord.begin(), ord.end(), [](int a, int b){ return rat[a] > rat[b]; });
        vector<char> in; ll val = runOrder(ord, in);
        commitIn(in, val);
        buildPool();
        vector<int> chosen; ll cw = 0, cv = 0;
        for(int i = 0; i < n; i++) if(in[i]){ chosen.push_back(i); cw += w[i]; cv += v[i]; }
        while(el() < TL - 0.2){
            vector<char> in2 = in; vector<int> ch2 = chosen; ll cw2 = cw, cv2 = cv;
            int rm = (int)min<ll>((ll)ch2.size(), 1 + RI(0, 3));
            for(int t2 = 0; t2 < rm && !ch2.empty(); t2++){
                int k = RI(0, (ll)ch2.size() - 1); int id = ch2[k];
                in2[id] = 0; cw2 -= w[id]; cv2 -= v[id];
                ch2[k] = ch2.back(); ch2.pop_back();
            }
            for(int id : poolByR){             // randomized greedy repair
                if(in2[id] || w[id] > W - cw2) continue;
                if(RD() < 0.30) continue;      // skip ~30% -> samples new combos
                in2[id] = 1; cw2 += w[id]; cv2 += v[id];
            }
            fillGreedy(in2, cw2, cv2);         // top off what the skips left
            if(cv2 > cv){                      // improving-only: else discard
                in = in2; chosen = ch2; cw = cw2; cv = cv2;
                for(int i = 0; i < n; i++);    // (state already synced)
                chosen.clear();
                for(int i = 0; i < n; i++) if(in[i]) chosen.push_back(i);
                commitIn(in, cv);
            }
        }
        output(); return 0;
    }
    if(MULTI){                             // randomized greedy restarts + 1-1 polish
        buildPool();
        greedyPortfolio(TL * 0.85);
        polish(TL - 0.1);
        output(); return 0;
    }
    greedyPortfolio(min(2.0, TL * 0.04));
    buildPool();
    ll M   = TL < 20 ? 60000 : (TL < 80 ? 120000 : 160000);
    int Pc = TL < 20 ? 2200 : 3200;
    if(!NODP && W < (ll)2e10) scaledDP(Pc, M);      // DP useless past its granularity
    double fineAt = TL * 0.45;                 // second, finer core DP mid-run
    bool fineDone = !(TL >= 60) || NODP || W >= (ll)2e10;
    double grindAt = TL * 0.45;                // back half: frozen improving grind
    while(el() < TL - 1.2){
        if(!fineDone && el() >= fineAt){ scaledDP(3600, 300000); fineDone = true; continue; }
        if(el() >= grindAt && !WEAK) GRIND = true;
        double dur = GRIND ? 4.0 : min(10.0, max(3.0, (TL - el()) / 4));
        if(dur <= 0.2) break;
        if(GRIND){ grindUniform(TL - 0.6, true); polish(TL - 0.15); break; }
        saRun(min(TL - 1.0, el() + dur));
    }
    polish(TL - 0.1);
    output();
    return 0;
}