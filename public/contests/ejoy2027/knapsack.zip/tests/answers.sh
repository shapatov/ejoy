#!/usr/bin/env bash
# Compiles everything, generates all tests, produces and verifies author answers.
# Answer file: line 1 = author value, line 2 = chosen indices (1-based).
set -e
g++ -Ofast -o gen gen.cpp
g++ -Ofast -o author author.cpp
g++ -Ofast -o verify verify.cpp
g++ -Ofast -o check check.cpp
./gen
for i in $(seq -w 1 10); do
  t=150; [ "$i" = "01" ] && t=5; [ "$i" = "02" ] && t=30
  ./author $t < test.$i.in > "test.$i.out"
  echo -n "test $i: "
  ./verify test.$i.in "test.$i.out"
done
rm author check gen verify