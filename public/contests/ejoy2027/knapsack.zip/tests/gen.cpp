#include <bits/stdc++.h>
#include <functional>
#include <assert.h>
using namespace std;
using ll = long long;

mt19937_64 rng;
ll R(ll a, ll b){ return uniform_int_distribution<ll>(a, b)(rng); }
double Rd(double a, double b){ return uniform_real_distribution<double>(a, b)(rng); }

struct Item { ll w, v; };
const ll VMAX = 1000000000LL;
const ll WMAXI = 1000000000LL;   // per-item weight cap (statement)

ll cv(double x){ return max(1LL, min(VMAX, (ll)llround(x))); }

void emit(int t, ll W, vector<Item> its){
    assert((ll)its.size() >= 1 && (ll)its.size() <= 100000);
    assert(W >= 1 && W <= 1000000000000LL);
    for(auto &e : its){
        assert(1 <= e.w && e.w <= WMAXI);
        assert(1 <= e.v && e.v <= VMAX);
    }
    shuffle(its.begin(), its.end(), rng);
    char nm[32]; snprintf(nm, 32, "test.%02d.in", t);
    FILE *f = fopen(nm, "w");
    fprintf(f, "%d %lld\n", (int)its.size(), W);
    for(auto &e : its) fprintf(f, "%lld %lld\n", e.w, e.v);
    fclose(f);
    long double sw = 0; for(auto &e : its) sw += e.w;
    fprintf(stderr, "[%02d] n=%-6d W=%-13lld sumW/W=%.1Lf\n", t, (int)its.size(), W, sw / W);
}

int main(){
    // 01 — brute force
    rng.seed(101);
    {
        vector<Item> its; ll sw = 0;
        for(int i = 0; i < 18; i++){
            ll wt = R(20000, 900000);
            its.push_back({wt, R(10000, 1000000)});
            sw += wt;
        }
        emit(1, (ll)(sw * 0.35), its);
    }
    // 02 — standard knapsack DP
    rng.seed(102);
    {
        vector<Item> its;
        for(int i = 0; i < 2000; i++)
            its.push_back({R(1, 1000), R(1, 1000000)});
        emit(2, 150000, its);
    }
    // 03..10 — heuristic
    // 03 — n=40: exactly solvable by meet-in-the-middle, heuristics get partials
    rng.seed(133);
    {
        vector<Item> its; ll sw = 0;
        for(int i = 0; i < 40; i++){
            ll wt = R(100000000, 1000000000);
            its.push_back({wt, R(100000000, 1000000000)});
            sw += wt;
        }
        emit(3, (ll)(sw * 0.4), its);
    }
    // 04..10 — grind variants: v ~ rho*w*(1+noise), each test targets a
    // different technique via its noise recipe:
    //   mul   — multiplicative jitter: ratio-aware search beats uniform exchange
    //   gems  — rare boosted items: hunting + fill
    //   addN  — additive +-bonuses: value-selection layer
    //   wMin  — coarse weights: deep fill decades get harder
    struct HP { ll n, wMin; double rho, mul; int gems; double gemLo, gemHi; ll addN; };
    vector<HP> hp = {
        { 20000,  1500000, 0.6180340, 0.004,   0, 0,    0,       0},  // near-pure pennies
        { 40000,  2000000, 0.6931472, 0.030,   0, 0,    0,       0},  // ratio jitter
        { 60000,  3000000, 0.5772157, 0.005, 250, 1.10, 1.28,    0},  // gems
        { 80000, 50000000, 0.6065307, 0.020,   0, 0,    0,       0},  // coarse grind
        { 80000,  4000000, 0.7853982, 0.020,   0, 0,    0,   80000},  // sign bonuses
        {100000,  8000000, 0.7071068, 0.020, 150, 1.08, 1.20,    0},  // mixed
        {100000, 12000000, 0.8414710, 0.030, 300, 1.05, 1.15, 40000}, // everything
    };
    for(int t = 4; t <= 10; t++){
        rng.seed(100 + t);
        auto &p = hp[t - 4];
        vector<Item> its; long double sum = 0;
        for(ll i = 0; i < p.n; i++){
            double u = Rd(log((double)p.wMin), log(1.0e9));
            ll wt = max(p.wMin, min((ll)1000000000, (ll)exp(u)));
            double mult = p.rho * (1.0 + (p.mul > 0 ? Rd(-p.mul, p.mul) : 0.0));
            if(p.gems > 0 && i < p.gems) mult = p.rho * Rd(p.gemLo, p.gemHi);
            ll vv = (ll)llround(mult * wt);
            if(p.addN > 0) vv += R(-p.addN, p.addN);
            vv = max(1LL, min((ll)1000000000, vv));
            its.push_back({wt, vv});
            sum += wt;
        }
        ll W = (ll)min((long double)990000000000.0L, 0.45L * sum);
        emit(t, W, its);
    }
    return 0;
}