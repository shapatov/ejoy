// verify.cpp — checks an output file against an input file.
// Usage: ./verify <input> <output>
// Output format expected: line 1 = claimed value, line 2 = chosen 1-based indices.
// Exits 0 and prints OK iff indices are valid & distinct, total weight <= W,
// and the claimed value equals the actual value of the chosen set.

#include <bits/stdc++.h>
using namespace std;
using ll = long long;

int main(int argc, char **argv){
    if(argc < 3){ fprintf(stderr, "usage: %s <input> <output>\n", argv[0]); return 2; }
    FILE *fi = fopen(argv[1], "r"), *fo = fopen(argv[2], "r");
    if(!fi || !fo){ fprintf(stderr, "cannot open files\n"); return 2; }
    int n; ll W;
    if(fscanf(fi, "%d %lld", &n, &W) != 2){ fprintf(stderr, "bad input\n"); return 2; }
    vector<ll> w(n), v(n);
    for(int i = 0; i < n; i++)
        if(fscanf(fi, "%lld %lld", &w[i], &v[i]) != 2){ fprintf(stderr, "bad input\n"); return 2; }
    ll claimed;
    if(fscanf(fo, "%lld", &claimed) != 1){ printf("FAIL: no value on line 1\n"); return 1; }
    vector<char> seen(n, 0);
    ll sw = 0, sv = 0, cnt = 0, id;
    while(fscanf(fo, "%lld", &id) == 1){
        if(id < 1 || id > n){ printf("FAIL: index %lld out of range\n", id); return 1; }
        if(seen[id - 1]){ printf("FAIL: duplicate index %lld\n", id); return 1; }
        seen[id - 1] = 1;
        sw += w[id - 1]; sv += v[id - 1]; cnt++;
    }
    if(sw > W){ printf("FAIL: overweight %lld > %lld\n", sw, W); return 1; }
    if(sv != claimed){ printf("FAIL: claimed %lld, actual %lld\n", claimed, sv); return 1; }
    printf("OK  value=%lld  weight=%lld/%lld  items=%lld\n", sv, sw, W, cnt);
    return 0;
}