#include "redica.h"
#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

int n,k,s;
vector<int> a;

void rec(int pos, int sum) {
    if(pos>=n) {
        if(sum==0) submit(a);
        return;
    }
    if(sum<0) return;
    for(int i = 1; i <= k; i++) {
        a[pos]=i;
        rec(pos+1, sum-i);
    }
}

void solve(int n, int k, int s) { 
    ::n=n;
    ::k=k;
    ::s=s;
    a.resize(n);

    rec(0, s);
}