#include <bits/stdc++.h>
#include "redica.h"
using namespace std;
const int maxn = 307;
const int maxsum = maxn * maxn;
const int maxq = 6e6 + 7;
vector<int> v;
pair<long long int, long long int> dp[maxn][maxsum];
int n, k, s;
void bruteforce(vector<int> nums, int left, int sum)
{
    if (left == 0 && sum == 0)
    {
        vector<int> res;
        for (auto x : v)
        {
            res.push_back(x);
        }
        for (auto x : nums)
        {
            res.push_back(x);
        }
        submit(res);
        return;
    }
    if (left == 0)
        return;
    if (sum <= 0)
        return;
    for (int i = 1; i <= k && i <= sum; i++)
    {
        nums.push_back(i);
        bruteforce(nums, left - 1, sum - i);
        nums.pop_back();
    }
    return;
}
void solve(int N, int K, int S)
{
    n = N;
    k = K;
    s = S;

    dp[0][0].first = 1;

    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= s; j++)
        {
            for (int x = 1; x <= k && x <= j; x++)
            {
                if (dp[i - 1][j - x].second == 1)
                {
                    dp[i][j].second = 1;
                    break;
                }
                dp[i][j].first += dp[i - 1][j - x].first;
                if (dp[i][j].first > maxq)
                {
                    dp[i][j].second = 1;
                    break;
                }
            }
        }
    }

    for (int i = 1; i <= N; i++)
    {
        if (dp[n][s].first > 0 && dp[n][s].second == 0)
            bruteforce({}, n, s);
        n--;
        int curr = query();
        v.push_back(curr);
        s -= curr;
    }
}

/*
int main() {




return 0;
}
*/
