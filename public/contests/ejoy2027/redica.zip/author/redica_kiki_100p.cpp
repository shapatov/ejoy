#include <bits/stdc++.h>
#include "redica.h"
using namespace std;
const int maxn = 307;
const int maxsum = maxn * maxn;
const int maxq = 6e6 + 7;
vector<int> v;
long long int dp[maxn][maxsum];
long long int pref[maxn][maxsum];
int n, k, s;

void bruteforce(vector<int> &nums, int left, int sum)
{
    if (left == 0 && sum == 0)
    {

        submit(nums);
        return;
    }
    if (left * k < sum)
        return;
    if (left == 0)
        return;
    if (sum <= 0)
        return;
    for (int i = 1; i <= k && i <= sum; i++)
    {
        nums.push_back(i);
        bruteforce(nums, left - 1, sum - i);
        nums.pop_back();
    }
    return;
}
void solve(int N, int K, int S)
{
    n = N;
    k = K;
    s = S;

    dp[0][0] = 1;
    for (int j = 0; j <= s; j++)
    {
        pref[0][j] = 1;
    }
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= s; j++)
        {
            int sum;
            if (j <= k)
            {
                sum = pref[i - 1][j - 1];
            }
            else
            {
                sum = pref[i - 1][j - 1] - pref[i - 1][j - 1 - k];
            }
            if (sum >= maxq)
                dp[i][j] = maxq;
            else
                dp[i][j] = sum;
            pref[i][j] = pref[i][j - 1] + dp[i][j];
        }
    }

    for (int i = 1; i <= N; i++)
    {
        if (dp[n][s] > 0 && dp[n][s] < maxq)
            bruteforce(v, n, s);
        n--;
        int curr = query();
        v.push_back(curr);
        s -= curr;
    }
}

/*
int main() {




return 0;
}
*/
