#include "redica.h"
#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

int n,k,s;

void solve(int n, int k, int s) { 
    vector<int> v;
    for(int i = 0; i < n; i++) v.push_back(query());
    submit(v);
}