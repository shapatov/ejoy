#include "redica.h"
#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

int n,k,s;
vector<int> a;
pair<long long, bool> dp[367][90067];
long long mx;

inline void precalc() {
    dp[0][0]={1, 0};
    for(int i = 1; i <= n; i++) {
        for(int j = 0; j <= s; j++) {
            for(int val = 1; val <= k; val++) {
                if(j-val<0) continue;
                dp[i][j].first+=dp[i-1][j-val].first;
                if(dp[i][j].first>mx) {
                    dp[i][j].first=mx;
                    dp[i][j].second=1;
                }
            }
        }
    }
}

inline void rec(int pos, int sum) {
    if(sum<0) return;
    if(pos>=n) {
        if(sum==0) submit(a);
        return;
    }
    if(dp[n-pos][sum].first==0) return;
    for(int i = 1; i <= k; i++) {
        a[pos]=i;
        rec(pos+1, sum-i);
    }
}

void solve(int n, int k, int s) { 
    ::n=n;
    ::k=k;
    ::s=s;
    a.resize(n);

    mx=8e6;
    precalc();

    int sum = 0;

    for(int i = 0; i < n; i++) {
        if(dp[n-i][s-sum].second) {
            int val = query();
            sum+=val;
            a[i]=val;
        }
        else {
            rec(i, s-sum);
            return;
        }
    }
    submit(a);
}