#include "redica.h"
#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

int n,k,s;
vector<int> a;
pair<long long, bool> dp[367][300*300+67];
long long px1[367][300*300+67];
long long px2[367][300*300+67];
long long mx;

void precalc() {
    dp[0][0]={1, 0};
    px1[0][0]=1;
    for(int i = 1; i <= s; i++) px1[0][i]=1;
    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= s; j++) {
            // dp[i][j]=dp[i-1][j-1]+dp[i-1][j-2]+...+dp[i-1][j-k]
            dp[i][j].first=px1[i-1][j-1]-(j-k<0?0:px1[i-1][j-k-1]);
            dp[i][j].second=(px2[i-1][j-1]-(j-k<0?0:px2[i-1][j-k-1])>0);
            if(dp[i][j].first>mx || dp[i][j].second) {
                dp[i][j].first=mx;
                dp[i][j].second=1;
            }
        }
        px1[i][0]=dp[i][0].first;
        px2[i][0]=dp[i][0].second;
        for(int j = 1; j <= s; j++) {
            px1[i][j]=px1[i][j-1]+dp[i][j].first;
            px2[i][j]=px2[i][j-1]+dp[i][j].second;
        }
    }
}

void rec(int pos, int sum) {
    if(sum<0) return;
    if(pos>=n) {
        if(sum==0) submit(a);
        return;
    }
    if(dp[n-pos][sum].first==0) return;
    for(int i = max(1, sum-(n-pos-1)*k); i <= min(k, sum-(n-pos-1)); i++) {
        a[pos]=i;
        rec(pos+1, sum-i);
    }
}

void solve(int n, int k, int s) { 
    ::n=n;
    ::k=k;
    ::s=s;
    a.resize(n);

    mx=8e6;
    precalc();

    int sum = 0;

    for(int i = 0; i < n; i++) {
        if(dp[n-i][s-sum].second) {
            int val = query();
            sum+=val;
            a[i]=val;
        }
        else {
            rec(i, s-sum);
            return;
        }
    }
    submit(a);
}
