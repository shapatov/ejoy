#include <bits/stdc++.h>
#include "redica.h"
using namespace std;
const int maxn = 307;
const int maxsum = maxn * maxn;
const int maxq = 1e8 + 7;
int n, k, s;
void bruteforce(vector<int> nums, int left, int sum)
{
    if (left == 0 && sum == 0)
    {
        submit(nums);
        return;
    }
    if (left == 0)
        return;
    if (sum <= 0)
        return;
    for (int i = 1; i <= k && i <= sum; i++)
    {
        nums.push_back(i);
        bruteforce(nums, left - 1, sum - i);
        nums.pop_back();
    }
    return;
}
void solve(int N, int K, int S)
{
    n = N;
    k = K;
    s = S;

    bruteforce({}, n, s);
}

/*
int main() {




return 0;
}
*/
