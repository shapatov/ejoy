#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <vector>
using namespace std;
const string password = "026ac928b3136a17308dd54987eea5c882994f8d9b7a452d1d698344072d251e";
void output_message(double points, string message){
	cout << fixed << setprecision(2) << points << endl;
	cerr << message << endl;
	exit(0);
}

int main (int argc, char** argv) {
	if(argc < 4){ output_message(0, "Insufficient arguments!"); return 1; }
	fstream input(argv[1]), output(argv[2]), contestant(argv[3]);
	if(!input.is_open()){ output_message(0, "Couldn't open input file."); return 1; }
	if(!output.is_open()){ output_message(0, "Couldn't open output file."); return 1; }
	if(!contestant.is_open()){ output_message(0, "Couldn't open contestant file."); return 1; }
	string check;
	contestant >> check;
	if(check != password){ output_message(0, "Contestant wrote to cout."); return 1; }
	int ok;
    contestant >> ok;
    if(ok==-1) {
        output_message(0, "Query out of bounds!"); return 1;
    }
    if(ok==0) {
        output_message(0, "Wrong answer!"); return 1;
    }
    int q;
    contestant >> q;
    int n;
    contestant >> n;
    int qopt;
    output >> qopt;
    double pts = max(0.1, min(1.0, pow(1.0-double(q-qopt)/double(n-qopt+1), 3)));
    output_message(pts, "OK in " + to_string(q) + " queries!");
	exit(0);
	return 0;
}