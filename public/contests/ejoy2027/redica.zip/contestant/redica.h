#include <vector>
void solve(int, int, int);
int query();
void submit(const std::vector<int>&);