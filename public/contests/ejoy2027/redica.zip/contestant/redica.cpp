#include "redica.h"

void solve(int N, int K, int S) {
    submit({});
}