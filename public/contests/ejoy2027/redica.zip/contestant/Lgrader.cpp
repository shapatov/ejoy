#include "redica.h"
#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <cstring>
#include <array>
using namespace std;

namespace gr {
    static int n, k, s;
    static vector<int> v;
    static int ptr = 0, cnt = 0;
}
using namespace gr;

int query() {
    ptr++;
    cnt++;
    if(ptr-1>=v.size()) {
        cout << "Query out of bounds!" << endl;
        exit(0);
    }
    return v[ptr-1];
}

void submit(const vector<int>& a) {
    if(a==v) {
        cout << "Correct with " << cnt << " queries" << endl;
        exit(0);
    }
}

int main() {
    cin >> n >> k >> s;
    for(int i = 0; i < n; i++) {
        int b; 
        cin >> b;
        v.push_back(b);
    }
    solve(n, k, s);
    cout << "Wrong answer with " << cnt << " queries" << endl;
}