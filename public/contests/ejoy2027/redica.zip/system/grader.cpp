#include "redica.h"
#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <cstring>
#include <array>
using namespace std;

namespace gr {
    static int n, k, s;
    static vector<int> v;
    static int ptr = 0, cnt = 0;
    static int ok=0;
    static const string password = "026ac928b3136a17308dd54987eea5c882994f8d9b7a452d1d698344072d251e";
}
using namespace gr;

int query() {
    ptr++;
    cnt++;
    if(ptr-1>=v.size()) {
        ok = -1;
        return -1;
    }
    return v[ptr-1];
}

void submit(const vector<int>& a) {
    if(ok==-1) return;
    if(a==v) {
        cout << password << " " << 1 << " " << cnt << " " << n << endl;
        exit(0);
    }
}

int main() {
    cin >> n >> k >> s;
    for(int i = 0; i < n; i++) {
        int b; 
        cin >> b;
        v.push_back(b);
    }
    solve(n, k, s);
    cout << password << " " << ok << " " << cnt << " " << n << endl;
}