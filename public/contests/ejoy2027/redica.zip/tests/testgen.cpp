#include <iostream>
#include <fstream>
#include <random>
#include <time.h>
#include <algorithm>
#include <assert.h>
#include <set>
#include <queue>
#include <limits.h>
using namespace std;
mt19937 mt(random_device{}());
namespace author {
    int n,k,s;
    int ptr = 0, cnt = 0;
    vector<int> a, real;
    pair<long long, bool> dp[367][300*300+67];
    long long px1[367][300*300+67];
    long long px2[367][300*300+67];
    long long mx;
    
    void precalc() {
        dp[0][0]={1, 0};
        px1[0][0]=1;
        for(int i = 1; i <= s; i++) px1[0][i]=1;
        for(int i = 1; i <= n; i++) {
            for(int j = 1; j <= s; j++) {
                // dp[i][j]=dp[i-1][j-1]+dp[i-1][j-2]+...+dp[i-1][j-k]
                dp[i][j].first=px1[i-1][j-1]-(j-k<0?0:px1[i-1][j-k-1]);
                dp[i][j].second=(px2[i-1][j-1]-(j-k<0?0:px2[i-1][j-k-1])>0);
                if(dp[i][j].first>mx || dp[i][j].second) {
                    dp[i][j].first=mx;
                    dp[i][j].second=1;
                }
            }
            px1[i][0]=dp[i][0].first;
            px2[i][0]=dp[i][0].second;
            for(int j = 1; j <= s; j++) {
                px1[i][j]=px1[i][j-1]+dp[i][j].first;
                px2[i][j]=px2[i][j-1]+dp[i][j].second;
            }
        }
    }

    int query() {
        ptr++;
        cnt++;
        if(ptr-1>=real.size()) {
            cout << "Query out of bounds!" << endl;
            return -1;
        }
        return real[ptr-1];
    }

    void submit(vector<int> a) {
        if(a==real) {
            cout << "Correct with " << cnt << " queries" << endl;
        }
    }
    void rec(int pos, int sum) {
        if(sum<0) return;
        if(dp[n-pos][sum].first==0) return;
        if(pos>=n) {
            if(sum==0) submit(a);
            return;
        }
        for(int i = 1; i <= k; i++) {
            a[pos]=i;
            rec(pos+1, sum-i);
        }
    }

    int solve(int k, int s, vector<int> r) {
        author::n=r.size();
        author::k=k;
        author::s=s;
        author::real = r;
        ptr=0;
        cnt=0;
        a.clear();
        a.resize(n);

        mx=8e6;
        precalc();

        int sum = 0;
        
        for(int i = 0; i < n; i++) {
            if(dp[n-i][s-sum].second) {
                int val = query();
                sum+=val;
                a[i]=val;
            }
            else {
                rec(i, s-sum);
                break;
            }
        }
        submit(a);
        return cnt;
    }
};
int main() {
    for(int i = 2; i <= 6; i++) {
        ofstream in("redica." + (string)(i<10?"0":"") + to_string(i) + ".in");
        ofstream out("redica." + (string)(i<10?"0":"") + to_string(i) + ".out");
        int n=7,k=10;
        int s=0;
        vector<int> a;
        for(int i = 0; i < n; i++) {a.push_back(1+mt()%k); s+=a[a.size()-1];}
        in << n << " " << k << " " << s << endl;
        for(auto x : a) in << x << " ";
        in << endl;
        int qopt = author::solve(k, s, a);
        out << qopt << endl;
        in.close();
        out.close();
    }
    for(int i = 7; i <= 8; i++) {
        ofstream in("redica." + (string)(i<10?"0":"") + to_string(i) + ".in");
        ofstream out("redica." + (string)(i<10?"0":"") + to_string(i) + ".out");
        int n=15,k=15;
        int s=0;
        vector<int> a;
        for(int i = 0; i < n; i++) {a.push_back(1+mt()%k); s+=a[a.size()-1];}
        in << n << " " << k << " " << s << endl;
        for(auto x : a) in << x << " ";
        in << endl;
        int qopt = author::solve(k, s, a);
        out << qopt << endl;
        in.close();
        out.close();
    }
    for(int i = 9; i <= 10; i++) {
        ofstream in("redica." + (string)(i<10?"0":"") + to_string(i) + ".in");
        ofstream out("redica." + (string)(i<10?"0":"") + to_string(i) + ".out");
        int n=15,k=7;
        int s=0;
        vector<int> a;
        for(int i = 0; i < n; i++) {a.push_back(1+mt()%k); s+=a[a.size()-1];}
        in << n << " " << k << " " << s << endl;
        for(auto x : a) in << x << " ";
        in << endl;
        int qopt = author::solve(k, s, a);
        out << qopt << endl;
        in.close();
        out.close();
    }
    for(int i = 11; i <= 13; i++) {
        ofstream in("redica." + (string)(i<10?"0":"") + to_string(i) + ".in");
        ofstream out("redica." + (string)(i<10?"0":"") + to_string(i) + ".out");
        int n=30,k=67;
        int s=0;
        vector<int> a;
        for(int i = 0; i < n; i++) {a.push_back(1+mt()%k); s+=a[a.size()-1];}
        in << n << " " << k << " " << s << endl;
        for(auto x : a) in << x << " ";
        in << endl;
        int qopt = author::solve(k, s, a);
        out << qopt << endl;
        in.close();
        out.close();
    }
    for(int i = 14; i <= 15; i++) {
        ofstream in("redica." + (string)(i<10?"0":"") + to_string(i) + ".in");
        ofstream out("redica." + (string)(i<10?"0":"") + to_string(i) + ".out");
        int n=30,k=2;
        int s=0;
        vector<int> a;
        for(int i = 0; i < n; i++) {a.push_back(1+mt()%k); s+=a[a.size()-1];}
        in << n << " " << k << " " << s << endl;
        for(auto x : a) in << x << " ";
        in << endl;
        int qopt = author::solve(k, s, a);
        out << qopt << endl;
        in.close();
        out.close();
    }
    for(int i = 16; i <= 17; i++) {
        ofstream in("redica." + (string)(i<10?"0":"") + to_string(i) + ".in");
        ofstream out("redica." + (string)(i<10?"0":"") + to_string(i) + ".out");
        int n=67,k=67;
        int s=0;
        vector<int> a;
        for(int i = 0; i < n; i++) {a.push_back(1+mt()%k); s+=a[a.size()-1];}
        in << n << " " << k << " " << s << endl;
        for(auto x : a) in << x << " ";
        in << endl;
        int qopt = author::solve(k, s, a);
        out << qopt << endl;
        in.close();
        out.close();
    }
    for(int i = 18; i <= 20; i++) {
        ofstream in("redica." + (string)(i<10?"0":"") + to_string(i) + ".in");
        ofstream out("redica." + (string)(i<10?"0":"") + to_string(i) + ".out");
        int n=67,k=100;
        int s=0;
        vector<int> a;
        for(int i = 0; i < n; i++) {a.push_back(1+mt()%k); s+=a[a.size()-1];}
        in << n << " " << k << " " << s << endl;
        for(auto x : a) in << x << " ";
        in << endl;
        int qopt = author::solve(k, s, a);
        out << qopt << endl;
        in.close();
        out.close();
    }
    
    for(int i = 21; i <= 21; i++) {
        ofstream in("redica." + (string)(i<10?"0":"") + to_string(i) + ".in");
        ofstream out("redica." + (string)(i<10?"0":"") + to_string(i) + ".out");
        int n=300,k=200;
        int s=0;
        vector<int> a;
        for(int i = 0; i < n; i++) {a.push_back(1+mt()%k); s+=a[a.size()-1];}
        in << n << " " << k << " " << s << endl;
        for(auto x : a) in << x << " ";
        in << endl;
        int qopt = author::solve(k, s, a);
        out << qopt << endl;
        in.close();
        out.close();
    }
    
    for(int i = 22; i <= 24; i++) {
        ofstream in("redica." + (string)(i<10?"0":"") + to_string(i) + ".in");
        ofstream out("redica." + (string)(i<10?"0":"") + to_string(i) + ".out");
        int n=300,k=300;
        int s=0;
        vector<int> a;
        for(int i = 0; i < n; i++) {a.push_back(1+mt()%k); s+=a[a.size()-1];}
        in << n << " " << k << " " << s << endl;
        for(auto x : a) in << x << " ";
        in << endl;
        int qopt = author::solve(k, s, a);
        out << qopt << endl;
        in.close();
        out.close();
    }
    for(int i = 25; i <= 25; i++) {
        ofstream in("redica." + (string)(i<10?"0":"") + to_string(i) + ".in");
        ofstream out("redica." + (string)(i<10?"0":"") + to_string(i) + ".out");
        int n=300,k=300;
        int s=0;
        vector<int> a;
        for(int i = 0; i < n; i++) {a.push_back(k-1); s+=a[a.size()-1];}
        in << n << " " << k << " " << s << endl;
        for(auto x : a) in << x << " ";
        in << endl;
        int qopt = author::solve(k, s, a);
        out << qopt << endl;
        in.close();
        out.close();
    }
    
    for(int i = 26; i <= 27; i++) {
        ofstream in("redica." + (string)(i<10?"0":"") + to_string(i) + ".in");
        ofstream out("redica." + (string)(i<10?"0":"") + to_string(i) + ".out");
        int n=300,k=170;
        int s=0;
        vector<int> a;
        for(int i = 0; i < n; i++) {a.push_back(1+mt()%k); s+=a[a.size()-1];}
        in << n << " " << k << " " << s << endl;
        for(auto x : a) in << x << " ";
        in << endl;
        int qopt = author::solve(k, s, a);
        out << qopt << endl;
        in.close();
        out.close();
    }
}