#include<bits/stdc++.h>
using namespace std;
vector<int>encode(vector<int>a) {
    for(int i=0; i<a.size(); i++) {
        if(a[i]==1)  a[i]=-1;
    }
    return a;
}
vector<int>decode(vector<int>a) {
    for(int i=0; i<a.size(); i++) {
        if(a[i]==-1) a[i]=1;
    }
    return a;
}


