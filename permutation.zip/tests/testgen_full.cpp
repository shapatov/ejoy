#include <bits/stdc++.h>
using namespace std;

int main() {
    mt19937 rng(random_device{}());

    for(int t=1; t<=69; t++) {
        int N = uniform_int_distribution<int>(1, 100000)(rng);
        int S = uniform_int_distribution<int>(0, N)(rng);

        vector<int> perm(N);
        iota(perm.begin(), perm.end(), 1); // 1..N

        // Pick S random positions to be the "smallest unused so far"
        vector<int> positions(N);
        iota(positions.begin(), positions.end(), 0);
        shuffle(positions.begin(), positions.end(), rng);

        vector<int> smallest_positions(positions.begin(), positions.begin() + S);
        sort(smallest_positions.begin(), smallest_positions.end()); // optional

        vector<int> remaining;
        for(int i=S+1; i<=N; i++) remaining.push_back(i);

        shuffle(remaining.begin(), remaining.end(), rng);

        // Fill perm: first S positions get 1..S
        for(int i=0; i<S; i++) perm[smallest_positions[i]] = i+1;

        // Fill the rest positions with remaining numbers
        int idx = 0;
        for(int i=0; i<N; i++) {
            if(find(smallest_positions.begin(), smallest_positions.end(), i) != smallest_positions.end()) continue;
            perm[i] = remaining[idx++];
        }

        // Write files
        ofstream fin(to_string(t) + ".in");
        fin << N << "\n";
        for(int i=0; i<N; i++) {
            fin << perm[i] << (i+1==N ? "\n" : " ");
        }
        fin.close();

        ofstream fout(to_string(t) + ".out"); fout.close();

        cout << "Test " << t << ": N=" << N << ", S=" << S << "\n";
    }
}

