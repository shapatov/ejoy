#!/bin/bash
set -e

# clean old
rm -f *.in *.out

for t in $(seq 1 69); do
    # pick n between 5 and 1e5
    n=$((5 + RANDOM % 100000))

    # create array 1..n
    seq 1 $n | shuf > perm.txt

    # write to file
    echo $n > "$t.in"
    tr '\n' ' ' < perm.txt | sed 's/ $//' >> "$t.in"
    echo >> "$t.in"

    # make empty out file
    > "$t.out"

    rm -f perm.txt
done

