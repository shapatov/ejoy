#include <bits/stdc++.h>
using namespace std;

int main() {
    mt19937 rng(random_device{}());

    for(int t=15; t<=20; t++) {
        int N = uniform_int_distribution<int>(1, 100000)(rng);
        int S = uniform_int_distribution<int>(0, N)(rng);

        vector<int> perm(N);
        iota(perm.begin(), perm.end(), 1); // 1..N
	reverse(perm.begin(), perm.end());
        // Write files
        ofstream fin(to_string(t) + ".in");
        fin << N << "\n";
        for(int i=0; i<N; i++) {
            fin << perm[i] << (i+1==N ? "\n" : " ");
        }
        fin.close();

        ofstream fout(to_string(t) + ".out"); fout.close();

        cout << "Test " << t << ": N=" << N << ", S=" << S << "\n";
    }
}

