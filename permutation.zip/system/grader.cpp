#include "permutation.h"
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;
const string password = "da764c687c5a6cdf5803c75da13b297fb221f9a680f5e87b505e1015ce1a28f3";
namespace gr {
	int author(vector<int> p) {
	    int n = p.size();
	    vector<bool> used(n+1, 0);
	    int cur = 1; 
		int cnt = 0;
	    for (int i = 0; i < n; i++) {
	        if (p[i] == cur) {
	            cnt++;
	            used[cur] = 1;
	            while (cur <= n && used[cur]) cur++;
	        } else {
	            used[p[i]] = 1;
	            while (cur <= n && used[cur]) cur++;
	        }
	    }
	    return cnt;
	}
};
int main() {
	int n;
	cin >> n;
	vector<int> p(n);
	for(int i = 0; i < n; i++) cin >> p[i];

	vector<int> p2 = p; // tampered
	p2.push_back(n+1);
	
	vector<int> e = encode(p), e2 = encode(p2);
	if(e.size()!=p.size() || e2.size()!=p2.size()) {
	    cout << password << " " << 0 << endl;
	    cout << "Wrong vector size!" << endl;
	    exit(0);
	}
	double cnt = 0;
	for(auto x : e) cnt += (x==-1);

	// greedy global memory detection
	if(decode(e) == p2) {
	    // if decode(original encoded) == tampered, then tampered was stored in global memory
	    cout << password << " " << 0 << endl;
	    cout << "Global memory detected!" << endl;
	    exit(0);
	}
	if(decode(e) == p) {
	    // ok
		double optimal = gr::author(p);
		double pts2 = max(0.0, min(1.0, cnt/optimal));
		double pts = ceil(pts2 * 100.0) / 100.0;
	    cout << password << " " << fixed << setprecision(2) << pts << endl;
	    if(cnt==0) cout << "No negative ones!" << endl;
		else cout << "Correct!" << endl;
	    exit(0);
	}

	// no global memory, wrong answer
	cout << password << " " << 0 << endl;
	cout << "Wrong answer!" << endl;
}