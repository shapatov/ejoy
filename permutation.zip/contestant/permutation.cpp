#include <bits/stdc++.h>
using namespace std;
vector<int> encode(vector<int> p) {
	return {};
}
vector<int> decode(vector<int> p) {
	return {};
}
