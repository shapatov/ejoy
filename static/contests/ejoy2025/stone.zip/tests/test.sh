

./a.out < stone.21.in

./a.out < stone.22.in

./a.out < stone.23.in

./a.out < stone.24.in

./a.out < stone.25.in

./a.out < stone.26.in

./a.out < stone.27.in

./a.out < stone.28.in

./a.out < stone.29.in

./a.out < stone.30.in
