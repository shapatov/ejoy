# Generate 10 empty output files stone.31.out to stone.40.out
for i in range(1, 41):
    filename = f"stone.{i}.out"
    with open(filename, "w") as f:
        pass  # Create empty file

