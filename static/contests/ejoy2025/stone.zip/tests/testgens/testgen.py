import random

# Generate 10 test files stone.31.in to stone.40.in
for i in range(21, 31):
    filename = f"stone.{i}.in"
    n =10**3
    m =10**3
    
    # Generate first list of n random numbers between 0 and m inclusive
    first_line = [str(random.randint(0, m)) for _ in range(n)]
    
    # Generate second list of n unique random numbers between 0 and m inclusive
    # Since m is very large, ensure uniqueness by sampling
    second_line = random.sample(range(0, m+1), n)
    
    with open(filename, "w") as f:
        f.write(f"{n} {m}\n")
        f.write(" ".join(first_line) + "\n")
        f.write(" ".join(map(str, second_line)) + "\n")
