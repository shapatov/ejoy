#include<iostream>
#define endl '\n'
#include "stone.h"
#define ll long long
using namespace std;
ll dronebattery=9;
void safemovedrone(vector<ll> pos)
{
    if(dronebattery==1)
    {
        movedrone(getposself());
        chargedrone();
        dronebattery=12;
    }
    movedrone(pos);
    dronebattery--;
}
vector<ll> calcmid(vector<ll> x,vector<ll> y)
{
    vector<ll> res;
    for(ll i=0;i<x.size();i++)
    {
        res.push_back((x[i]+y[i])/2);
    }
    return res;
}
bool check(vector<ll> dirs)
{
    for(ll i=0;i<dirs.size();i++)
    {
        if(dirs[i]!=2)return false;
    }
    return true;
}
void solve(ll n,ll m)
{
    vector<ll> l;
    vector<ll> r;
    vector<ll> mid;
    for(ll i=0;i<n;i++)
    {
        l.push_back(0);
        r.push_back(m);
    }
    mid=calcmid(l,r);
    safemovedrone(mid);
    vector<ll> dirs=query();
    while(!check(dirs))
    {
        for(ll i=0;i<n;i++)
        {
            if(dirs[i]==0)
            {
                r[i]=mid[i]-1;
            }
            else if(dirs[i]==1)
            {
                l[i]=mid[i]+1;
            }
        }
        mid=calcmid(l,r);
        safemovedrone(mid);
        dirs=query();
    }
    moveself(mid);
    portal();
}
