	#include<iostream>
#define endl '\n'
#include "stone.h"
#include "stone.cpp"
#define ll long long
using namespace std;

void speed()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
}
ll _n,_m;
vector<long long> _portalpos;
vector<long long> _playerpos;
vector<long long> _dronepos;
ll _playermove=0;
ll _dronebattery=12;
ll _queriesused=0;
void moveself(vector<ll> pos)
{
    _playermove++;
    _playerpos=pos;
}
void movedrone(vector<ll> pos)
{
    if(_dronebattery>0)
    {
        _dronebattery--;
        _dronepos=pos;
    }
    else
    {
        cout<<"Atempted to move drone without any battery left\n";
        exit(0);
    }
}
void hugdrone() {

}
void changename(string a) {

}
void chargedrone()
{
    if(_dronepos==_playerpos)
    {
        _playermove++;
        _dronebattery=12;
    }
    else
    {
        cout<<"Atempted to charge drone while not in same position as drone\n";
        exit(0);
    }
}
vector<ll> getposself()
{
    return _playerpos;
}
vector<ll> getposdrone()
{
    return _dronepos;
}
vector<ll> query()
{
    _queriesused++;
    vector<ll> res(_n);
    for(ll i=0; i<_n; i++)
    {
        if(_portalpos[i]<_dronepos[i])res[i]=0;
        else if(_portalpos[i]>_dronepos[i])res[i]=1;
        else res[i]=2;
    }
    return res;
}
void portal()
{
    if(_playerpos==_portalpos)
    {
        cout<<"Reached portal with "<<_playermove<<" player moves or drone charges and with "<<_dronebattery<<"% dronebattery left and with "<<_queriesused<<" queries\n";
        exit(0);
    }
    else
    {
        cout<<"Called portal() while not in same position as portal with "<<_playermove<<" player moves or drone charges and with "<<_dronebattery<<"% dronebattery left and with "<<_queriesused<<" queries\n";
        exit(0);
    }
}
signed main()
{
    speed();
    cin>>_n>>_m;
    for(ll i=0; i<_n; i++)
    {
        ll x;
        cin>>x;
        _playerpos.push_back(x);
    }
    for(ll i=0; i<_n; i++)
    {
        ll x;
        cin>>x;
        _portalpos.push_back(x);
    }
    _dronepos=_playerpos;
    solve(_n,_m);
    if(_playerpos==_portalpos)portal();
    cout<<"You did not reach portal"<<endl;
    return 0;
}
