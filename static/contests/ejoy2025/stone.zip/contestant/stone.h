#include <vector>
#include <string>

std::vector<long long> query();
void moveself(std::vector<long long> pos);
void movedrone(std::vector<long long> pos);
void chargedrone();
void portal();
void solve(long long n,long long m);
std::vector<long long> getposself();
std::vector<long long> getposdrone();
void changename(std::string name);
void hugdrone();
