#include "bribe.h"
void solve(int n) {

}
