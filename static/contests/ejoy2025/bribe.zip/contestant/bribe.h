#include <iostream>
using namespace std;
void bribe();
int query(int u, int v);
void submit(int l);
void solve(int n);