#include<iostream>
#include<vector>
#include<algorithm>
#include<random>
#include<iomanip>
#include<chrono>
#include<cstdint>
#include<ctime>
#include"bribe.h"
using namespace std;
namespace Lgrader { 
    int n,m;
    int par[1005];
    int s[1005][1005]={0};
    mt19937 t(
        random_device{}() ^                       // OS entropy
        (chrono::high_resolution_clock::now().time_since_epoch().count()) ^ // nanosecond clock
        (uintptr_t)new int                        // unique-ish memory address
    );
    struct edge {
        int w,a,b;
        const bool operator<(const edge &q) const {
            return w<q.w;
        };
    };
    int findpar(int k) {
        if(par[k]==k) return k;
        return par[k]=findpar(par[k]);
    }
    long long sum=0;
    void join(int a, int b, int w) {
        a = findpar(a), b = findpar(b);
        if(a==b) return;
        par[b]=a;
        sum+=w;
    }
    int l=0, used_bribes=0, percent=67;
    
    double abs(double a) { return (a<0?-a:a); }
}
int query(int u, int v) {
        int r = Lgrader::t()%100+1;
        bool lie = r <= Lgrader::percent;
        if(lie) {
            if(Lgrader::s[u][v]) {
                return -1;
            }
            else {
                return Lgrader::t()%10000;
            }
        }
        else {
            if(Lgrader::s[u][v]!=0) {
                return Lgrader::s[u][v];
            }
            else {
                return -1;
            }
        }
    }
    void bribe() {
        if(Lgrader::percent==0) return;
        Lgrader::used_bribes++;
        Lgrader::percent--;
    }
    void submit(int l) {
        Lgrader::l=l;
    }
int main() {
    cin >> Lgrader::n >> Lgrader::m;
    vector<Lgrader::edge> v;
    for(int i = 1; i <= Lgrader::m; i++) {
        int a,b,c; cin >> a >> b >> c;
        if(Lgrader::s[a][b]==0 || Lgrader::s[a][b]>c) {
            Lgrader::s[a][b]=c;
            Lgrader::s[b][a]=c;
        }
        v.push_back({c,a,b});
    }
    for(int i = 1; i <= Lgrader::n; i++) Lgrader::par[i]=i;
    sort(v.begin(), v.end());
    for(auto x : v) {
        Lgrader::join(x.a, x.b, x.w);
    }
    solve(Lgrader::n);
    double mst_weight = Lgrader::sum, your_weight = Lgrader::l;
    double coeffMst = 0;
    double diff = Lgrader::abs(mst_weight-your_weight);
    
    if(diff <= 10) coeffMst = 1;
    else if(diff <= 50) coeffMst = 0.85;
    else if(diff <= 100) coeffMst = 0.80;
    else if(diff <= 100000) coeffMst = 0.40;
    else if(diff <= 1000000) coeffMst = 0.35;
    else if(diff <= 10000000) coeffMst = 0.30;
    else if(diff <= 100000000) coeffMst = 0.20;
    else if(diff <= 1000000000) coeffMst = 0.10;
    else if(diff <= 10000000000) coeffMst = 0.05;
    double coeffB = 0;
    if(Lgrader::used_bribes <= 10) coeffB=1;
    else if(Lgrader::used_bribes <= 20) coeffB=0.95;
    else if(Lgrader::used_bribes <= 40) coeffB=0.92;
    else if(Lgrader::used_bribes <= 50) coeffB=0.90;
    else if(Lgrader::used_bribes <= 67) coeffB=0.75;
    double result = coeffMst*coeffB;
    cout << fixed << setprecision(4) << result << endl;
    /*
    
    
    */
}
