// ne e pisano ot gpt
#include <bits/stdc++.h>
using namespace std;

struct Edge {
    long long u, v, w;
};

long long find_set(long long v, vector<long long> &parent) {
    if (v == parent[v]) return v;
    return parent[v] = find_set(parent[v], parent);
}

bool union_sets(long long a, long long b, vector<long long> &parent, vector<long long> &rank) {
    a = find_set(a, parent);
    b = find_set(b, parent);
    if (a == b) return false;
    if (rank[a] < rank[b]) swap(a, b);
    parent[b] = a;
    if (rank[a] == rank[b]) rank[a]++;
    return true;
}

main() {
    srand(time(0));
    for (long long test = 1; test <= 67; test++) {
        long long N = 100 + rand() % 901;         // N между 100 и 1000
        long long M = N-1 + rand() % (N*2);       // M >= N-1, <= N*2

        vector<Edge> edges;

        // Свързано дърво първо
        for (long long i = 2; i <= N; i++) {
            long long u = i;
            long long v = rand() % (i-1) + 1;
            long long w = rand() % 9999 + 1;
            edges.push_back({u, v, w});
        }

        // Добавяме произволни ребра до M
        while ((long long)edges.size() < M) {
            long long u = rand() % N + 1;
            long long v = rand() % N + 1;
            if (u == v) continue;
            long long w = rand() % 9999 + 1;
            edges.push_back({u, v, w});
        }

        // Записваме input файл
        char fname[20];
        sprintf(fname, "bribe.%02d.in", test);
        ofstream fin(fname);
        fin << N << " " << M << "\n";
        for (auto &e : edges) fin << e.u << " " << e.v << " " << e.w << "\n";
        fin.close();

        // Изчисляваме MST (Kruskall)
        sort(edges.begin(), edges.end(), [](Edge &a, Edge &b){ return a.w < b.w; });
        vector<long long> parent(N+1), rank(N+1, 0);
        for (long long i=1;i<=N;i++) parent[i]=i;
        long long mst = 0;
        for (auto &e : edges) {
            if (union_sets(e.u, e.v, parent, rank)) mst += e.w;
        }

        // Записваме output файл
        sprintf(fname, "bribe.%02d.out", test);
        ofstream fout(fname);
        fout << mst << "\n";
        fout.close();
    }

    return 0;
}
