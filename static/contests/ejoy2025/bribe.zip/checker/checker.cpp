#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

void output_message(double points, const char message[]) {
    fprintf(stdout, "%f\n", points);
    fflush(stdout);
    fflush(stderr);
    exit(0);
}

int main(int argc, char **argv) {
    FILE *inp, *ans, *out;
    if (argc < 4) output_message(0, "The checker needs input file, correct output and contestant output!");

    inp = fopen(argv[1], "rt");
    if (!inp) output_message(0, "Could not open input file!");
    ans = fopen(argv[2], "rt");
    if (!ans) output_message(0, "Could not open correct output file!");
    out = fopen(argv[3], "rt");
    if (!out) output_message(0, "Could not open contestant output file!");

    double res;
    char extra[1024];

    // Try to read a double
    if (fscanf(out, "%lf", &res) != 1) 
        output_message(0, "Could not read output as a number!");

    // Check for any extra characters after the number
    if (fscanf(out, "%1023s", extra) == 1) 
        output_message(0, "Extra output detected! Only a number is allowed.");

    output_message(res, "");  // valid output
    return 0;
}
