#pragma GCC optimize("Ofast")
#pragma GCC target("avx2")

#include <iostream>
#include <cstring>
#include <random>
#include <ctime>
#include <fstream>
#include <stack>
#include <algorithm>
#include <unordered_set>
#include <set>
#include <unordered_map>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;

int par[10000];
bool used[10000];
int sz[10000];

template<class T>
using ordered_set = __gnu_pbds::tree<T, __gnu_pbds::null_type, less<T>, __gnu_pbds::rb_tree_tag, __gnu_pbds::tree_order_statistics_node_update>;
mt19937 mt(random_device{}());

inline int findpar(int k) {
    if(par[k]==k) return k;
    return par[k]=findpar(par[k]);
}

inline bool join(int a, int b) {
    a=findpar(a), b=findpar(b);
    if(a==b) return 0;
    if(sz[b]>sz[a]) swap(a, b);
    par[b]=a;
    sz[a]+=sz[b];
    return 1;
}

void solve() {
    int n,m;
    cin >> n >> m;
    for(int i = 1; i <= n; i++) {sz[i]=1;par[i]=i;}
    memset(used, 0, sizeof(used));
    vector<pair<int, pair<int,pair<int, int>>>> v, og(m+1);
    for(int i = 1; i <= m; i++) {
        int a,b,w; cin >> a >> b >> w;
        og[i] = {w, {a, {b, i}}};
        v.push_back(og[i]);
    }

    // min mst
    int mn=0;
    sort(v.begin(), v.end());
    for(int i = 0; i < v.size(); i++) mn+=v[i].first*(int)join(v[i].second.first, v[i].second.second.first);
    for(int i = 1; i <= n; i++) {sz[i]=1;par[i]=i;}

    // max mst
    ordered_set<int> bestv;
    int mx=0,ans;
    for(int i = v.size()-1; i >= 0; i--) {
        if(join(v[i].second.first, v[i].second.second.first)) {
            mx+=v[i].first;
            bestv.insert(v[i].second.second.second);
        }
    }
    ans=mx;
    for(int i = 1; i <= n; i++) {sz[i]=1;par[i]=i;}

    int target = mn+((mx-mn+1)*67)/100;

    vector<pair<int,vector<int>>> all;

    const int br = 1e8/n;
    for(auto &x : bestv) used[x]=1;

    // hill climb
    for(int it = 0; it < br; it++) {
        int used = *bestv.find_by_order(mt()%bestv.size());
        int unused = mt()%m+1;
        while(::used[unused]) unused=mt()%m+1;
        if(abs(ans-target)>abs(ans-og[used].first+og[unused].first-target)) {
            for(int i = 1; i <= n; i++) {sz[i]=1;par[i]=i;}
            for(auto &x : bestv) {
                if(x!=used) join(og[x].second.first, og[x].second.second.first);
            }
            join(og[unused].second.first, og[unused].second.second.first);
            bool ok=1;
            int base=findpar(1);
            for(int i = 2; i <= n; i++) ok&=(findpar(i)==base);
            if(ok) {
                ::used[used]=0, ::used[unused]=1;
                bestv.erase(used);
                bestv.insert(unused);
                ans=ans-og[used].first+og[unused].first;
            }
        }
    }

    for(auto &x : bestv) cout << x << " ";
    cout << endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    for(int test = 1; test <= 10; test++) {
        string s = (test<10?"0":"") + to_string(test);
        freopen(("test."+s+".in").c_str(), "r", stdin);
        freopen(("test."+s+".out").c_str(), "w", stdout);
        int t; cin >> t; while(t--) solve();
    }
}