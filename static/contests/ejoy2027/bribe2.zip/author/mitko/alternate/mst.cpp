#pragma GCC optimize("Ofast")
#pragma GCC target("avx2")

#include <iostream>
#include <cstring>
#include <random>
#include <ctime>
#include <fstream>
#include <stack>
#include <algorithm>
#include <unordered_set>
#include <set>
#include <unordered_map>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;

int par[10000];
int sz[10000];

template<class T>
using ordered_set = __gnu_pbds::tree<T, __gnu_pbds::null_type, less<T>, __gnu_pbds::rb_tree_tag, __gnu_pbds::tree_order_statistics_node_update>;
mt19937 mt(random_device{}());

inline int findpar(int k) {
    if(par[k]==k) return k;
    return par[k]=findpar(par[k]);
}

inline bool join(int a, int b) {
    a=findpar(a), b=findpar(b);
    if(a==b) return 0;
    if(sz[b]>sz[a]) swap(a, b);
    par[b]=a;
    sz[a]+=sz[b];
    return 1;
}

void solve() {
    int n,m;
    cin >> n >> m;
    for(int i = 1; i <= n; i++) {sz[i]=1;par[i]=i;}
    vector<pair<int, pair<int,pair<int, int>>>> v;
    for(int i = 1; i <= m; i++) {
        int a,b,w; cin >> a >> b >> w;
        v.push_back({w, {a, {b, i}}});
    }
    sort(v.begin(), v.end());
    int l = 0, r = v.size()-1;
    bool p=0;
    while(l<=r) {
        auto val = v[l];
        if(p) val=v[r];
        if(join(val.second.first, val.second.second.first)) {
            cout << val.second.second.second << " ";
        }
        if(!p) l++; else r--;
        p=!p;
    }
    cout << endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    for(int test = 1; test <= 10; test++) {
        string s = (test<10?"0":"") + to_string(test);
        freopen(("test."+s+".in").c_str(), "r", stdin);
        freopen(("test."+s+".out").c_str(), "w", stdout);
        int t; cin >> t; while(t--) solve();
    }
}