#pragma GCC optimize("Ofast")
#pragma GCC target("avx2")

#include <iostream>
#include <cstring>
#include <random>
#include <ctime>
#include <fstream>
#include <stack>
#include <algorithm>
#include <unordered_set>
#include <set>
#include <unordered_map>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;

int par[10000];
int sz[10000];

template<class T>
using ordered_set = __gnu_pbds::tree<T, __gnu_pbds::null_type, less<T>, __gnu_pbds::rb_tree_tag, __gnu_pbds::tree_order_statistics_node_update>;
mt19937 mt(random_device{}());

inline int findpar(int k) {
    if(par[k]==k) return k;
    return par[k]=findpar(par[k]);
}

inline bool join(int a, int b) {
    a=findpar(a), b=findpar(b);
    if(a==b) return 0;
    if(sz[b]>sz[a]) swap(a, b);
    par[b]=a;
    sz[a]+=sz[b];
    return 1;
}

void solve() {
    int n,m;
    cin >> n >> m;
    for(int i = 1; i <= n; i++) {sz[i]=1;par[i]=i;}
    vector<pair<int, pair<int,pair<int, int>>>> v;
    for(int i = 1; i <= m; i++) {
        int a,b,w; cin >> a >> b >> w;
        v.push_back({w, {a, {b, i}}});
    }

    vector<pair<int,vector<int>>> all;

    const int br = 1e8/n;
    for(int it = 0; it < br; it++) {
        for(int i = 1; i <= n; i++) {sz[i]=1;par[i]=i;}
        shuffle(v.begin(), v.end(), mt);
        int ans=0; vector<int> currv;
        for(int i = 0; i < v.size(); i++) {
            if(join(v[i].second.first, v[i].second.second.first)) {
                currv.push_back(v[i].second.second.second);
                ans+=v[i].first;
            }
        }
        all.push_back({ans, currv});
    }
    sort(all.begin(), all.end());
    for(auto &x : all[(all.size()*67)/100].second) cout << x << " ";
    cout << endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    for(int test = 1; test <= 10; test++) {
        string s = (test<10?"0":"") + to_string(test);
        freopen(("test."+s+".in").c_str(), "r", stdin);
        freopen(("test."+s+".out").c_str(), "w", stdout);
        int t; cin >> t; while(t--) solve();
    }
}