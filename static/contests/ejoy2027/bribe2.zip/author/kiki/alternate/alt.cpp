#include <bits/stdc++.h>
using namespace std;
const int maxn = 5e3 + 7;
int lead[maxn];
int sz[maxn];
struct node
{
    int x;
    int y;
    int w;
    int ind;
};
void filllead()
{
    for (int i = 0; i < maxn; i++)
    {
        lead[i] = i;
        sz[i] = 1;
    }
    return;
}
int findlead(int u)
{
    if (lead[u] == u)
        return u;
    return lead[u] = findlead(lead[u]);
}
void unite(int x, int y)
{
    int leadx = findlead(x);
    int leady = findlead(y);
    if (sz[leadx] < sz[leady])
    {
        lead[leadx] = leady;
        sz[leady] += sz[leadx];
    }
    else
    {
        lead[leady] = leadx;
        sz[leadx] += sz[leady];
    }

    return;
}
bool cmp(node a, node b)
{
    return a.w < b.w;
}
void solve()
{
    int n, m;
    cin >> n >> m;
    vector<node> edges;
    vector<int> mst;

    int sum = 0;
    int sum2 = 0;
    for (int i = 1; i <= m; i++)
    {
        int x, y, w;
        cin >> x >> y >> w;
        edges.push_back({x, y, w, i});
    }
    sort(edges.begin(), edges.end(), cmp);
    int l = 0;
    int r = edges.size() - 1;
    filllead();
    while (true)
    {
        if (l > r)
            break;
        node z = edges[l];
        if (findlead(z.x) != findlead(z.y))
        {
            unite(z.x, z.y);
            mst.push_back(z.ind);
        }
        if (r != l)
        {
            z = edges[r];
            if (findlead(z.x) != findlead(z.y))
            {
                unite(z.x, z.y);
                mst.push_back(z.ind);
            }
        }
        l++;
        r--;
    }
    for (auto x : mst)
    {
        cout << x << endl;
    }
}
int main()
{
    for (int t = 1; t <= 10; t++)
    {
        string file = to_string(t);
        if (t < 10)
        {
            file = '0' + file;
        }
        file = "test." + file;
        string inf = file + ".in";
        string outf = file + ".out";
        freopen(inf.c_str(), "r", stdin);
        freopen(outf.c_str(), "w", stdout);
        int cnt;
        cin >> cnt;
        while (cnt--)
        {
            solve();
        }
    }
    return 0;
}
