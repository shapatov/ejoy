// eJOY "67th percentile spanning tree" -- author solution + checker.
//   author in.file out.file          -> construct optimal outputs
//   author in.file --score sub.file  -> score an arbitrary submission (checker mode)
// Standalone: recovers blocks via biconnected components from the input alone,
// enumerates each block's exact spanning-tree weight distribution, convolves them
// EXACTLY (dense DP or FFT fast-power over repeated identical distributions),
// then constructs a tree whose weight has CDF closest to 0.67.
#include <bits/stdc++.h>
#include <cassert>
using namespace std;
typedef long long ll;
typedef vector<double> vd;
const double Q = 0.67;

// ---------------- FFT ----------------
typedef complex<double> cd;
void fft(vector<cd>&a, bool inv){
  int n=a.size();
  for(int i=1,j=0;i<n;i++){ int bit=n>>1;
    for(;j&bit;bit>>=1) j^=bit; j^=bit; if(i<j) swap(a[i],a[j]); }
  for(int len=2;len<=n;len<<=1){
    double ang=2*M_PI/len*(inv?-1:1); cd wl(cos(ang),sin(ang));
    for(int i=0;i<n;i+=len){ cd w(1);
      for(int j=0;j<len/2;j++){ cd u=a[i+j],v=a[i+j+len/2]*w;
        a[i+j]=u+v; a[i+j+len/2]=u-v; w*=wl; } } }
  if(inv) for(auto&x:a) x/=n;
}
vd conv(const vd&a,const vd&b){
  size_t rs=a.size()+b.size()-1;
  if((double)a.size()*b.size()<=4e6){ // naive for small
    vd r(rs,0.0);
    for(size_t i=0;i<a.size();i++){ double ai=a[i]; if(ai==0) continue;
      for(size_t j=0;j<b.size();j++) r[i+j]+=ai*b[j]; }
    return r;
  }
  size_t n=1; while(n<rs) n<<=1;
  vector<cd> fa(n,0),fb(n,0);
  for(size_t i=0;i<a.size();i++) fa[i]=a[i];
  for(size_t i=0;i<b.size();i++) fb[i]=b[i];
  fft(fa,false); fft(fb,false);
  for(size_t i=0;i<n;i++) fa[i]*=fb[i];
  fft(fa,true);
  vd r(rs); double s=0;
  for(size_t i=0;i<rs;i++){ double v=fa[i].real(); r[i]=v>0?v:0; s+=r[i]; }
  for(auto&v:r) v/=s;                       // renormalize (prob mass = 1)
  return r;
}
vd powdist(vd p,ll k){                       // p convolved with itself k times
  vd r(1,1.0);
  while(k){ if(k&1) r=conv(r,p); k>>=1; if(k) p=conv(p,p); }
  return r;
}

// ---------------- BCC (iterative) ----------------
struct BCC {
  int n; vector<vector<pair<int,int>>> adj; // (to, edge id)
  vector<int> disc, low; vector<vector<int>> blocks;
  BCC(int n_, const vector<array<int,3>>&E):n(n_),adj(n_),disc(n_,-1),low(n_){
    for(int i=0;i<(int)E.size();i++){ adj[E[i][0]].push_back({E[i][1],i}); adj[E[i][1]].push_back({E[i][0],i}); }
    vector<int> estk; int timer=0;
    vector<tuple<int,int,size_t>> stk; // node, parent edge, iterator
    for(int s=0;s<n;s++){
      if(disc[s]!=-1) continue;
      stk.push_back({s,-1,0}); disc[s]=low[s]=timer++;
      while(!stk.empty()){
        auto&[u,pe,it]=stk.back();
        if(it<adj[u].size()){
          auto[v,id]=adj[u][it++];
          if(id==pe) continue;
          if(disc[v]==-1){
            estk.push_back(id); disc[v]=low[v]=timer++;
            stk.push_back({v,id,0});
          } else if(disc[v]<disc[u]){ estk.push_back(id); low[u]=min(low[u],disc[v]); }
        } else {
          stk.pop_back();
          if(!stk.empty()){
            int p=get<0>(stk.back()); low[p]=min(low[p],low[u]);
            if(low[u]>=disc[p]){    // pop one block
              blocks.push_back({});
              while(true){ int id=estk.back(); estk.pop_back();
                blocks.back().push_back(id); if(id==pe) break; }
            }
          }
        }
      }
    }
  }
};

// ---------------- block enumeration ----------------
struct Dist { vector<int> vals; vector<double> probs; vector<ll> cnts; int mn, mx; };
// enumerate spanning trees of a small block; optionally stop at first tree of weight 'want'
bool enum_block(const vector<array<int,3>>&E, const vector<int>&ids,
                map<int,ll>*wc, int want, vector<int>*rep){
  int m=ids.size(); vector<int> vmap; vector<array<int,3>> le;
  for(int id:ids){ vmap.push_back(E[id][0]); vmap.push_back(E[id][1]); }
  sort(vmap.begin(),vmap.end()); vmap.erase(unique(vmap.begin(),vmap.end()),vmap.end());
  int V=vmap.size();
  auto lv=[&](int g){ return lower_bound(vmap.begin(),vmap.end(),g)-vmap.begin(); };
  for(int id:ids) le.push_back({(int)lv(E[id][0]),(int)lv(E[id][1]),E[id][2]});
  if(V==1) return false;                    // shouldn't happen
  int k=V-1;
  if(m==V){                                  // pure cycle: tree = omit one edge
    ll S=0; for(auto&x:le) S+=x[2];
    for(int i=0;i<m;i++){ int w=(int)(S-le[i][2]);
      if(wc) (*wc)[w]++;
      if(rep && w==want){ rep->clear();
        for(int j=0;j<m;j++) if(j!=i) rep->push_back(ids[j]);
        return true; } }
    return false;
  }
  if(m>24){ fprintf(stderr,"block too large (%d edges)\n",m); exit(1); }
  vector<int> c(k); iota(c.begin(),c.end(),0);
  int par[32];
  while(true){
    for(int i=0;i<V;i++) par[i]=i;
    bool ok=true; int w=0;
    for(int i=0;i<k;i++){ int a=le[c[i]][0],b=le[c[i]][1];
      while(par[a]!=a)a=par[a]=par[par[a]]; while(par[b]!=b)b=par[b]=par[par[b]];
      if(a==b){ok=false;break;} par[a]=b; w+=le[c[i]][2]; }
    if(ok){
      if(wc) (*wc)[w]++;
      if(rep && w==want){ rep->clear(); for(int i=0;i<k;i++) rep->push_back(ids[c[i]]); return true; }
    }
    int i=k-1; while(i>=0 && c[i]==m-k+i) i--;
    if(i<0) break; c[i]++; for(int j=i+1;j<k;j++) c[j]=c[j-1]+1;
  }
  return false;
}

// ---------------- per-subtest solve ----------------
struct Sub { int n; vector<array<int,3>> E; };

struct Solved {
  vd dp; ll base;                            // exact pmf over weights base..base+|dp|-1
  vector<vector<int>> blocks; vector<int> grp; vector<Dist> dists;
};

Solved analyze(const Sub&s){
  Solved R;
  BCC bcc(s.n, s.E);
  R.blocks = bcc.blocks;
  map<vector<ll>,int> gid;
  for(auto&blk:R.blocks){
    map<int,ll> wc; enum_block(s.E,blk,&wc,-1,nullptr);
    vector<ll> key; for(auto&[v,c]:wc){ key.push_back(v); key.push_back(c); }
    auto it=gid.find(key);
    if(it==gid.end()){
      int id=R.dists.size(); gid[key]=id;
      Dist d; ll tot=0; for(auto&[v,c]:wc){ d.vals.push_back(v); d.cnts.push_back(c); tot+=c; }
      for(ll c:d.cnts) d.probs.push_back((double)c/tot);
      d.mn=d.vals.front(); d.mx=d.vals.back();
      R.dists.push_back(d); R.grp.push_back(id);
    } else R.grp.push_back(it->second);
  }
  // exact convolution
  R.base=0; ll S=0; vector<ll> kcnt(R.dists.size(),0);
  for(size_t i=0;i<R.blocks.size();i++){ const Dist&d=R.dists[R.grp[i]]; R.base+=d.mn; S+=d.mx-d.mn; kcnt[R.grp[i]]++; }
  if(S<=1200000 && (ll)R.blocks.size()<=1500){   // dense sequential path
    vd dp(1,1.0);
    for(size_t i=0;i<R.blocks.size();i++){
      const Dist&d=R.dists[R.grp[i]]; int sp=d.mx-d.mn;
      if(sp==0) continue;
      vd nw(dp.size()+sp,0.0);
      for(size_t j=0;j<d.vals.size();j++){ int off=d.vals[j]-d.mn; double p=d.probs[j];
        for(size_t x=0;x<dp.size();x++) nw[x+off]+=p*dp[x]; }
      dp.swap(nw);
    }
    R.dp=dp;
  } else {                                   // FFT: power per group, then D&C merge
    vector<vd> parts;
    for(size_t g=0;g<R.dists.size();g++){
      const Dist&d=R.dists[g]; if(kcnt[g]==0 || d.mx==d.mn) continue;
      vd p(d.mx-d.mn+1,0.0);
      for(size_t j=0;j<d.vals.size();j++) p[d.vals[j]-d.mn]=d.probs[j];
      parts.push_back(powdist(p,kcnt[g]));
    }
    if(parts.empty()) R.dp=vd(1,1.0);
    else{
      // D&C merge, smallest first
      auto cmp=[](const vd&a,const vd&b){ return a.size()>b.size(); };
      priority_queue<vd,vector<vd>,decltype(cmp)> pq(cmp);
      for(auto&p:parts) pq.push(move(p));
      while(pq.size()>1){ vd a=pq.top();pq.pop(); vd b=pq.top();pq.pop(); pq.push(conv(a,b)); }
      R.dp=pq.top();
    }
  }
  double sum=0; for(double v:R.dp) sum+=v;
  for(double&v:R.dp) v/=sum;
  return R;
}

// pick per-block weights summing to target; returns (achieved, choice)
pair<ll,vector<int>> construct(const Solved&R, ll target, mt19937&rng){
  int NI=R.blocks.size();
  ll S=(ll)R.dp.size()-1;
  vector<int> ch(NI); ll tot=0;
  for(int i=0;i<NI;i++){ const Dist&d=R.dists[R.grp[i]];
    // init at value nearest the block mean
    double mu=0; for(size_t j=0;j<d.vals.size();j++) mu+=d.vals[j]*d.probs[j];
    int best=d.vals[0]; for(int v:d.vals) if(fabs(v-mu)<fabs(best-mu)) best=v;
    ch[i]=best; tot+=best; }
  ll D=target-tot;
  // exact bitset reconstruction when affordable (guaranteed hit)
  if((ll)NI*(S+1)<=6e8 && NI<=1000){
    int W=(S+64)/64+1;
    vector<vector<uint64_t>> pre(NI+1, vector<uint64_t>(W,0));
    pre[0][0]=1;
    vector<ll> pmin(NI+1,0);
    for(int i=0;i<NI;i++){ const Dist&d=R.dists[R.grp[i]]; pmin[i+1]=pmin[i]+d.mn;
      auto&cur=pre[i+1]; auto&prv=pre[i];
      for(int v:d.vals){ int off=v-d.mn; int wsh=off/64, bsh=off%64;
        for(int w=W-1;w>=0;w--){ uint64_t x=0;
          if(w-wsh>=0){ x=prv[w-wsh]<<bsh; if(bsh && w-wsh-1>=0) x|=prv[w-wsh-1]>>(64-bsh); }
          cur[w]|=x; } } }
    ll need=target-R.base;                    // offset from Σ per-block minima == R.base... careful: offsets accumulate vs pmin
    // pre[i] holds sums offset by pmin[i]; overall offset pmin[NI]=Σ mn = base
    if(need>=0 && need<=S && (pre[NI][need/64]>>(need%64)&1)){
      ll rem=need;
      for(int i=NI-1;i>=0;i--){ const Dist&d=R.dists[R.grp[i]];
        for(int v:d.vals){ ll r2=rem-(v-d.mn);
          if(r2>=0 && (pre[i][r2/64]>>(r2%64)&1)){ ch[i]=v; rem=r2; break; } } }
      return {target,ch};
    }
  }
  // greedy sweeps
  for(int pass=0;pass<4&&D;pass++)
    for(int i=0;i<NI&&D;i++){ const Dist&d=R.dists[R.grp[i]];
      ll want=ch[i]+D;
      auto it=lower_bound(d.vals.begin(),d.vals.end(),want);
      int best=ch[i];
      for(int t=0;t<2;t++,--it){ if(it!=d.vals.end()&&it>=d.vals.begin()){
        if(llabs(D-(*it-ch[i]))<llabs(D-(best-ch[i]))) best=*it; } if(it==d.vals.begin())break; }
      if(best!=ch[i]){ D-=best-ch[i]; ch[i]=best; } }
  // random polish
  for(int it=0;it<400000&&D;it++){
    int i=rng()%NI; const Dist&d=R.dists[R.grp[i]];
    ll want=ch[i]+D;
    auto lb=lower_bound(d.vals.begin(),d.vals.end(),want);
    for(int t=0;t<2;t++){ auto p=lb; if(t) { if(p==d.vals.begin()) continue; --p; }
      if(p==d.vals.end()) continue;
      if(llabs(D-(*p-ch[i]))<llabs(D)){ D-=*p-ch[i]; ch[i]=*p; break; } } }
  // pair fix: exhaust value grid of random pairs
  for(int it=0;it<3000&&D;it++){
    int i=rng()%NI, j=rng()%NI; if(i==j) continue;
    const Dist&di=R.dists[R.grp[i]], &dj=R.dists[R.grp[j]];
    for(int vi:di.vals){ ll need=ch[j]+(D-(vi-ch[i]));
      auto p=lower_bound(dj.vals.begin(),dj.vals.end(),need);
      if(p!=dj.vals.end()&&*p==need){ D-= (vi-ch[i])+(*p-ch[j]); ch[i]=vi; ch[j]=*p; break; } } }
  return {target-D,ch};
}

int main(int argc,char**argv){
  if(argc<3){ fprintf(stderr,"usage: author in.file (out.file | --score sub.file)\n"); return 1; }
  FILE*fin=fopen(argv[1],"r");
  bool scoring = string(argv[2])=="--score";
  FILE*fsub = scoring? fopen(argv[3],"r") : nullptr;
  FILE*fout = scoring? nullptr : fopen(argv[2],"w");
  FILE*ftree = (!scoring && argc>=4)? fopen(argv[3],"w") : nullptr;  // optional: dump author's own submission
  int t; fscanf(fin,"%d",&t);
  mt19937 rng(424242);
  double totscore=0;
  for(int si=0;si<t;si++){
    Sub s; int m;
    if(fscanf(fin,"%d %d",&s.n,&m)!=2){ fprintf(stderr,"bad input\n"); return 1; }
    s.E.resize(m);
    for(auto&e:s.E){ fscanf(fin,"%d %d %d",&e[0],&e[1],&e[2]); e[0]--; e[1]--; }
    Solved R=analyze(s);
    // cdf + candidates
    vd cdf(R.dp.size()); double c=0;
    for(size_t i=0;i<R.dp.size();i++){ cdf[i]=c+R.dp[i]/2; c+=R.dp[i]; } // mid-CDF
    if(scoring){
      vector<int> ids(s.n-1);
      for(auto&x:ids){ fscanf(fsub,"%d",&x); x--; }
      vector<int> par(s.n); iota(par.begin(),par.end(),0);
      function<int(int)> find=[&](int x){ while(par[x]!=x){par[x]=par[par[x]];x=par[x];} return x; };
      ll w=0; bool ok=true;
      for(int id:ids){ if(id<0||id>=m){ok=false;break;}
        int a=find(s.E[id][0]),b=find(s.E[id][1]); if(a==b){ok=false;break;}
        par[a]=b; w+=s.E[id][2]; }
      if(!ok){ printf("  sub%d: INVALID tree -> score 0\n",si+1); continue; }
      double p=cdf[min<ll>(max<ll>(w-R.base,0),(ll)cdf.size()-1)];
      if(w<R.base) p=0;
      printf("  sub%d: weight=%lld cdf=%.4f  |cdf-0.67|=%.4f\n",si+1,w,p,fabs(p-Q));
      totscore+=fabs(p-Q);
      continue;
    }
    // candidates: achievable sums by closeness of cdf to Q
    vector<pair<double,ll>> cand;
    for(size_t i=0;i<R.dp.size();i++) if(R.dp[i]>1e-13) cand.push_back({fabs(cdf[i]-Q),(ll)i});
    sort(cand.begin(),cand.end());
    if(cand.size()>16) cand.resize(16);
    ll achieved=-1; vector<int> choice; double bestsc=1e18;
    for(auto&[sc,off]:cand){
      auto[a,ch]=construct(R,R.base+off,rng);
      double asc=fabs(cdf[a-R.base]-Q);
      if(asc<bestsc){ bestsc=asc; achieved=a; choice=ch; }
      if(a==R.base+off) break;
    }
    // second pass: extract a representative tree per block at chosen weight
    vector<int> outids;
    for(size_t b=0;b<R.blocks.size();b++){
      vector<int> rep;
      bool got=enum_block(s.E,R.blocks[b],nullptr,choice[b],&rep);
      assert(got);
      for(int id:rep) outids.push_back(id);
    }
    sort(outids.begin(),outids.end());
    assert((int)outids.size()==s.n-1);
    { // validate
      vector<int> par(s.n); iota(par.begin(),par.end(),0);
      function<int(int)> find=[&](int x){ while(par[x]!=x){par[x]=par[par[x]];x=par[x];} return x; };
      ll w=0; for(int id:outids){ int a=find(s.E[id][0]),b=find(s.E[id][1]); assert(a!=b); par[a]=b; w+=s.E[id][2]; }
      assert(w==achieved);
    }
    fprintf(fout,"%lld %zu\n", R.base, R.dp.size());
    for(double x : cdf) {
        fprintf(fout,"%.10g ", x);
    }
    fprintf(fout,"\n");
    if(ftree){ for(int id:outids) fprintf(ftree,"%d ",id+1); fprintf(ftree,"\n"); }
    printf("  sub%d: n=%d m=%d blocks=%zu groups=%zu span=%zu achieved-cdf=%.4f\n",
           si+1,s.n,m,R.blocks.size(),R.dists.size(),R.dp.size()-1,cdf[achieved-R.base]);
  }
  if(scoring) printf("  file avg |cdf-0.67| = %.4f\n", totscore/ (t>0?t:1));
  if(fout) fclose(fout);
  if(ftree) fclose(ftree);
  return 0;
}
