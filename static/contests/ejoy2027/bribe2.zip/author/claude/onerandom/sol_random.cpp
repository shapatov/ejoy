#include <bits/stdc++.h>
using namespace std;
FILE *fi = stdin, *fo = stdout;
mt19937 rng(1);

void solve()
{
  int n, m;
  fscanf(fi, "%d %d", &n, &m);
  vector<array<int, 3>> E(m);
  for (auto &e : E)
  {
    fscanf(fi, "%d %d %d", &e[0], &e[1], &e[2]);
    e[0]--;
    e[1]--;
  }
  vector<int> ord(m);
  iota(ord.begin(), ord.end(), 0);
  shuffle(ord.begin(), ord.end(), rng);
  vector<int> par(n), out;
  iota(par.begin(), par.end(), 0);
  function<int(int)> f = [&](int x)
  {while(par[x]!=x){par[x]=par[par[x]];x=par[x];}return x; };
  for (int e : ord)
  {
    int a = f(E[e][0]), b = f(E[e][1]);
    if (a != b)
    {
      par[a] = b;
      out.push_back(e);
    }
  }
  sort(out.begin(), out.end());
  for (size_t i = 0; i < out.size(); i++)
    fprintf(fo, "%d%c", out[i] + 1, i + 1 < out.size() ? ' ' : '\n');
}

int main()
{
  for (int test = 1; test <= 10; test++)
  {
    string s = (test < 10 ? "0" : "") + to_string(test);
    if (!freopen(("test." + s + ".in").c_str(), "r", stdin))
      continue;
    freopen(("test." + s + ".out").c_str(), "w", stdout);
    int t;
    if (!(cin >> t))
      continue;
    while (t--)
      solve();
  }
  return 0;
}