// Intermediate "found the insight" solution: BCC decomposition, exact per-block
// distributions, but target = mu + 0.4399*sigma (normal approx, no skew correction).
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
struct BCC
{
  int n;
  vector<vector<pair<int, int>>> adj;
  vector<int> disc, low;
  vector<vector<int>> blocks;
  BCC(int n_, const vector<array<int, 3>> &E) : n(n_), adj(n_), disc(n_, -1), low(n_)
  {
    for (int i = 0; i < (int)E.size(); i++)
    {
      adj[E[i][0]].push_back({E[i][1], i});
      adj[E[i][1]].push_back({E[i][0], i});
    }
    vector<int> estk;
    int timer = 0;
    vector<tuple<int, int, size_t>> stk;
    for (int s = 0; s < n; s++)
    {
      if (disc[s] != -1)
        continue;
      stk.push_back({s, -1, 0});
      disc[s] = low[s] = timer++;
      while (!stk.empty())
      {
        auto &[u, pe, it] = stk.back();
        if (it < adj[u].size())
        {
          auto [v, id] = adj[u][it++];
          if (id == pe)
            continue;
          if (disc[v] == -1)
          {
            estk.push_back(id);
            disc[v] = low[v] = timer++;
            stk.push_back({v, id, 0});
          }
          else if (disc[v] < disc[u])
          {
            estk.push_back(id);
            low[u] = min(low[u], disc[v]);
          }
        }
        else
        {
          stk.pop_back();
          if (!stk.empty())
          {
            int p = get<0>(stk.back());
            low[p] = min(low[p], low[u]);
            if (low[u] >= disc[p])
            {
              blocks.push_back({});
              while (true)
              {
                int id = estk.back();
                estk.pop_back();
                blocks.back().push_back(id);
                if (id == pe)
                  break;
              }
            }
          }
        }
      }
    }
  }
};
FILE *fi = stdin, *fo = stdout;
mt19937 rng(3);

void solve()
{
  int n, m;
  fscanf(fi, "%d %d", &n, &m);
  vector<array<int, 3>> E(m);
  for (auto &e : E)
  {
    fscanf(fi, "%d %d %d", &e[0], &e[1], &e[2]);
    e[0]--;
    e[1]--;
  }
  BCC bcc(n, E);
  int NB = bcc.blocks.size();
  vector<vector<int>> vals(NB);
  vector<vector<vector<int>>> reps(NB);
  double k1 = 0, k2 = 0;
  for (int b = 0; b < NB; b++)
  {
    auto &ids = bcc.blocks[b];
    vector<int> vm;
    for (int id : ids)
    {
      vm.push_back(E[id][0]);
      vm.push_back(E[id][1]);
    }
    sort(vm.begin(), vm.end());
    vm.erase(unique(vm.begin(), vm.end()), vm.end());
    int V = vm.size(), k = V - 1, M = ids.size();
    auto lv = [&](int g)
    { return lower_bound(vm.begin(), vm.end(), g) - vm.begin(); };
    map<int, pair<ll, vector<int>>> wc;
    vector<int> c(k);
    iota(c.begin(), c.end(), 0);
    vector<int> par(V);
    while (true)
    {
      for (int i = 0; i < V; i++)
        par[i] = i;
      bool ok = true;
      int w = 0;
      for (int i = 0; i < k; i++)
      {
        int a = lv(E[ids[c[i]]][0]), b2 = lv(E[ids[c[i]]][1]);
        while (par[a] != a)
          a = par[a] = par[par[a]];
        while (par[b2] != b2)
          b2 = par[b2] = par[par[b2]];
        if (a == b2)
        {
          ok = false;
          break;
        }
        par[a] = b2;
        w += E[ids[c[i]]][2];
      }
      if (ok)
      {
        auto &e2 = wc[w];
        e2.first++;
        if (e2.second.empty())
          for (int i = 0; i < k; i++)
            e2.second.push_back(ids[c[i]]);
      }
      int i = k - 1;
      while (i >= 0 && c[i] == M - k + i)
        i--;
      if (i < 0)
        break;
      c[i]++;
      for (int j = i + 1; j < k; j++)
        c[j] = c[j - 1] + 1;
    }
    ll tot = 0;
    for (auto &[v, pc] : wc)
      tot += pc.first;
    double mu = 0;
    for (auto &[v, pc] : wc)
    {
      mu += (double)v * pc.first / tot;
      vals[b].push_back(v);
      reps[b].push_back(pc.second);
    }
    double var = 0;
    for (auto &[v, pc] : wc)
      var += (v - mu) * (v - mu) * pc.first / tot;
    k1 += mu;
    k2 += var;
  }
  ll target = llround(k1 + 0.4399131657 * sqrt(k2));
  vector<int> ch(NB);
  ll tot = 0;
  for (int b = 0; b < NB; b++)
  {
    ch[b] = 0;
    tot += vals[b][0];
  }
  ll D = target - tot;
  for (int pass = 0; pass < 6 && D; pass++)
    for (int b = 0; b < NB && D; b++)
    {
      int cur = vals[b][ch[b]];
      ll want = cur + D;
      auto it = lower_bound(vals[b].begin(), vals[b].end(), want);
      int bi = ch[b];
      for (int s = 0; s < 2; s++)
      {
        auto p = it;
        if (s)
        {
          if (p == vals[b].begin())
            continue;
          --p;
        }
        if (p == vals[b].end())
          continue;
        if (llabs(D - (*p - cur)) < llabs(D - (vals[b][bi] - cur)))
          bi = p - vals[b].begin();
      }
      if (bi != ch[b])
      {
        D -= vals[b][bi] - cur;
        ch[b] = bi;
      }
    }
  for (int it2 = 0; it2 < 400000 && D; it2++)
  {
    int b = rng() % NB;
    int cur = vals[b][ch[b]];
    ll want = cur + D;
    auto p = lower_bound(vals[b].begin(), vals[b].end(), want);
    for (int s = 0; s < 2; s++)
    {
      auto q = p;
      if (s)
      {
        if (q == vals[b].begin())
          continue;
        --q;
      }
      if (q == vals[b].end())
        continue;
      if (llabs(D - (*q - cur)) < llabs(D))
      {
        D -= *q - cur;
        ch[b] = q - vals[b].begin();
        break;
      }
    }
  }
  vector<int> out;
  for (int b = 0; b < NB; b++)
    for (int id : reps[b][ch[b]])
      out.push_back(id);
  sort(out.begin(), out.end());
  for (size_t i = 0; i < out.size(); i++)
    fprintf(fo, "%d%c", out[i] + 1, i + 1 < out.size() ? ' ' : '\n');
}

int main()
{
  for (int test = 1; test <= 10; test++)
  {
    string s = (test < 10 ? "0" : "") + to_string(test);
    if (!freopen(("test." + s + ".in").c_str(), "r", stdin))
      continue;
    freopen(("test." + s + ".out").c_str(), "w", stdout);
    int t;
    if (!(cin >> t))
      continue;
    while (t--)
      solve();
  }
  return 0;
}