// Reference PARTIAL solution: sample random-Kruskal trees, aim at the sampled P67.
// This is what a contestant without the block-decomposition insight submits.
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
FILE *fin = stdin, *fout = stdout;
mt19937 rng(777);

void solve()
{
  int n, m;
  fscanf(fin, "%d %d", &n, &m);
  vector<array<int, 3>> E(m);
  for (auto &e : E)
  {
    fscanf(fin, "%d %d %d", &e[0], &e[1], &e[2]);
    e[0]--;
    e[1]--;
  }
  int NS = max(400, min(4000, (int)(3e8 / max(m, 1))));
  vector<int> ord(m);
  iota(ord.begin(), ord.end(), 0);
  vector<int> par(n);
  auto sample = [&](vector<int> *tree) -> ll
  {
    shuffle(ord.begin(),ord.end(),rng);
    iota(par.begin(),par.end(),0);
    ll w=0; int c=0; if(tree) tree->clear();
    for(int e:ord){ int a=E[e][0],b=E[e][1];
      while(par[a]!=a)a=par[a]=par[par[a]]; while(par[b]!=b)b=par[b]=par[par[b]];
      if(a!=b){ par[a]=b; w+=E[e][2]; if(tree)tree->push_back(e); if(++c==n-1)break; } }
    return w; };
  vector<ll> ws(NS);
  for (auto &w : ws)
    w = sample(nullptr);
  sort(ws.begin(), ws.end());
  ll target;
  {
    vector<array<int, 4>> S(m);
    for (int i = 0; i < m; i++)
    {
      S[i] = {E[i][0], E[i][1], E[i][2], i};
    }
    sort(S.begin(), S.end(), [](auto &a, auto &b)
         { return a[2] < b[2]; });
    auto span = [&](bool mx) -> ll
    { vector<int> p(n); iota(p.begin(),p.end(),0); function<int(int)> f=[&](int x){while(p[x]!=x){p[x]=p[p[x]];x=p[x];}return x;}; ll w=0; if(mx) reverse(S.begin(),S.end()); for(auto&e:S){int a=f(e[0]),b=f(e[1]); if(a!=b){p[a]=b;w+=e[2];}} if(mx) reverse(S.begin(),S.end()); return w; };
    ll lo = span(false), hi = span(true);
    target = lo + llround(0.67 * (double)(hi - lo));
  }
  vector<int> best, cur;
  ll bd = LLONG_MAX;
  for (int i = 0; i < NS; i++)
  {
    ll w = sample(&cur);
    if (llabs(w - target) < bd)
    {
      bd = llabs(w - target);
      best = cur;
      if (!bd)
        break;
    }
  }
  sort(best.begin(), best.end());
  for (size_t i = 0; i < best.size(); i++)
    fprintf(fout, "%d%c", best[i] + 1, i + 1 < best.size() ? ' ' : '\n');
}

int main()
{
  for (int test = 1; test <= 10; test++)
  {
    string s = (test < 10 ? "0" : "") + to_string(test);
    if (!freopen(("test." + s + ".in").c_str(), "r", stdin))
      continue;
    freopen(("test." + s + ".out").c_str(), "w", stdout);
    int t;
    if (!(cin >> t))
      continue;
    while (t--)
      solve();
  }
  return 0;
}