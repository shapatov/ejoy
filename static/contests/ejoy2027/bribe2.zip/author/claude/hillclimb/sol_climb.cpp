// Mode hardcoded below (was previously argv[1] = hc_range | hc_p67 | sa_p67 | sa_range).
// Change MODE to switch variants.
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const string MODE = "hc_range";
const bool sa = (MODE == "sa_p67" || MODE == "sa_range");
const bool rangeT = (MODE == "hc_range" || MODE == "sa_range");

mt19937 rng(9);
int n, m;
vector<array<int, 3>> E;
vector<char> intree;
vector<vector<pair<int, int>>> adj; // tree adjacency: (to, edge id)
FILE *fi = stdin, *fo = stdout;
int T0 = 1; // set per input file to the file's subtest count, used to scale compute budget

ll randtree(vector<int> &ord)
{
  shuffle(ord.begin(), ord.end(), rng);
  vector<int> p(n);
  iota(p.begin(), p.end(), 0);
  function<int(int)> f = [&](int x)
  {while(p[x]!=x){p[x]=p[p[x]];x=p[x];}return x; };
  fill(intree.begin(), intree.end(), 0);
  ll w = 0;
  int c = 0;
  for (int e : ord)
  {
    int a = f(E[e][0]), b = f(E[e][1]);
    if (a != b)
    {
      p[a] = b;
      intree[e] = 1;
      w += E[e][2];
      if (++c == n - 1)
        break;
    }
  }
  adj.assign(n, {});
  for (int e = 0; e < m; e++)
    if (intree[e])
    {
      adj[E[e][0]].push_back({E[e][1], e});
      adj[E[e][1]].push_back({E[e][0], e});
    }
  return w;
}
vector<int> pv, pe;
vector<int> stamp;
int curstamp = 0;
bool path(int u, int v)
{ // BFS on tree u->v filling pv/pe; returns true
  curstamp++;
  stamp[u] = curstamp;
  pv[u] = -1;
  static vector<int> q;
  q.clear();
  q.push_back(u);
  for (size_t i = 0; i < q.size(); i++)
  {
    int x = q[i];
    if (x == v)
      return true;
    for (auto [y, id] : adj[x])
      if (stamp[y] != curstamp)
      {
        stamp[y] = curstamp;
        pv[y] = x;
        pe[y] = id;
        q.push_back(y);
      }
  }
  return stamp[v] == curstamp;
}
void dropadj(int u, int id)
{
  auto &a = adj[u];
  for (size_t i = 0; i < a.size(); i++)
    if (a[i].second == id)
    {
      a[i] = a.back();
      a.pop_back();
      return;
    }
}

void solve()
{
  fscanf(fi, "%d %d", &n, &m);
  E.resize(m);
  intree.assign(m, 0);
  pv.assign(n, 0);
  pe.assign(n, 0);
  stamp.assign(n, 0);
  curstamp = 0;
  for (auto &e : E)
  {
    fscanf(fi, "%d %d %d", &e[0], &e[1], &e[2]);
    e[0]--;
    e[1]--;
  }
  vector<int> ord(m);
  iota(ord.begin(), ord.end(), 0);
  ll target;
  if (rangeT)
  {
    vector<int> ix(m);
    iota(ix.begin(), ix.end(), 0);
    sort(ix.begin(), ix.end(), [&](int a, int b)
         { return E[a][2] < E[b][2]; });
    auto span = [&](bool mx) -> ll
    { vector<int> p(n); iota(p.begin(),p.end(),0);
        function<int(int)> f=[&](int x){while(p[x]!=x){p[x]=p[p[x]];x=p[x];}return x;};
        ll w=0; if(mx) reverse(ix.begin(),ix.end());
        for(int e:ix){ int a=f(E[e][0]),b=f(E[e][1]); if(a!=b){p[a]=b;w+=E[e][2];} }
        if(mx) reverse(ix.begin(),ix.end()); return w; };
    ll lo = span(false), hi = span(true);
    target = lo + llround(0.67 * (hi - lo));
  }
  else
  {
    int NS = max(300, min(3000, (int)(1.5e8 / max(m, 1) / T0)));
    vector<ll> ws(NS);
    for (auto &w : ws)
      w = randtree(ord);
    sort(ws.begin(), ws.end());
    target = ws[(int)(0.67 * NS)];
  }
  ll W = randtree(ord);
  double temp = max<double>(llabs(W - target) / 8.0, 1.0);
  ll ops = 0, budget = (ll)(2.5e8) / T0;
  vector<int> nont;
  for (int e = 0; e < m; e++)
    if (!intree[e])
      nont.push_back(e);
  uniform_real_distribution<double> ur(0, 1);
  int stag = 0;
  vector<char> bestTree = intree;
  ll bestWglob = W;
  while (W != target && ops < budget && (sa || stag < 800))
  {
    int ei = rng() % nont.size();
    int e = nont[ei];
    if (intree[e])
    {
      nont[ei] = nont.back();
      nont.pop_back();
      continue;
    }
    int u = E[e][0], v = E[e][1];
    if (!path(u, v))
    {
      stag++;
      continue;
    }
    int bestf = -1;
    ll bestW = 0;
    double bestd = 1e18;
    for (int x = v; pv[x] != -1; x = pv[x])
    {
      ops++;
      ll W2 = W + E[e][2] - E[pe[x]][2];
      double d = llabs(W2 - target);
      if (d < bestd)
      {
        bestd = d;
        bestf = pe[x];
        bestW = W2;
      }
    }
    ops += n / 4;
    double cur = llabs(W - target);
    bool acc = bestf >= 0 && (bestd < cur || (sa && ur(rng) < exp(-(bestd - cur) / temp)));
    if (sa)
      temp = max(1.0, temp * 0.999);
    if (acc)
    {
      intree[e] = 1;
      intree[bestf] = 0;
      dropadj(E[bestf][0], bestf);
      dropadj(E[bestf][1], bestf);
      adj[u].push_back({v, e});
      adj[v].push_back({u, e});
      nont[ei] = bestf;
      W = bestW;
      if (llabs(W - target) < llabs(bestWglob - target))
      {
        bestWglob = W;
        bestTree = intree;
      }
      if (bestd < cur)
        stag = 0;
    }
    else
      stag++;
  }
  if (sa)
    intree = bestTree;
  vector<int> out;
  for (int e = 0; e < m; e++)
    if (intree[e])
      out.push_back(e);
  for (size_t i = 0; i < out.size(); i++)
    fprintf(fo, "%d%c", out[i] + 1, i + 1 < out.size() ? ' ' : '\n');
}

int main()
{
  for (int test = 1; test <= 10; test++)
  {
    string s = (test < 10 ? "0" : "") + to_string(test);
    if (!freopen(("test." + s + ".in").c_str(), "r", stdin))
      continue;
    freopen(("test." + s + ".out").c_str(), "w", stdout);
    int t;
    if (!(cin >> t))
      continue;
    T0 = max(t, 1);
    while (t--)
      solve();
  }
  return 0;
}