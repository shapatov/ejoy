#include <bits/stdc++.h>
using namespace std;
FILE *fi = stdin, *fo = stdout;

void solve()
{
  int n, m;
  fscanf(fi, "%d %d", &n, &m);
  vector<array<int, 4>> E(m);
  for (int i = 0; i < m; i++)
  {
    fscanf(fi, "%d %d %d", &E[i][0], &E[i][1], &E[i][2]);
    E[i][0]--;
    E[i][1]--;
    E[i][3] = i;
  }
  sort(E.begin(), E.end(), [](auto &a, auto &b)
       { return a[2] < b[2]; });
  vector<int> par(n), out;
  iota(par.begin(), par.end(), 0);
  function<int(int)> f = [&](int x)
  {while(par[x]!=x){par[x]=par[par[x]];x=par[x];}return x; };
  for (auto &e : E)
  {
    int a = f(e[0]), b = f(e[1]);
    if (a != b)
    {
      par[a] = b;
      out.push_back(e[3]);
    }
  }
  sort(out.begin(), out.end());
  for (size_t i = 0; i < out.size(); i++)
    fprintf(fo, "%d%c", out[i] + 1, i + 1 < out.size() ? ' ' : '\n');
}

int main()
{
  for (int test = 1; test <= 10; test++)
  {
    string s = (test < 10 ? "0" : "") + to_string(test);
    if (!freopen(("test." + s + ".in").c_str(), "r", stdin))
      continue;
    freopen(("test." + s + ".out").c_str(), "w", stdout);
    int t;
    if (!(cin >> t))
      continue;
    while (t--)
      solve();
  }
  return 0;
}