#include <bits/stdc++.h>
using namespace std;

using ll = long long;

struct Edge {
    int u, v;
    int w;
};

struct DSU {
    vector<int> p, sz;

    DSU(int n = 0) {
        p.resize(n);
        sz.assign(n, 1);
        iota(p.begin(), p.end(), 0);
    }

    int find(int x) {
        while (p[x] != x) {
            p[x] = p[p[x]];
            x = p[x];
        }
        return x;
    }

    bool unite(int a, int b) {
        a = find(a);
        b = find(b);

        if (a == b)
            return false;

        if (sz[a] < sz[b])
            swap(a, b);

        p[b] = a;
        sz[a] += sz[b];
        return true;
    }

    bool connected() {
        int r = find(0);
        for (int i = 1; i < (int)p.size(); i++)
            if (find(i) != r)
                return false;
        return true;
    }
};


int main(int argc, char **argv) {
    if (argc != 4) {
        cerr << "Wrong checker arguments\n";
        return 1;
    }

    string input_file = argv[1];
    string answer_file = argv[2];
    string output_file = argv[3];

    ifstream fin(input_file);
    ifstream fans(answer_file);
    ifstream fout(output_file);

    if (!fin) {
        cerr << "Cannot open input\n";
        return 1;
    }

    if (!fans) {
        cerr << "Cannot open answer\n";
        return 1;
    }

    if (!fout) {
        cerr << "Cannot open contestant output\n";
        return 1;
    }


    int T;
    fin >> T;

    double totalScore = 1;

    for (int tc = 0; tc < T; tc++) {
        int n, m;
        fin >> n >> m;

        vector<Edge> e(m);

        for (auto &x : e) {
            fin >> x.u >> x.v >> x.w;
            x.u--;
            x.v--;
        }


        // read official CDF
        ll base;
        int cdfSize;

        if (!(fans >> base >> cdfSize)) {
            cerr << "Error reading answer\n";
            return 1;
        }

        vector<double> cdf(cdfSize);

        for (double &x : cdf) {
            fans >> x;
        }


        vector<int> chosen;

        for (int i = 0; i < n - 1; i++) {
            int id;

            if (!(fout >> id)) {
                cerr << "Wrong format on subtest " << tc + 1 << "\n";
                cout << 0.0 << "\n";
                return 0;
            }

            chosen.push_back(id - 1);
        }


        DSU dsu(n);

        bool ok = true;
        ll weight = 0;


        for (int id : chosen) {
            if (id < 0 || id >= m) {
                ok = false;
                break;
            }

            if (!dsu.unite(e[id].u, e[id].v)) {
                ok = false;
                break;
            }

            weight += e[id].w;
        }


        if (!dsu.connected())
            ok = false;


        double score = 0;

        if (!ok) {
            cerr << "Invalid tree on subtest " << tc + 1 << "\n";
            score = 0;
        }
        else {
            double p;

            if (weight < base) {
                p = 0;
            }
            else {
                ll idx = weight - base;

                if (idx >= cdfSize)
                    p = 1;
                else
                    p = cdf[idx];
            }


            score = 1.0 - fabs(p - 0.67) / 0.33;

            if (score < 0)
                score = 0;

            if (score > 1)
                score = 1;
        }


        totalScore = min(totalScore, score);
    }



    cout << fixed << setprecision(2) << totalScore << "\n";

    return 0;
}