// PREVIOUS generator, kept for reference. Superseded by gen.cpp.
// v2 suite: coarse/tie/ladder archetypes with per-solution calibration dials.
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
mt19937 rng;
int ri(int a,int b){ return uniform_int_distribution<int>(a,b)(rng); }
struct Sub { int n; vector<array<int,3>> E; };

// tie-cycle: L edges, k tied at weight a (omitting one -> MAX tree, mass k/L), rest at a+g
void addcyc_tie(Sub&s,int L,int k,int a,int g){
  int st=s.n? ri(0,s.n-1) : (s.n=1,0);
  vector<int> w(L,a+g); for(int i=0;i<k;i++) w[i]=a;
  shuffle(w.begin(),w.end(),rng);
  int prev=st;
  for(int i=0;i<L-1;i++){ s.E.push_back({prev,s.n,w[i]}); prev=s.n++; }
  s.E.push_back({prev,st,w[L-1]});
}
// ladder cycle: arithmetic (pw=1) or convex (pw>1) weight spread
void addcyc_ladder(Sub&s,int L,int base,int d,double pw){
  int st=s.n? ri(0,s.n-1) : (s.n=1,0);
  vector<int> w(L); for(int i=0;i<L;i++) w[i]=base+(int)llround(d*L*pow((double)i/(L-1),pw));
  shuffle(w.begin(),w.end(),rng);
  int prev=st;
  for(int i=0;i<L-1;i++){ s.E.push_back({prev,s.n,w[i]}); prev=s.n++; }
  s.E.push_back({prev,st,w[L-1]});
}

void addcyc_tie3(Sub&s,int L,int a,int h2){
  int st=s.n? uniform_int_distribution<int>(0,s.n-1)(rng) : (s.n=1,0);
  int h1=(int)llround(.33*h2);
  vector<int> w(L,a);
  int n1=(int)llround(.24*L), n2=(int)llround(.10*L);
  for(int i=0;i<n1;i++) w[i]=a+h1;
  for(int i=n1;i<n1+n2;i++) w[i]=a+h2;
  shuffle(w.begin(),w.end(),rng);
  int prev=st;
  for(int i=0;i<L-1;i++){ s.E.push_back({prev,s.n,w[i]}); prev=s.n++; }
  s.E.push_back({prev,st,w[L-1]});
}

void addcyc_rare(Sub&s,int L,int a,int g,double minfrac){
  int st=s.n? uniform_int_distribution<int>(0,s.n-1)(rng) : (s.n=1,0);
  int h=(int)llround(.33*g);
  int k=(int)llround(minfrac*L);
  vector<int> w(L,a+g);
  for(int i=0;i<k;i++) w[i]=a;
  w[k]=a+h; // the single rare edge
  shuffle(w.begin(),w.end(),rng);
  int prev=st;
  for(int i=0;i<L-1;i++){ s.E.push_back({prev,s.n,w[i]}); prev=s.n++; }
  s.E.push_back({prev,st,w[L-1]});
}
void addtheta(Sub&s,int l3,int wl){ // bias gadget
  int A=s.n? ri(0,s.n-1) : (s.n=1,0); int B=s.n++;
  int lens[3]={2,3,l3}, ws[3]={wl,wl,1};
  for(int p=0;p<3;p++){ int prev=A;
    for(int j=0;j<lens[p]-1;j++){ s.E.push_back({prev,s.n,ws[p]}); prev=s.n++; }
    s.E.push_back({prev,B,ws[p]}); }
}
void shuf(Sub&s){
  vector<int> vp(s.n); iota(vp.begin(),vp.end(),0); shuffle(vp.begin(),vp.end(),rng);
  shuffle(s.E.begin(),s.E.end(),rng);
  for(auto&e:s.E){ int u=vp[e[0]],v=vp[e[1]]; if(ri(0,1))swap(u,v); e[0]=u;e[1]=v; }
}
void write(int fi, vector<Sub>&subs){
  char fn[64]; sprintf(fn,"tests2/%02d.in",fi);
  FILE*f=fopen(fn,"w"); fprintf(f,"%d\n",(int)subs.size());
  ll sn=0,sm=0;
  for(auto&s:subs){ fprintf(f,"%d %d\n",s.n,(int)s.E.size());
    for(auto&e:s.E) fprintf(f,"%d %d %d\n",e[0]+1,e[1]+1,e[2]); sn+=s.n; sm+=s.E.size(); }
  fclose(f); printf("f%02d t=%d sum_n=%lld sum_m=%lld\n",fi,(int)subs.size(),sn,sm);
}
int main(){
  // t1: tiny brute-forceable
  rng.seed(9001); { vector<Sub> v;
    for(int i=0;i<10;i++){ int n=ri(5,8), m=ri(n,min(12,n*(n-1)/2));
      Sub s; s.n=n; set<pair<int,int>> have;
      for(int x=1;x<n;x++){ int u=ri(0,x-1); s.E.push_back({u,x,ri(1,1000)}); have.insert({min(u,x),max(u,x)}); }
      vector<pair<int,int>> rest; for(int a=0;a<n;a++)for(int b=a+1;b<n;b++) if(!have.count({a,b})) rest.push_back({a,b});
      shuffle(rest.begin(),rest.end(),rng);
      for(auto&p:rest){ if((int)s.E.size()>=m)break; s.E.push_back({p.first,p.second,ri(1,1000)}); }
      shuf(s); v.push_back(s); } write(1,v); }
  // t2,t3: single tie-cycle, mass at max = 0.66 (idx67/naive/climbers all tuned to ace)
  for(int fi=2;fi<=3;fi++){ rng.seed(9000+fi); vector<Sub> v;
    for(int i=0;i<8;i++){ Sub s; s.n=0; int L=(fi==2?ri(301,701):ri(801,1601));
      addcyc_tie(s,L,(int)llround(.66*L),ri(1,4),ri(40,120)); shuf(s); v.push_back(s); }
    write(fi,v); }
  // mixed tie pair: p1=.66 (keeps idx67 min-omitting), p2=.99; product .653 -> all-max mid ~.673
  auto idxmix=[&](int fi){ rng.seed(9000+fi); vector<Sub> v;
    for(int i=0;i<6;i++){ Sub s; s.n=0;
      if(fi==4) addcyc_tie3(s,ri(401,901),ri(1,4),ri(90,150));      // range-climbers structurally 0
      else { int L=ri(401,901); addcyc_tie(s,L,(int)llround(.66*L),ri(1,4),ri(60,100)); } // plain single-tie
      shuf(s); v.push_back(s); } write(fi,v); };
  idxmix(4);
  // t5: single arithmetic-ladder cycles (range-solver file)
  { rng.seed(9005); vector<Sub> v;
    for(int i=0;i<6;i++){ Sub s; s.n=0; addcyc_ladder(s,ri(501,1501),ri(3,9),ri(2,4),1.0); shuf(s); v.push_back(s); }
    write(5,v); }
  // t6: single arithmetic-ladder cycles: W uniform -> range target == P67 exactly
  { rng.seed(9006); vector<Sub> v;
    for(int i=0;i<6;i++){ Sub s; s.n=0; addcyc_ladder(s,ri(501,1501),ri(3,9),ri(2,4),1.0); shuf(s); v.push_back(s); }
    write(6,v); }
  // t7: rare-pair: range target sits on a ~1e-5-mass sum; climbers reach it, samplers don't
  { rng.seed(9007); vector<Sub> v;
    for(int i=0;i<5;i++){ Sub s; s.n=0;
      addcyc_rare(s,ri(301,701),ri(1,4),ri(280,320),.66);
      addcyc_rare(s,ri(301,701),ri(1,4),ri(195,225),.50);
      shuf(s); v.push_back(s); } write(7,v); }
  // t8: single convex-ladder (pw=1.35): mild systematic offset for range-solvers
  { rng.seed(9008); vector<Sub> v;
    for(int i=0;i<5;i++){ Sub s; s.n=0; addcyc_ladder(s,ri(501,1501),ri(3,9),ri(2,4),1.7); shuf(s); v.push_back(s); }
    write(8,v); }
  // t9: mixed tie pair again
  idxmix(9);
  // t10: strong theta bias -> all samplers and range-climbers die; author only
  { rng.seed(9010); vector<Sub> v;
    for(int i=0;i<2;i++){ Sub s; s.n=0;
      while(s.n<3000) addtheta(s,ri(9,10),ri(60,90));
      shuf(s); v.push_back(s); } write(10,v); }
}
