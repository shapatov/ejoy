#pragma once

// Exact spanning-tree weight distribution of a subtest, plus the percentile that
// each heuristic family lands on. Shared by gen.cpp (which rejection-samples
// against these numbers) and calib.cpp (which reports them for an existing file).
//
// A subtest graph is always built so that every biconnected block is either a
// plain cycle or has at most 24 edges, which is what makes the exact enumeration
// below feasible.

#include <algorithm>
#include <array>
#include <cmath>
#include <complex>
#include <cstdio>
#include <map>
#include <numeric>
#include <queue>
#include <random>
#include <tuple>
#include <vector>

using namespace std;

struct Sub {
    int n = 0;
    vector<array<int, 3>> E;
};

namespace dist {

typedef complex<double> Complex;

inline void fft(vector<Complex> &a, bool inverse) {
    int n = a.size();
    for (int i = 1, j = 0; i < n; i++) {
        int bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) swap(a[i], a[j]);
    }
    for (int len = 2; len <= n; len <<= 1) {
        double ang = 2 * M_PI / len * (inverse ? -1 : 1);
        Complex wl(cos(ang), sin(ang));
        for (int i = 0; i < n; i += len) {
            Complex w(1);
            for (int j = 0; j < len / 2; j++) {
                Complex u = a[i + j], v = a[i + j + len / 2] * w;
                a[i + j] = u + v;
                a[i + j + len / 2] = u - v;
                w *= wl;
            }
        }
    }
    if (inverse) for (Complex &x : a) x /= n;
}

inline vector<double> conv(const vector<double> &a, const vector<double> &b) {
    size_t rs = a.size() + b.size() - 1;
    if ((double)a.size() * b.size() <= 4e6) {
        vector<double> r(rs, 0.0);
        for (size_t i = 0; i < a.size(); i++) {
            double ai = a[i];
            if (ai == 0) continue;
            for (size_t j = 0; j < b.size(); j++) r[i + j] += ai * b[j];
        }
        return r;
    }
    size_t n = 1;
    while (n < rs) n <<= 1;
    vector<Complex> fa(n, 0), fb(n, 0);
    for (size_t i = 0; i < a.size(); i++) fa[i] = a[i];
    for (size_t i = 0; i < b.size(); i++) fb[i] = b[i];
    fft(fa, false);
    fft(fb, false);
    for (size_t i = 0; i < n; i++) fa[i] *= fb[i];
    fft(fa, true);
    vector<double> r(rs);
    double s = 0;
    for (size_t i = 0; i < rs; i++) {
        double v = fa[i].real();
        r[i] = v > 0 ? v : 0;
        s += r[i];
    }
    for (double &v : r) v /= s;
    return r;
}

inline vector<double> mergeAll(vector<vector<double>> &parts) {
    if (parts.empty()) return vector<double>(1, 1.0);
    auto cmp = [](const vector<double> &a, const vector<double> &b) { return a.size() > b.size(); };
    priority_queue<vector<double>, vector<vector<double>>, decltype(cmp)> pq(cmp);
    for (vector<double> &p : parts) pq.push(p);
    while (pq.size() > 1) {
        vector<double> a = pq.top(); pq.pop();
        vector<double> b = pq.top(); pq.pop();
        pq.push(conv(a, b));
    }
    return pq.top();
}

// iterative biconnected components, returning the edge ids of every block
inline vector<vector<int>> blocks(int n, const vector<array<int, 3>> &E) {
    vector<vector<pair<int, int>>> adj(n);
    for (int i = 0; i < (int)E.size(); i++) {
        adj[E[i][0]].push_back({E[i][1], i});
        adj[E[i][1]].push_back({E[i][0], i});
    }
    vector<int> disc(n, -1), low(n), estk;
    vector<vector<int>> out;
    int timer = 0;
    vector<tuple<int, int, size_t>> stk;
    for (int s = 0; s < n; s++) {
        if (disc[s] != -1) continue;
        stk.push_back({s, -1, 0});
        disc[s] = low[s] = timer++;
        while (!stk.empty()) {
            auto &[u, pe, it] = stk.back();
            if (it < adj[u].size()) {
                auto [v, id] = adj[u][it++];
                if (id == pe) continue;
                if (disc[v] == -1) {
                    estk.push_back(id);
                    disc[v] = low[v] = timer++;
                    stk.push_back({v, id, 0});
                } else if (disc[v] < disc[u]) {
                    estk.push_back(id);
                    low[u] = min(low[u], disc[v]);
                }
            } else {
                int uu = u, pee = pe;
                stk.pop_back();
                if (!stk.empty()) {
                    int p = get<0>(stk.back());
                    low[p] = min(low[p], low[uu]);
                    if (low[uu] >= disc[p]) {
                        out.push_back({});
                        while (true) {
                            int id = estk.back();
                            estk.pop_back();
                            out.back().push_back(id);
                            if (id == pee) break;
                        }
                    }
                }
            }
        }
    }
    return out;
}

// one block with its vertices renumbered 0..V-1
struct Block {
    int V;
    vector<array<int, 3>> edges;
};

inline Block localize(const vector<array<int, 3>> &E, const vector<int> &ids) {
    Block B;
    vector<int> vmap;
    for (int id : ids) {
        vmap.push_back(E[id][0]);
        vmap.push_back(E[id][1]);
    }
    sort(vmap.begin(), vmap.end());
    vmap.erase(unique(vmap.begin(), vmap.end()), vmap.end());
    B.V = vmap.size();
    for (int id : ids) {
        int a = lower_bound(vmap.begin(), vmap.end(), E[id][0]) - vmap.begin();
        int b = lower_bound(vmap.begin(), vmap.end(), E[id][1]) - vmap.begin();
        B.edges.push_back({a, b, E[id][2]});
    }
    return B;
}

// exact histogram of spanning tree weights of one block
inline bool enumBlock(const Block &B, map<int, long long> &hist) {
    int m = B.edges.size(), V = B.V, k = V - 1;
    if (m == V) {
        long long S = 0;
        for (const array<int, 3> &e : B.edges) S += e[2];
        for (int i = 0; i < m; i++) hist[(int)(S - B.edges[i][2])]++;
        return true;
    }
    if (m > 24) return false;
    vector<int> c(k);
    iota(c.begin(), c.end(), 0);
    int par[32];
    while (true) {
        for (int i = 0; i < V; i++) par[i] = i;
        bool ok = true;
        int w = 0;
        for (int i = 0; i < k; i++) {
            int a = B.edges[c[i]][0], b = B.edges[c[i]][1];
            while (par[a] != a) a = par[a] = par[par[a]];
            while (par[b] != b) b = par[b] = par[par[b]];
            if (a == b) { ok = false; break; }
            par[a] = b;
            w += B.edges[c[i]][2];
        }
        if (ok) hist[w]++;
        int i = k - 1;
        while (i >= 0 && c[i] == m - k + i) i--;
        if (i < 0) break;
        c[i]++;
        for (int j = i + 1; j < k; j++) c[j] = c[j - 1] + 1;
    }
    return true;
}

// weight distribution of one block under random-order Kruskal, which is what every
// "shuffle the edges and run Kruskal" sampler actually draws from. Exact for cycles
// (there the omitted edge is uniform), sampled otherwise.
inline void kruskalBlock(const Block &B, map<int, double> &pmf, mt19937 &rng, int samples) {
    int m = B.edges.size(), V = B.V;
    if (m == V) {
        long long S = 0;
        for (const array<int, 3> &e : B.edges) S += e[2];
        for (int i = 0; i < m; i++) pmf[(int)(S - B.edges[i][2])] += 1.0 / m;
        return;
    }
    vector<int> ord(m);
    iota(ord.begin(), ord.end(), 0);
    int par[32];
    for (int it = 0; it < samples; it++) {
        shuffle(ord.begin(), ord.end(), rng);
        for (int i = 0; i < V; i++) par[i] = i;
        int w = 0, c = 0;
        for (int e : ord) {
            int a = B.edges[e][0], b = B.edges[e][1];
            while (par[a] != a) a = par[a] = par[par[a]];
            while (par[b] != b) b = par[b] = par[par[b]];
            if (a != b) {
                par[a] = b;
                w += B.edges[e][2];
                if (++c == V - 1) break;
            }
        }
        pmf[w] += 1.0 / samples;
    }
}

struct Dsu {
    vector<int> par;
    Dsu(int n) : par(n) { iota(par.begin(), par.end(), 0); }
    int find(int x) { while (par[x] != x) x = par[x] = par[par[x]]; return x; }
    bool unite(int a, int b) { a = find(a); b = find(b); if (a == b) return false; par[a] = b; return true; }
};

// score of every heuristic family on one subtest, all as checker scores in [0,1]
struct Eval {
    double maxmst, minmst, alt, range, krusk, author;
    // "Kruskal at index 67%" repeatedly takes the edge 67% of the way through what is
    // left. Which edge that is depends on how equal weights are ordered, and the answer
    // it produces is wildly sensitive to that, so it is scored under two orderings -
    // by (weight, endpoints, index) and by (weight, index) - and reported as a range.
    double idx67Lo, idx67Hi;
    double pKrusk, pAlt, pRange, pMax;
    long long base, span;
    int nBlocks;
    bool ok;
};

inline double scoreOf(double p) {
    double s = 1.0 - fabs(p - 0.67) / 0.33;
    return s < 0 ? 0 : (s > 1 ? 1 : s);
}

inline Eval evaluate(const Sub &s, mt19937 &rng, int kruskalSamples = 4000) {
    Eval R;
    R.ok = false;
    int m = s.E.size();
    vector<vector<int>> bl = blocks(s.n, s.E);
    R.nBlocks = bl.size();
    long long base = 0, kbase = 0;
    vector<vector<double>> parts, kparts;
    for (vector<int> &ids : bl) {
        Block B = localize(s.E, ids);
        map<int, long long> hist;
        if (!enumBlock(B, hist)) return R;
        long long tot = 0;
        for (auto &[v, c] : hist) tot += c;
        int mn = hist.begin()->first, mx = hist.rbegin()->first;
        base += mn;
        if (mx > mn) {
            vector<double> p(mx - mn + 1, 0.0);
            for (auto &[v, c] : hist) p[v - mn] = (double)c / tot;
            parts.push_back(p);
        }
        map<int, double> kw;
        kruskalBlock(B, kw, rng, kruskalSamples);
        int kmn = kw.begin()->first, kmx = kw.rbegin()->first;
        kbase += kmn;
        if (kmx > kmn) {
            vector<double> p(kmx - kmn + 1, 0.0);
            for (auto &[v, pr] : kw) p[v - kmn] = pr;
            kparts.push_back(p);
        }
    }
    vector<double> pmf = mergeAll(parts), kpmf = mergeAll(kparts);
    double sum = 0;
    for (double v : pmf) sum += v;
    for (double &v : pmf) v /= sum;
    vector<double> cdf(pmf.size());
    {
        double c = 0;
        for (size_t i = 0; i < pmf.size(); i++) { cdf[i] = c + pmf[i] / 2; c += pmf[i]; }
    }
    R.base = base;
    R.span = (long long)pmf.size() - 1;
    auto pct = [&](long long w) {
        if (w < base) return 0.0;
        long long idx = w - base;
        if (idx >= (long long)cdf.size()) return 1.0;
        return cdf[idx];
    };

    vector<int> ix(m);
    iota(ix.begin(), ix.end(), 0);
    sort(ix.begin(), ix.end(), [&](int a, int b) { return s.E[a][2] < s.E[b][2]; });
    auto runKruskal = [&](const vector<int> &ord) {
        Dsu d(s.n);
        long long w = 0;
        for (int e : ord) if (d.unite(s.E[e][0], s.E[e][1])) w += s.E[e][2];
        return w;
    };
    long long wMin = runKruskal(ix);
    vector<int> rx = ix;
    reverse(rx.begin(), rx.end());
    long long wMax = runKruskal(rx);

    vector<int> alt;
    {
        int l = 0, r = m - 1;
        bool back = false;
        while (l <= r) {
            alt.push_back(back ? ix[r--] : ix[l++]);
            back = !back;
        }
    }
    long long wAlt = runKruskal(alt);

    auto runIdx67 = [&](bool byEndpoints) {
        vector<int> pool(m);
        iota(pool.begin(), pool.end(), 0);
        sort(pool.begin(), pool.end(), [&](int a, int b) {
            if (s.E[a][2] != s.E[b][2]) return s.E[a][2] < s.E[b][2];
            if (byEndpoints && s.E[a][0] != s.E[b][0]) return s.E[a][0] < s.E[b][0];
            if (byEndpoints && s.E[a][1] != s.E[b][1]) return s.E[a][1] < s.E[b][1];
            return a < b;
        });
        Dsu d(s.n);
        long long w = 0;
        while (!pool.empty()) {
            size_t k = (pool.size() * 67) / 100;
            int e = pool[k];
            if (d.unite(s.E[e][0], s.E[e][1])) w += s.E[e][2];
            pool.erase(pool.begin() + k);
        }
        return w;
    };
    double idxA = scoreOf(pct(runIdx67(true))), idxB = scoreOf(pct(runIdx67(false)));
    long long wRange = wMin + (long long)llround(0.67 * (wMax - wMin));

    long long wKrusk;
    {
        double c = 0;
        size_t i = 0;
        for (; i < kpmf.size(); i++) { if (c + kpmf[i] >= 0.67) break; c += kpmf[i]; }
        if (i >= kpmf.size()) i = kpmf.size() - 1;
        wKrusk = kbase + (long long)i;
    }

    double bestAuthor = 1e9;
    for (size_t i = 0; i < pmf.size(); i++)
        if (pmf[i] > 1e-13) bestAuthor = min(bestAuthor, fabs(cdf[i] - 0.67));

    R.pMax = pct(wMax);
    R.pAlt = pct(wAlt);
    R.pRange = pct(wRange);
    R.pKrusk = pct(wKrusk);
    R.maxmst = scoreOf(R.pMax);
    R.minmst = scoreOf(pct(wMin));
    R.alt = scoreOf(R.pAlt);
    R.idx67Lo = min(idxA, idxB);
    R.idx67Hi = max(idxA, idxB);
    R.range = scoreOf(R.pRange);
    R.krusk = scoreOf(R.pKrusk);
    R.author = scoreOf(0.67 + bestAuthor);
    R.ok = true;
    return R;
}

}  // namespace dist
