// calib in.file [kruskalSamples]
//
// Reports, per subtest, the exact score each heuristic family would get, and the
// per-file score (= min over subtests, which is how the checker aggregates).
// KRUSK is the infinite-sample limit of a "shuffle edges, run Kruskal, take the
// 67th percentile" sampler, so it is an upper bound on what those solutions score.
#include <cstdio>
#include <random>

#include "dist.h"

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "usage: calib in.file [kruskalSamples]\n");
        return 1;
    }
    int samples = argc >= 3 ? atoi(argv[2]) : 20000;
    FILE *fin = fopen(argv[1], "r");
    if (!fin) {
        fprintf(stderr, "cannot open %s\n", argv[1]);
        return 1;
    }
    int t;
    if (fscanf(fin, "%d", &t) != 1) return 1;
    mt19937 rng(777);
    double worst[7];
    for (int i = 0; i < 7; i++) worst[i] = 1e9;
    const char *names[7] = {"MAXMST", "MINMST", "ALT", "IDX67", "RANGE", "KRUSK", "AUTHOR"};
    for (int si = 0; si < t; si++) {
        Sub s;
        int m;
        if (fscanf(fin, "%d %d", &s.n, &m) != 2) return 1;
        s.E.resize(m);
        for (array<int, 3> &e : s.E) {
            if (fscanf(fin, "%d %d %d", &e[0], &e[1], &e[2]) != 3) return 1;
            e[0]--;
            e[1]--;
        }
        dist::Eval R = dist::evaluate(s, rng, samples);
        if (!R.ok) {
            printf("  sub%d: block too large to enumerate\n", si + 1);
            return 1;
        }
        double sc[7] = {R.maxmst, R.minmst, R.alt, R.idx67Lo, R.range, R.krusk, R.author};
        printf("  sub%d n=%d m=%d blocks=%d span=%lld |", si + 1, s.n, m, R.nBlocks, R.span);
        for (int i = 0; i < 7; i++) printf(" %s=%.3f", names[i], sc[i]);
        printf("  (pKr=%.4f pAlt=%.4f pRange=%.4f pMax=%.4f)\n", R.pKrusk, R.pAlt, R.pRange, R.pMax);
        for (int i = 0; i < 7; i++) worst[i] = min(worst[i], sc[i]);
    }
    printf("FILE %s |", argv[1]);
    for (int i = 0; i < 7; i++) printf(" %s=%.3f", names[i], worst[i]);
    printf("\n");
    return 0;
}
