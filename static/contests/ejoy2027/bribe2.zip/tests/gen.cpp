// Test generator for bribe2.
//
// Every subtest is a random block tree: biconnected blocks (long cycles and small
// chorded blocks) glued at random cut vertices, then relabelled. Nothing about the
// shape of a subtest is fixed, but each archetype is rejection-sampled against the
// exact spanning-tree weight distribution (dist.h) until the heuristic families land
// where the suite wants them, so the point budget is exact rather than hoped for.
//
// Intended per-family totals over the ten tests (10 points each):
//   maximum spanning tree      20   (tests 1-2)
//   alternating Kruskal        35   (tests 1-2 fully, 3-5 at the ~0.48 floor)
//   percentile-67 sampler      75   (tests 1-7, half of test 8)
//   exact block DP            100
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <numeric>
#include <random>
#include <set>
#include <vector>

#include "dist.h"

mt19937 rng;

int ri(int a, int b) {
    return uniform_int_distribution<int>(a, b)(rng);
}

double rd() {
    return uniform_real_distribution<double>(0.0, 1.0)(rng);
}

// a random already-existing vertex to hang the next block off, creating the very
// first vertex if the subtest is still empty
int anchorVertex(Sub &s) {
    if (s.n == 0) {
        s.n = 1;
        return 0;
    }
    return ri(0, s.n - 1);
}

// cycle of weights.size() edges through the anchor and weights.size()-1 new vertices
void addCycle(Sub &s, vector<int> weights) {
    int L = weights.size();
    int start = anchorVertex(s);
    shuffle(weights.begin(), weights.end(), rng);
    int prev = start;
    for (int i = 0; i < L - 1; i++) {
        s.E.push_back({prev, s.n, weights[i]});
        prev = s.n++;
    }
    s.E.push_back({prev, start, weights[L - 1]});
}

// two-connected block on V vertices (anchor plus V-1 new): a cycle through all of
// them plus `extra` chords. weights must hold V+extra entries.
void addChordBlock(Sub &s, int V, int extra, vector<int> weights) {
    int start = anchorVertex(s);
    vector<int> node(V);
    node[0] = start;
    for (int i = 1; i < V; i++) node[i] = s.n++;
    shuffle(node.begin(), node.end(), rng);
    shuffle(weights.begin(), weights.end(), rng);
    int at = 0;
    set<pair<int, int>> have;
    for (int i = 0; i < V; i++) {
        int a = node[i], b = node[(i + 1) % V];
        s.E.push_back({a, b, weights[at++]});
        have.insert({min(a, b), max(a, b)});
    }
    vector<pair<int, int>> rest;
    for (int i = 0; i < V; i++)
        for (int j = i + 1; j < V; j++)
            if (!have.count({min(node[i], node[j]), max(node[i], node[j])}))
                rest.push_back({node[i], node[j]});
    shuffle(rest.begin(), rest.end(), rng);
    for (int i = 0; i < extra && i < (int)rest.size(); i++)
        s.E.push_back({rest[i].first, rest[i].second, weights[at++]});
}

void relabel(Sub &s) {
    vector<int> perm(s.n);
    iota(perm.begin(), perm.end(), 0);
    shuffle(perm.begin(), perm.end(), rng);
    shuffle(s.E.begin(), s.E.end(), rng);
    for (array<int, 3> &e : s.E) {
        int u = perm[e[0]], v = perm[e[1]];
        if (ri(0, 1)) swap(u, v);
        e[0] = u;
        e[1] = v;
    }
}

// L weights on [lo,hi] with a tunable skew: gamma = 1 is uniform, gamma > 1 pulls the
// mean above the median (which drags alternating Kruskal up), gamma < 1 below it
vector<int> skewWeights(int L, int lo, int hi, double gamma) {
    vector<int> w(L);
    for (int i = 0; i < L; i++)
        w[i] = lo + (int)llround((hi - lo) * pow(rd(), gamma));
    return w;
}

// ---------------------------------------------------------------- biased blocks
// Uniformly random spanning trees and the trees that "shuffle the edges and run
// Kruskal" produces are the same thing on a cycle, but not on anything else: Kruskal
// closes short cycles early, so it throws away edges of the short paths of a block far
// more often than a uniform spanning tree would. A generalised theta - two ends joined
// by a few short heavy paths and one long light path - maximises that gap, at about a
// fifth of a standard deviation per block. The gap adds up linearly over blocks while
// the standard deviation only grows as a square root, so enough copies push any
// sampler's idea of the 67th percentile arbitrarily far from the real one.
//
// Random chorded blocks are useless here: their gap is under 0.12 sd and, worse, its
// sign is random, so it cancels instead of accumulating.
struct Gadget {
    vector<int> len;  // edges on each of the paths joining the two hubs
    vector<int> w;    // weight of every edge of each path
};

void addGadget(Sub &s, const Gadget &g) {
    int hubA = anchorVertex(s);
    int hubB = s.n++;
    for (size_t p = 0; p < g.len.size(); p++) {
        int prev = hubA;
        for (int j = 0; j < g.len[p] - 1; j++) {
            s.E.push_back({prev, s.n, g.w[p]});
            prev = s.n++;
        }
        s.E.push_back({prev, hubB, g.w[p]});
    }
}

double gadgetShift(const Gadget &g, int samples) {
    Sub probe;
    addGadget(probe, g);
    vector<int> ids(probe.E.size());
    iota(ids.begin(), ids.end(), 0);
    dist::Block loc = dist::localize(probe.E, ids);
    map<int, long long> hist;
    if (!dist::enumBlock(loc, hist)) return 0;
    long long tot = 0;
    double mean = 0, sq = 0;
    for (auto &[v, c] : hist) tot += c;
    for (auto &[v, c] : hist) mean += (double)v * c / tot;
    for (auto &[v, c] : hist) sq += (v - mean) * (v - mean) * c / tot;
    double sd = sqrt(sq);
    if (sd < 1e-9) return 0;
    map<int, double> kw;
    dist::kruskalBlock(loc, kw, rng, samples);
    double kmean = 0;
    for (auto &[v, p] : kw) kmean += v * p;
    return (kmean - mean) / sd;
}

// base is where the block sits in the weight range, spread is how much of the subtest's
// variance it carries. Only the differences matter for the shift, so base is free to
// wander over the whole range and keep the weight histogram looking ordinary.
Gadget makeGadget(int base, int spread, double wantShift) {
    while (true) {
        Gadget g;
        int paths = ri(3, 4);
        for (int i = 0; i + 1 < paths; i++) g.len.push_back(ri(2, 4));
        g.len.push_back(ri(8, 15));
        int high = base + spread;
        for (int i = 0; i + 1 < paths; i++) g.w.push_back(high + ri(-spread / 8, spread / 8));
        g.w.push_back(base + ri(0, max(1, spread / 8)));
        if (gadgetShift(g, 800) >= wantShift) return g;
    }
}

// ------------------------------------------------------------------- archetypes
// Camouflage: small blocks whose edges sit within a couple of units of each other, so
// they add degree-three vertices and push m above n without measurably moving either
// the weight distribution or what a shuffle-and-Kruskal sampler draws. Their centres
// follow the same law as the cycle weights, otherwise they drag the global median off
// the cycles' own median and alternating Kruskal stops omitting the edge it should.
void addCamouflage(Sub &s, int count, int lo, int hi, double gamma, int jitter) {
    for (int i = 0; i < count; i++) {
        int V = ri(5, 9), extra = ri(2, 4);
        int centre = skewWeights(1, lo, hi, gamma)[0];
        vector<int> w(V + extra);
        for (int &x : w) x = centre + ri(0, jitter);
        addChordBlock(s, V, extra, w);
    }
}

// Tests 1-2. A few cycles carry a block of tied minimum-weight edges, so the maximum
// spanning tree is far from unique. The multiplicities telescope to 33/50 = 0.66, so
// the probability of hitting the maximum weight is exactly 0.66 and the maximum
// spanning tree sits at mid-CDF 1 - 0.66/2 = 0.67 exactly.
//
// Everything else in the graph is constant-weight camouflage: any block with a spread
// of its own would multiply into the 0.66 and break it. The tied value is placed at
// the quantile of the camouflage weights that leaves the tied edges straddling the
// global median rank, which is where alternating Kruskal takes its last edge, so that
// solution ends up on the maximum tree as well.
Sub makeMaxTie() {
    int camoBlocks = ri(340, 400);
    vector<int> camoV(camoBlocks), camoExtra(camoBlocks), camoWeight(camoBlocks);
    vector<int> pool;
    int camoEdges = 0;
    for (int i = 0; i < camoBlocks; i++) {
        camoV[i] = ri(5, 9);
        camoExtra[i] = ri(2, 4);
        camoWeight[i] = ri(1, 9000);
        int cnt = camoV[i] + camoExtra[i];
        camoEdges += cnt;
        for (int j = 0; j < cnt; j++) pool.push_back(camoWeight[i]);
    }

    vector<int> chain;
    chain.push_back(33);
    {
        set<int> mid;
        int steps = ri(3, 5);
        while ((int)mid.size() < steps - 1) mid.insert(ri(34, 49));
        for (int x : mid) chain.push_back(x);
    }
    chain.push_back(50);

    vector<int> len, tied;
    int high = 0;
    for (int i = 1; i < (int)chain.size(); i++) {
        int scale = max(3, ri(130, 260) / chain[i]);
        len.push_back(scale * chain[i]);
        tied.push_back(scale * chain[i - 1]);
        high += len.back() - tied.back();
    }

    sort(pool.begin(), pool.end());
    double q = (camoEdges + high) / (2.0 * camoEdges);
    int tie = pool[min<int>(pool.size() - 1, (int)(q * camoEdges))];

    // Each cycle gets its own tied value, one unit apart, so no single weight carries a
    // conspicuous share of the edges. They stay adjacent in the sorted order and the
    // band as a whole is centred on the median, which is what alternating Kruskal needs.
    Sub s;
    for (int i = 0; i < (int)len.size(); i++) {
        vector<int> w(len[i], tie + i);
        for (int j = tied[i]; j < len[i]; j++) w[j] = ri(tie + 300, tie + 2800);
        addCycle(s, w);
    }
    for (int i = 0; i < camoBlocks; i++)
        addChordBlock(s, camoV[i], camoExtra[i], vector<int>(camoV[i] + camoExtra[i], camoWeight[i]));
    relabel(s);
    return s;
}

// A long cycle carrying one far heavier edge. Its weights only take two levels, so
// almost all of its spanning trees sit at its maximum, but the gap D between the two
// levels widens [min, max] by D while widening the standard deviation by only
// D/sqrt(L). That makes it the lever for min + 0.67(max - min): each copy drags that
// target about 0.33*sqrt(L) standard deviations below the mean, while barely touching
// alternating Kruskal (1/sqrt(L)) and not touching the samplers at all, since a cycle
// is a cycle.
// reversed flips which end the mass piles up on, and so which side of the mean the
// range target is dragged to; a subtest needs whichever sign its other blocks are not
// already supplying, since the solve below has to bracket 0.67 from both ends.
void addStretcher(Sub &s, int base, int gap, bool reversed) {
    int L = ri(150, 250);
    vector<int> w(L);
    for (int i = 0; i + 1 < L; i++) w[i] = base + (reversed ? gap : 0) + ri(0, 30);
    w[L - 1] = base + (reversed ? 0 : gap);
    addCycle(s, w);
}

// Tests 3-7. Plain cycles with skewed weights, plus a few stretchers. gamma = 1 leaves
// alternating Kruskal on the median tree (its 0.485 floor); gamma below 1 pushes it off
// the median in a direction that the ~25 blocks amplify until it scores nothing, and
// gamma above 1 pushes it the other way. The stretchers then place the range target
// independently of all that.
Sub makeCycles(int cycles, int cycleLen, double gamma, int stretchers, int gap) {
    Sub s;
    int lo = ri(300, 600), hi = lo + ri(620, 760);
    for (int i = 0; i < cycles; i++)
        addCycle(s, skewWeights(max(12, cycleLen + ri(-12, 12)), lo, hi, gamma));
    for (int i = 0; i < stretchers; i++) addStretcher(s, ri(lo, hi), gap, false);
    addCamouflage(s, 110, lo, hi, gamma, 2);
    relabel(s);
    return s;
}

// Test 8 (mild) and tests 9-10 (full). Mixing biased blocks into the cycles moves the
// distribution that a shuffle-and-Kruskal sampler draws from away from the true one.
// The cycles are what dilutes the gadgets: they carry variance without carrying bias,
// so cycleSpread and gadgetSpread together set how far off the samplers end up.
//
// A gadget's weight distribution is concentrated on its maximum, which puts it well
// above the 67% point of its own range - the opposite side from a plain cycle - so with
// uniform cycle weights the two cancel and hand the range-targeting hill climbers a
// free test. gamma below 1 moves the cycles far enough that they dominate again.
Sub makeBiased(int cycles, int cycleSpread, double gamma, int gadgets, int gadgetSpread,
               double wantShift, int stretchers, int gap) {
    Sub s;
    int lo = ri(300, 600), hi = lo + cycleSpread;
    for (int i = 0; i < cycles; i++) addCycle(s, skewWeights(ri(70, 140), lo, hi, gamma));
    for (int i = 0; i < gadgets; i++)
        addGadget(s, makeGadget(ri(lo, hi), gadgetSpread + ri(-gadgetSpread / 5, gadgetSpread / 5), wantShift));
    for (int i = 0; i < stretchers; i++) addStretcher(s, ri(lo, hi), gap, true);
    addCamouflage(s, 40, lo, hi, gamma, 2);
    relabel(s);
    return s;
}

// ---------------------------------------------------------------------- driver
// A window per heuristic family, plus which knob (if any) the driver should solve for.
// min + 0.67(max - min) has to be placed to within a thousandth of the 67th percentile,
// which rejection alone will never hit, so it gets solved instead:
//   TuneGamma  moves the cycle weight skew. Smooth, and leaves nothing else pinned, so
//              this is the one to use wherever index-67% also needs a live window.
//   TuneGap    widens the stretcher blocks. Needed once the gadgets of tests 9-10 have
//              dragged the range target somewhere gamma cannot reach on its own, at the
//              cost of pinning index-67% to an extreme.
enum Tune { TuneNone, TuneGamma, TuneGap };

struct Spec {
    double maxmstLo, maxmstHi;
    double altLo, altHi;
    double idxLo, idxHi;
    double rangeLo, rangeHi;
    double kruskLo, kruskHi;
    Tune tune;
};

long long rejects[8];  // why candidates were thrown away, reported per subtest
const char *rejectName[8] = {"unusable", "AUTHOR", "MAXMST", "ALT", "IDX67", "RANGE", "KRUSK", "nobracket"};

bool accepts(const Spec &sp, const dist::Eval &e) {
    if (!e.ok) { rejects[0]++; return false; }
    if (e.author < 0.9995) { rejects[1]++; return false; }
    if (e.maxmst < sp.maxmstLo || e.maxmst > sp.maxmstHi) { rejects[2]++; return false; }
    if (e.alt < sp.altLo || e.alt > sp.altHi) { rejects[3]++; return false; }
    if (e.idx67Lo < sp.idxLo || e.idx67Hi > sp.idxHi) { rejects[4]++; return false; }
    if (e.range < sp.rangeLo || e.range > sp.rangeHi) { rejects[5]++; return false; }
    if (e.krusk < sp.kruskLo || e.krusk > sp.kruskHi) { rejects[6]++; return false; }
    return true;
}

void writeTest(int index, const vector<Sub> &subs) {
    char name[64];
    sprintf(name, "../contestant/test.%02d.in", index);
    FILE *f = fopen(name, "w");
    fprintf(f, "%d\n", (int)subs.size());
    long long sumN = 0, sumM = 0;
    for (const Sub &s : subs) {
        fprintf(f, "%d %d\n", s.n, (int)s.E.size());
        for (const array<int, 3> &e : s.E) fprintf(f, "%d %d %d\n", e[0] + 1, e[1] + 1, e[2]);
        sumN += s.n;
        sumM += s.E.size();
    }
    fclose(f);
    printf("test %02d written: t=%d sumN=%lld sumM=%lld\n", index, (int)subs.size(), sumN, sumM);
    fflush(stdout);
}

// `gen sweep` walks the cycle archetype's knobs and reports where each heuristic
// family lands, which is how the windows below were chosen.
void sweep() {
    mt19937 evalRng(1);
    printf("%6s %8s | %6s %6s %6s %6s %6s %6s\n", "gamma", "stretch", "MAXMST", "ALT", "IDX67", "RANGE", "KRUSK", "AUTH");
    for (double gamma = 0.4; gamma <= 2.61; gamma += 0.15) {
        for (int stretch = 0; stretch <= 6; stretch += 3) {
            rng.seed(1234);
            Sub s = makeCycles(ri(20, 28), ri(70, 140), gamma, stretch, 3000);
            dist::Eval e = dist::evaluate(s, evalRng, 3000);
            printf("%6.2f %8d | %6.3f %6.3f %6.3f %6.3f %6.3f %6.3f\n", gamma, stretch,
                   e.maxmst, e.alt, e.idx67Lo, e.idx67Hi, e.range, e.krusk, e.author);
        }
    }
}

int main(int argc, char **argv) {
    if (argc >= 2 && string(argv[1]) == "sweep") {
        sweep();
        return 0;
    }
    int only = argc >= 2 ? atoi(argv[1]) : 0;

    //             MAXMST        ALT          IDX67        RANGE        KRUSK       tune
    // 1-2  maximum spanning tree lands exactly on 0.67, and so does alternating Kruskal
    Spec gift   { .996, 1.0,   .996, 1.0,  0.0, .35,  0.0, .05,   .996, 1.0, TuneNone};
    // 3,5  alternating Kruskal on its median floor, index-67% given its band
    Spec neutral{  0.0, .02,   .40, .58,  .68, .98,  0.0, .05,   .996, 1.0, TuneNone};
    // 4    the same, with few enough cycles that solving the range target still leaves
    //      alternating Kruskal near its floor
    Spec ranged {  0.0, .02,   .35, .62,  .68, .98,  .996, 1.0,  .996, 1.0, TuneGamma};
    // 6-7  many cycles instead, which buries alternating Kruskal while the range target
    //      is solved just the same
    Spec skewed {  0.0, .02,   0.0, .20,  .68, .98,  .996, 1.0,  .996, 1.0, TuneGamma};
    // 8    sampler only half right, nothing else scores
    Spec mild   {  0.0, .02,   0.0, .05,  0.0, .35,  0.0, .05,    .35, .65, TuneNone};
    // 9    sampler dead, but the range target is still reachable - this is the test that
    //      lifts the merged ceiling from 74 to 85
    Spec reach  {  0.0, .02,   0.0, .05,  0.0, .35,  .996, 1.0,   0.0, .12, TuneGap};
    // 10   nothing but the exact solution
    Spec hostile{  0.0, .02,   0.0, .05,  0.0, .35,  0.0, .05,    0.0, .03, TuneNone};

    for (int test = 1; test <= 10; test++) {
        if (only && test != only) continue;
        mt19937 evalRng(4242u + test);

        int subtests = 6;
        vector<Sub> subs;
        for (int si = 0; si < subtests; si++) {
            int tries = 0;
            for (int i = 0; i < 8; i++) rejects[i] = 0;
            while (true) {
                tries++;
                Spec sp = test <= 2 ? gift : test <= 3 ? neutral : test == 4 ? ranged
                        : test == 5 ? neutral : test <= 7 ? skewed : test == 8 ? mild
                        : test == 9 ? reach : hostile;
                // reseeding per attempt makes the build a pure function of its knob, so a
                // knob can be solved for without the rest of the graph moving underneath
                unsigned seed = 20260730u + 7919u * test + 104729u * si + 1299721u * tries;
                auto build = [&](double gamma, int gap) {
                    rng.seed(seed);
                    if (test <= 2) return makeMaxTie();
                    if (test <= 5) return makeCycles(ri(20, 28), ri(70, 140), gamma, 0, 0);
                    if (test <= 7) return makeCycles(ri(44, 58), ri(38, 56), gamma, 0, 0);
                    if (test == 8) return makeBiased(ri(18, 24), 700, 0.5, ri(120, 160), 70, 0.15, 0, 0);
                    return makeBiased(ri(6, 10), 60, 0.5, ri(140, 165), 200, 0.15,
                                      gap ? ri(2, 3) : 0, gap);
                };

                double gamma = test <= 5 ? 1.0 : 0.55;
                int gap = 0;
                {   // cheap size guard: solving a knob below costs a dozen evaluations
                    Sub probe = build(gamma, sp.tune == TuneGap ? 3000 : 0);
                    if (probe.n > 5000 || (int)probe.E.size() > 10000) {
                        if (tries > 250) {
                            fprintf(stderr, "test %d subtest %d: candidates always oversized\n", test, si + 1);
                            return 1;
                        }
                        continue;
                    }
                }

                if (sp.tune != TuneNone) {
                    // pRange is monotone in either knob, so bracket 0.67 and bisect. The
                    // weights move continuously with gamma because the seed is fixed.
                    double lo = sp.tune == TuneGamma ? 0.8 : 40, hi = sp.tune == TuneGamma ? 3.2 : 8000;
                    auto at = [&](double x) {
                        return dist::evaluate(sp.tune == TuneGamma ? build(x, 0) : build(gamma, (int)x), evalRng, 300);
                    };
                    dist::Eval ea = at(lo), eb = at(hi);
                    if (!ea.ok || !eb.ok) continue;
                    if ((ea.pRange - 0.67) * (eb.pRange - 0.67) > 0) { rejects[7]++; continue; }
                    bool rising = eb.pRange > ea.pRange;
                    for (int step = 0; step < (sp.tune == TuneGamma ? 26 : 13); step++) {
                        double mid = (lo + hi) / 2;
                        dist::Eval em = at(mid);
                        if (!em.ok) break;
                        if ((em.pRange < 0.67) == rising) { lo = mid; ea = em; } else { hi = mid; eb = em; }
                    }
                    double best = fabs(ea.pRange - 0.67) <= fabs(eb.pRange - 0.67) ? lo : hi;
                    if (sp.tune == TuneGamma) gamma = best; else gap = (int)best;
                }

                Sub s = build(gamma, gap);
                if (s.n > 5000 || (int)s.E.size() > 10000) continue;
                dist::Eval e = dist::evaluate(s, evalRng, 4000);
                if (accepts(sp, e)) {
                    printf("  t%02d sub%d (try %d) n=%d m=%d blocks=%d span=%lld gamma=%.3f gap=%d | "
                           "MAXMST=%.3f ALT=%.3f IDX67=%.3f..%.3f RANGE=%.3f KRUSK=%.3f AUTHOR=%.3f\n",
                           test, si + 1, tries, s.n, (int)s.E.size(), e.nBlocks, e.span, gamma, gap,
                           e.maxmst, e.alt, e.idx67Lo, e.idx67Hi, e.range, e.krusk, e.author);
                    for (int i = 0; i < 8; i++)
                        if (rejects[i]) printf("      rejected on %s: %lld\n", rejectName[i], rejects[i]);
                    fflush(stdout);
                    subs.push_back(s);
                    break;
                }
                if (getenv("GENVERBOSE"))
                    printf("    reject t%02d sub%d try %d: gamma=%.3f gap=%d | "
                           "MAXMST=%.3f ALT=%.3f IDX67=%.3f..%.3f RANGE=%.3f KRUSK=%.3f AUTHOR=%.3f\n",
                           test, si + 1, tries, gamma, gap,
                           e.maxmst, e.alt, e.idx67Lo, e.idx67Hi, e.range, e.krusk, e.author);
                if (tries > 1500) {
                    fprintf(stderr, "test %d subtest %d: no candidate accepted\n", test, si + 1);
                    return 1;
                }
            }
        }
        writeTest(test, subs);
    }
    return 0;
}
