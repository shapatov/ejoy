#include <iostream>
#include <vector>
#include <assert.h>
#include <algorithm>
#include <random>
#include "manager.h"
#define endl '\n'
using namespace std;
namespace grader {
    static const string password = "2844f5600716523252ef0f5475b2d3257d5fd4ec5b9722f408af0a2e130c6eaa";
}

namespace manager {
    static const string password = "c97e21e6214a369fe6ebf59742045ad1598f969c19adb673567fe3682d16c8bf";
}

inline void safeexit(char* argv[]) {
    for(int i=1;i<=4;i++)close(atoi(argv[i]));exit(0);
}

static int num[100000];

int main(int argc, char* argv[]) {
    ios::sync_with_stdio(false);
    cin.tie(0);
    
    fd_to_stream(argv+1, 4);
    // 0-encode, 1-decode

    string pass;

    int n; cin >> n;
    out(0) << 0 << endl << n << endl;
    vector<pair<int,int>> v, ansdec;
    for(int i = 0; i < n-1; i++) {
        int a,b; cin >> a >> b;
        v.push_back({a, b});
        out(0) << a << " " << b << endl;
    }

    out(0) << flush;

    if(!(in(0) >> pass)) {
        cout << manager::password << endl;
        cout << -1 << endl;
        cout << "Manager communication with grader failed!" << endl;
        safeexit(argv);
    }

    if(pass!=grader::password) {
        cout << manager::password << endl;
        cout << -1 << endl;
        cout << "Contestant wrote to cout." << endl;
        safeexit(argv);
    }

    int br=0;
    if(!(in(0) >> br)) {
        cout << manager::password << endl;
        cout << -1 << endl;
        cout << "Error while reading vector of removed nodes!" << endl;
        safeexit(argv);
    }

    if(br==-1) {
        cout << manager::password << endl;
        cout << -1 << endl;
        cout << "Invalid vector returned in encode!" << endl;
        safeexit(argv);
    }

    vector<int> ansenc(br);
    bool b=0;
    for(int i = 0; i < br; i++) {
        if(!(in(0) >> ansenc[i])) {
            cout << manager::password << endl;
            cout << -1 << endl;
            cout << "Error while reading vector of removed nodes!" << endl;
            safeexit(argv);
        }
        b|=(ansenc[i]==1);
    }

    int len = ansenc.size();

    // anonymise tree here rather than in decode process

    mt19937 mt(6742067);
    vector<pair<int,int>> nw;
    int ptr=-1;
    for(int i = 1; i <= n; i++) num[i]=i;
    if(b) {
        num[1]=-1;
        ptr--;
        ansenc.erase(remove(ansenc.begin(), ansenc.end(), 1), ansenc.end());
    }
    shuffle(ansenc.begin(), ansenc.end(), mt);
    for(auto &x : ansenc) {
        num[x]=ptr;
        ptr--;
    }
    for(auto &x : v) {
        nw.push_back({num[x.first], num[x.second]});
        if(mt()%2) swap(nw.back().first, nw.back().second);
    }

    out(1) << 1 << endl << n << endl;
    for(auto &x : nw) {
        out(1) << x.first << " " << x.second << endl;
    }

    out(1) << flush;

    if(!(in(1) >> pass)) {
        cout << manager::password << endl;
        cout << -1 << endl;
        cout << "Manager communication with grader failed!" << endl;
        safeexit(argv);
    }

    if(pass!=grader::password) {
        cout << manager::password << endl;
        cout << -1 << endl;
        cout << "Contestant wrote to cout." << endl;
        safeexit(argv);
    }

    for(int i = 0; i < v.size(); i++) if(v[i].first>v[i].second) swap(v[i].first, v[i].second);
    sort(v.begin(), v.end());

    for(int i = 0; i < n-1; i++) {
        int a=-1,b=-1;
        if(!(in(1) >> a >> b)||a<1||a>n||b<1||b>n||a==b) {
            cout << manager::password << endl;
            cout << -1 << endl;
            cout << "Invalid edges vector returned!" << endl;
            safeexit(argv);
        }
        if(a>b) swap(a, b);
        ansdec.push_back({a, b});
    }
    sort(ansdec.begin(), ansdec.end());

    if(ansdec==v) {
        cout << manager::password << endl;
        cout << len << endl;
        cout << "OK with " << len << " removed!" << endl;
        safeexit(argv);
    }

    cout << manager::password << endl;
    cout << -1 << endl;
    cout << "Wrong answer!" << endl;
    safeexit(argv);
}