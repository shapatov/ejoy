#include <iostream>
#include <unordered_set>
#include <random>
#include <algorithm>
#include "tree2.h"
using namespace std;
namespace grader {
    static const string password = "2844f5600716523252ef0f5475b2d3257d5fd4ec5b9722f408af0a2e130c6eaa";
}
using namespace grader;
int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    
    int type; cin >> type;
    if(type==0) {
        int n; cin >> n;
        vector<pair<int,int>> v;
        for(int i = 0; i < n-1; i++) {
            int a,b; cin >> a >> b;
            v.push_back({a, b});
        }
        vector<int> ans=encode(n, v);
        unordered_set<int> nums;
        for(int i = 0; i < ans.size(); i++) {
            if(ans[i]<1||ans[i]>n) {
                cout << password << endl << -1 << endl;
                cout << flush;
                exit(0);
            }
            nums.insert(ans[i]);
        }
        if(nums.size()!=ans.size()) {
            cout << password << endl << -1 << endl;
            cout << flush;
            exit(0);
        }
        cout << password << endl << ans.size() << " ";
        for(auto &x : ans) cout << x << " ";
        cout << endl;
        cout << flush;
    }
    else {
        int n; cin >> n;
        vector<pair<int,int>> v;
        for(int i = 0; i < n-1; i++) {
            int a,b; cin >> a >> b;
            v.push_back({a, b});
        }
        vector<pair<int,int>> ans=decode(n, v);
        cout << password << endl;
        if(ans.size()!=n-1) {
            cout << "-1 -1" << endl;
            cout << flush;
            return 0;
        }
        for(auto &x : ans) cout << x.first << " " << x.second << endl;
        cout << endl;
        cout << flush;
    }
}