#!/bin/bash

task="tree2"
stack_size=268435456  # 256 GB

ulimit -s "${stack_size}"
"./${task}"

