#include "tree2.h"

std::vector<int> encode(int N, std::vector<std::pair<int, int>> v) {
    return {};
}

std::vector<std::pair<int, int>> decode(int N, std::vector<std::pair<int,int>> v) {
    return {};
}