#pragma once
#include <iostream>
#include <vector>

std::vector<int> encode(int, std::vector<std::pair<int, int>>);
std::vector<std::pair<int, int>> decode(int, std::vector<std::pair<int,int>>);