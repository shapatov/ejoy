#include <iostream>
#include <vector>
#include <cmath>
#include <unordered_map>
#include "tree2.h"
using namespace std;

vector<int> encode(int n, vector<pair<int, int>> v) {
    return {1, 2};
}

vector<pair<int, int>> decode(int n, vector<pair<int, int>> v) {
    vector<pair<int,int>> ans=v;
    for(auto &x : ans) {
        x.first=abs(x.first), x.second=abs(x.second);
    }
    return ans;
}