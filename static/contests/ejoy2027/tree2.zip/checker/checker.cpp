#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <vector>
using namespace std;

void output_message(double points, string message){
	cout << points << endl;
	cerr << message << endl;
	exit(0);
}

namespace manager {
    const string password = "c97e21e6214a369fe6ebf59742045ad1598f969c19adb673567fe3682d16c8bf";
}

int main (int argc, char** argv) {
	if(argc < 4){ output_message(0, "Insufficient arguments!"); return 1; }
	fstream input(argv[1]), output(argv[2]), contestant(argv[3]);
	if(!input.is_open()){ output_message(0, "Couldn't open input file."); return 1; }
	if(!output.is_open()){ output_message(0, "Couldn't open output file."); return 1; }
	if(!contestant.is_open()){ output_message(0, "Couldn't open contestant file."); return 1; }

	string check;
	contestant >> check;
	if(check != manager::password){ output_message(0, "Contestant wrote to cout."); return 1; }

    int n; input >> n;
	int len;
    contestant >> len;
    //cout << res << endl;
    double pts = min<double>(1.0, max<double>(0.0, (double)len/(double)floor(sqrt((double)n))));
    if(len==-1) cout << 0 << endl;
    else cout << fixed << setprecision(2) << pts << endl;
    string message;
    while(contestant >> message) {
        cerr << message << " ";
    }
    cout << endl;
	exit(0);
	return 0;
}