#include <iostream>
#include "guess.h"
using namespace std;
namespace grader {
    static int _queries = 0;
    static int _x, _n; 
    static string password="be3daf18e77c0238d43b4718dfca512d7ff1d32d62172d3332fcb8d875076595";
}
using namespace grader;
bool query(int y) {
    _queries++;
    return _x>=y; 
}
int main() {
    cin >> _x >> _n;
    int val = solve(_n);
    cout << password << " " << val << " " << _queries << endl;
}