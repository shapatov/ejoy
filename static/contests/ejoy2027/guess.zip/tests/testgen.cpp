#include <iostream>
#include <random>
#include <fstream>
#include <algorithm>
using namespace std;
mt19937 mt(random_device{}());
int main() {
    for(int t = 1; t <= 20; t++) {
        int n = 1000000000+mt()%1000000000+1, x = 1+mt()%n;
        string s = to_string(t);
        reverse(s.begin(),s.end());
        if(t<10) s.push_back('0');
        if(t<100) s.push_back('0');
        reverse(s.begin(),s.end());
        ofstream in("test."+s+".in");
        ofstream out("test."+s+".out");
        in << x << " " << n;
        in.close();
        out.close();
    }
}
