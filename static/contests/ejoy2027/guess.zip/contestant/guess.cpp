#include "guess.h"

int solve(int N) {
    return 0;
}