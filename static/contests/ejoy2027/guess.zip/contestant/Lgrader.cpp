#include <iostream>
#include "guess.h"
using namespace std;
static int queries = 0;
static int x, n; 
bool query(int y) {
    queries++;
    return x>=y;
}
int main() {
    cin >> x >> n;
    int ans = solve(n);
    if(ans!=x) cout << "Wrong answer! Returned " << ans << endl;
    else cout << "Correct in " << queries << " queries!" << endl;
}