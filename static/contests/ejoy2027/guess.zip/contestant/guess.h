int solve(int);
bool query(int); 