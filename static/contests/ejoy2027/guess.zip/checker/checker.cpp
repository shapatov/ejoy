/* the checker has three arguments:
    - first - name of the input file
    - second - name of the correct output file
    - third - name of the contestant output file */
#include<iostream>
#include<fstream>
#include<cmath>
#define endl '\n'
using namespace std;
static string password="be3daf18e77c0238d43b4718dfca512d7ff1d32d62172d3332fcb8d875076595";
void output_message(double points, string message){
	cout << points << endl;
	if(message.size()) cerr << message << endl;
	exit(0);
}
int main (int argc, char** argv) {
	if(argc < 4){ output_message(0, "Insufficient arguments!"); return 1; }
	fstream input(argv[1]), output(argv[2]), contestant(argv[3]);
	if(!input.is_open()){ output_message(0, "Couldn't open input file."); return 1; }
	if(!output.is_open()){ output_message(0, "Couldn't open output file."); return 1; }
	if(!contestant.is_open()){ output_message(0, "Couldn't open contestant file."); return 1; }
    
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    string pass; contestant >> pass;
    if(pass!=password) {
        output_message(0, "Contestant wrote to cout!");
    }
    int x,n; input >> x >> n;
    int xc, q; contestant >> xc >> q;
    if(x!=xc || q<0) { output_message(0, ""); return 1; }
    output_message(min<double>(1.0, 0.1+0.9*pow((double)(ceil((double)log2(n))+1.0)/(double)(q+1), 2.0)), "");
	return 0;
}