#include <iostream>
#include "guess.h"

int pw[50];

int solve(int N) {
    int ans=0, lg=0;
    pw[0]=1;
    for(int i = 1; pw[i-1]+pw[i-1]<=N; i++) {lg=i; pw[i]=pw[i-1]+pw[i-1];}

    for(int i = lg; i >= 0; i--) {
        if(query(ans+pw[i])) ans+=pw[i];
    }
    return ans;
}