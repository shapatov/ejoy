#include <iostream>
#include "guess.h"

long long pw[100];

int solve(int N) {
    long long ans=0, lg=0;
    pw[0]=1;
    for(long long i = 1; pw[i-1]+pw[i-1]<=N; i++) {lg=i; pw[i]=pw[i-1]+pw[i-1];}

    for(long long i = lg; i >= 0; i--) {
        if(query(ans+pw[i])) ans+=pw[i];
    }
    return ans;
}
