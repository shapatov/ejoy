#include <iostream>
#include <random>
#include <fstream>
using namespace std;
mt19937_64 mt(random_device{}());
int main() {
    for(int t = 1; t <= 1; t++) {
        long long a=mt()%(long long)10,b=mt()%(long long)10;
        ofstream in("test."+string(t<=9?"0":"")+to_string(t)+".in");
        ofstream out("test."+string(t<=9?"0":"")+to_string(t)+".out");
        in << a << " " << b;
        out << a-b;
        in.close();
        out.close();
    }
    for(int t = 2; t <= 5; t++) {
        long long a=mt()%(long long)1e8,b=mt()%(long long)1e8;
        ofstream in("test."+string(t<=9?"0":"")+to_string(t)+".in");
        ofstream out("test."+string(t<=9?"0":"")+to_string(t)+".out");
        in << a << " " << b;
        out << a-b;
        in.close();
        out.close();
    }
    for(int t = 6; t <= 10; t++) {
        long long a=mt()%(long long)1e18,b=mt()%(long long)1e18;
        ofstream in("test."+string(t<=9?"0":"")+to_string(t)+".in");
        ofstream out("test."+string(t<=9?"0":"")+to_string(t)+".out");
        in << a << " " << b;
        out << a-b;
        in.close();
        out.close();
    }
}