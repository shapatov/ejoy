#pragma GCC optimize("Ofast")
#pragma GCC target("avx2")

#include <iostream>
#include <cstring>
#include <random>
#include <ctime>
#include <fstream>
#include <stack>
#include <algorithm>
#include <unordered_set>
#include <set>
#include <unordered_map>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;

void solve() {    
    long long a,b;
    cin >> a >> b;
    cout << a-b;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    for(int test = 1; test <= 10; test++) {
        string s = (test<10?"0":"") + to_string(test);
        freopen(("test."+s+".in").c_str(), "r", stdin);
        freopen(("test."+s+".out").c_str(), "w", stdout);
        int t=1; while(t--) solve();
    }
}