#include <iostream>
#include <fstream>
#include <random>
#include <time.h>
#include <assert.h>
#include <set>
#include <queue>
#include <limits.h>
#include <unordered_set>
#include <cstring>
#include <chrono>
using namespace std;
namespace author {
    long long tree[3000000];
    long long lazy[3000000];
    void init() {
        memset(tree, 0, sizeof(tree));
        memset(lazy, 0, sizeof(lazy));
    }
    void push_lazy(int v, int l, int r) {
        if(lazy[v]) {
            tree[v]+=(r-l+1)*lazy[v];
            if(l!=r) {
                lazy[v<<1]+=lazy[v];
                lazy[v<<1|1]+=lazy[v];
            }
            lazy[v]=0;
        }
    }
    void update(int v, int l, int r, int ql, int qr, long long val) {
        push_lazy(v, l, r);
        if(l>qr || r<ql) return;
        if(l>=ql && r<=qr) {
            lazy[v]+=val;
            push_lazy(v, l, r);
            return;
        }
        int mid = (l+r)>>1;
        update(v<<1, l, mid, ql, qr, val);
        update(v<<1|1, mid+1, r, ql, qr, val);
        tree[v]=tree[v<<1]+tree[v<<1|1];
    }
    long long query(int v, int l, int r, int ql, int qr) {
        push_lazy(v, l, r);
        if(l>qr || r<ql) return 0;
        if(l>=ql && r<=qr) return tree[v];
        int mid = (l+r)>>1;
        return query(v<<1, l, mid, ql, qr)+query(v<<1|1, mid+1, r, ql, qr);
    }
};
using namespace author;
int main() {
    mt19937 mt(random_device{}());
    
    for(int i = 1; i <= 3; i++) {
        ofstream in("nod2." + (string)(i<10?"0":"") + to_string(i) + ".in");
        ofstream out("nod2." + (string)(i<10?"0":"") + to_string(i) + ".out");
        int n=1,q=500;
        in << n << " " << q << endl;
        init();
        while(q--) {
            int t=mt()%2+1; in << t << " ";
            int l = 1, r = 1; in << l << " " << r;
            if(t==1) {
                long long x=mt()%(int)1e9+1; in << " " << x;
                update(1, 1, n, l, r, x);
            }
            else {
                out << query(1, 1, n, l, r) << endl;
            }
            in << endl;
        }
        in.close();
        out.close();
    }

    for(int i = 4; i <= 7; i++) {
        ofstream in("nod2." + (string)(i<10?"0":"") + to_string(i) + ".in");
        ofstream out("nod2." + (string)(i<10?"0":"") + to_string(i) + ".out");
        int n=500,q=500;
        in << n << " " << q << endl;
        init();
        while(q--) {
            int t=mt()%2+1; in << t << " ";
            int r = mt()%n+1, l = mt()%r+1; in << l << " " << r;
            if(t==1) {
                long long x=mt()%(int)1e9+1; in << " " << x;
                update(1, 1, n, l, r, x);
            }
            else {
                out << query(1, 1, n, l, r) << endl;
            }
            in << endl;
        }
        in.close();
        out.close();
    }
    for(int i = 8; i <= 12; i++) {
        ofstream in("nod2." + (string)(i<10?"0":"") + to_string(i) + ".in");
        ofstream out("nod2." + (string)(i<10?"0":"") + to_string(i) + ".out");
        int n=500,q=500;
        in << n << " " << q << endl;
        init();
        while(q--) {
            int t=(mt()%10<=8?2:1); in << t << " ";
            int r = n-mt()%10, l = mt()%10+1; in << l << " " << r;
            if(t==1) {
                long long x=mt()%(int)1e9+1; in << " " << x;
                update(1, 1, n, l, r, x);
            }
            else {
                out << query(1, 1, n, l, r) << endl;
            }
            in << endl;
        }
        in.close();
        out.close();
    }
    

    for(int i = 13; i <= 14; i++) {
        ofstream in("nod2." + (string)(i<10?"0":"") + to_string(i) + ".in");
        ofstream out("nod2." + (string)(i<10?"0":"") + to_string(i) + ".out");
        int n=30000,q=30000;
        in << n << " " << q << endl;
        init();
        while(q--) {
            int t=(mt()%10<=8?2:1); in << t << " ";
            int r = n-mt()%10, l = (t==1?r:mt()%r+1); in << l << " " << r;
            if(t==1) {
                long long x=mt()%(int)1e9+1; in << " " << x;
                update(1, 1, n, l, r, x);
            }
            else {
                out << query(1, 1, n, l, r) << endl;
            }
            in << endl;
        }
        in.close();
        out.close();
    }
    for(int i = 15; i <= 16; i++) {
        ofstream in("nod2." + (string)(i<10?"0":"") + to_string(i) + ".in");
        ofstream out("nod2." + (string)(i<10?"0":"") + to_string(i) + ".out");
        int n=30000,q=30000;
        in << n << " " << q << endl;
        init();
        while(q--) {
            int t=mt()%2+1; in << t << " ";
            int r = mt()%n+1, l = (t==1?r:mt()%r+1); in << l << " " << r;
            if(t==1) {
                long long x=mt()%(int)1e9+1; in << " " << x;
                update(1, 1, n, l, r, x);
            }
            else {
                out << query(1, 1, n, l, r) << endl;
            }
            in << endl;
        }
        in.close();
        out.close();
    }

    for(int i = 17; i <= 19; i++) {
        ofstream in("nod2." + (string)(i<10?"0":"") + to_string(i) + ".in");
        ofstream out("nod2." + (string)(i<10?"0":"") + to_string(i) + ".out");
        int n=30000,q=30000;
        in << n << " " << q << endl;
        init();
        while(q--) {
            int t=(mt()%10<=8?2:1); in << t << " ";
            int r = n-mt()%10, l = mt()%10+1; in << l << " " << r;
            if(t==1) {
                long long x=mt()%(int)1e9+1; in << " " << x;
                update(1, 1, n, l, r, x);
            }
            else {
                out << query(1, 1, n, l, r) << endl;
            }
            in << endl;
        }
        in.close();
        out.close();
    }
    for(int i = 20; i <= 22; i++) {
        ofstream in("nod2." + (string)(i<10?"0":"") + to_string(i) + ".in");
        ofstream out("nod2." + (string)(i<10?"0":"") + to_string(i) + ".out");
        int n=30000,q=30000;
        in << n << " " << q << endl;
        init();
        while(q--) {
            int t=mt()%2+1; in << t << " ";
            int r = mt()%n+1, l = mt()%r+1; in << l << " " << r;
            if(t==1) {
                long long x=mt()%(int)1e9+1; in << " " << x;
                update(1, 1, n, l, r, x);
            }
            else {
                out << query(1, 1, n, l, r) << endl;
            }
            in << endl;
        }
        in.close();
        out.close();
    }
    
}