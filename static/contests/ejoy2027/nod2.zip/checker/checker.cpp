#include <bits/stdc++.h>
#include <cassert>
#include <chrono>
using namespace std;
using namespace chrono;
long long m[1000067];
const double tl = 4.5;
long long registers[15];
inline int getreg(const string& s) {return (s=="RES"?0:s[0]-'A'+1);}
enum op { IN, OUT, MOVR, MOVI, ADD, SUB, DIV, MUL, CMP, LOAD, STORE, JZ, JNZ, RET, NOP, ERROR };
struct inst { int op = NOP, a = 0, b = 0; long long val = 0; };
int main(int argc, char *argv[])
{
    auto start = high_resolution_clock::now();
    if(argc<4) {
		cout << 0 << endl;
        cerr << "4 arguments needed!" << endl;
        return 0;
    }
    ifstream file(argv[3]);
    string line;
    vector<inst> code;
    while (getline(file, line)) {
        istringstream iss(line);
        string word;
        vector<string> words;
        while (iss >> word) {
            size_t p = word.find(';');
            if (p != string::npos) { if (p) words.push_back(word.substr(0, p)); break; }
            words.push_back(word);
        }
        inst a;
        if(words.size()==0) { code.push_back(a); continue; }

        if(words[0]=="IN") a.op=IN;
        else if(words[0]=="OUT") a.op=OUT;
        else if(words[0]=="MOV") a.op=MOVR; // default movr
        else if(words[0]=="ADD") a.op=ADD;
        else if(words[0]=="SUB") a.op=SUB;
        else if(words[0]=="DIV") a.op=DIV;
        else if(words[0]=="MUL") a.op=MUL;
        else if(words[0]=="CMP") a.op=CMP;
        else if(words[0]=="LOAD") a.op=LOAD;
        else if(words[0]=="STORE") a.op=STORE;
        else if(words[0]=="JZ") a.op=JZ;
        else if(words[0]=="JNZ") a.op=JNZ;
        else if(words[0]=="RETURN") a.op=RET;
        else { 
            cout << 0 << endl;
            cerr << "Syntax error!" << endl;
            return 0; 
        }
        
        if(words[0]=="RETURN"){}
        else if((words[0]=="JZ"||words[0]=="JNZ")&&words.size()>1) a.a=atoll(words[1].c_str());
        else if (words.size()>1 && (words[1] == "RES" || (words[1].size()==1 && words[1][0] >= 'A' && words[1][0] <= 'H'))) a.a=getreg(words[1]);
        else {
            cout << 0 << endl;
            cerr << "Syntax error!" << endl;
            return 0;
        }
        
        if(words[0]=="RETURN"){}
        else if(words[0]=="IN" || words[0]=="OUT") {}
        else if(words[0]=="JZ"||words[0]=="JNZ") {}
        else if (words.size()>2 && (words[2] == "RES" || (words[2].size()==1 && words[2][0] >= 'A' && words[2][0] <= 'H'))) a.b=getreg(words[2]);
        else if(words[0]=="MOV"&&words.size()>2) {a.val = atoll(words[2].c_str()); a.op=MOVI;}
        else {
            cout << 0 << endl;
            cerr << "Syntax error!" << endl;
            return 0;
        }
        code.push_back(a);
    }
    ifstream input(argv[1]);
	ifstream correct(argv[2]);
	vector<long long> correctAns, inp, contestant;

	long long tmp;
	while(correct >> tmp) correctAns.push_back(tmp);

	while(input >> tmp) inp.push_back(tmp);

    int inputPointer = 0, outputPointer = 0;
    
    long long steps=0;
    for(int lineNum = 0; lineNum < code.size(); lineNum++) {
        steps++;
        double sec;
        if(steps%100000==0) {
            auto end = high_resolution_clock::now();
            auto duration = duration_cast<microseconds>(end-start);
            sec = chrono::duration_cast<chrono::duration<double>>(end - start).count();
            sec=floor(sec*100)/100;
            if(sec>tl) {
                cout << 0 << endl;
                std::cerr << "TL: >=" << sec << " s." << endl;
                return 0;
            }
        }
        const inst& line = code[lineNum];
        switch (line.op) {
            case IN:
                if (inputPointer >= (int)inp.size()) { cout<<0<<endl; cerr<<"Read past input!"<<endl; return 0; }
                registers[line.a] = inp[inputPointer++];
                break;
            case OUT:
                if (outputPointer >= (int)correctAns.size() || correctAns[outputPointer++] != registers[line.a]) {
                    auto end = high_resolution_clock::now();
                    auto duration = duration_cast<microseconds>(end-start);
                    sec = chrono::duration_cast<chrono::duration<double>>(end - start).count();
                    sec=floor(sec*100)/100;
                    cout<<0<<endl; cerr << "WA in " << sec << " s." << endl; return 0;
                }
                break;
            case MOVR: registers[line.a] = registers[line.b]; break;
            case MOVI: registers[line.a] = line.val; break;
            case ADD: registers[line.a] += registers[line.b]; break;
            case SUB: registers[line.a] -= registers[line.b]; break;
            case MUL: registers[line.a] *= registers[line.b]; break;
            case CMP: registers[0] = registers[line.a] <= registers[line.b]; break;
            case DIV:
                if (!registers[line.b]) { cout<<0<<endl; cerr<<"Divide by zero!"<<endl; return 0; }
                registers[line.a] /= registers[line.b];
                break;
            case LOAD:
                if (registers[line.a] < 0 || registers[line.a] > 999999) { cout<<0<<endl; cerr<<"Invalid array index!"<<endl; return 0; }
                registers[line.b] = m[registers[line.a]];
                break;
            case STORE:
                if (registers[line.a] < 0 || registers[line.a] > 999999) { cout<<0<<endl; cerr<<"Invalid array index!"<<endl; return 0; }
                m[registers[line.a]] = registers[line.b];
                break;
            case JZ: 
                if (registers[0] == 0) {
                    if (line.a < 1 || line.a > (int)code.size()) { cout<<0<<endl; cerr<<"Invalid jump index!"<<endl; return 0; }
                    lineNum = line.a - 2;
                }
                break;
            case JNZ: 
                if (registers[0] != 0) {
                    if (line.a < 1 || line.a > (int)code.size()) { cout<<0<<endl; cerr<<"Invalid jump index!"<<endl; return 0; }
                    lineNum = line.a - 2;
                }
                break;
            case RET: goto done;
            default: break;
        }
    }
    done:
    if(outputPointer != correctAns.size()) {
		cout << 0 << endl;
        auto end = high_resolution_clock::now();
        auto duration = duration_cast<microseconds>(end-start);
        double sec = chrono::duration_cast<chrono::duration<double>>(end - start).count();
        sec=floor(sec*100)/100;
        cerr << "WA in " << sec << " s." << endl;
		return 0;
	}
    auto end = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(end-start);
    double sec = chrono::duration_cast<chrono::duration<double>>(end - start).count();
    sec=floor(sec*100)/100;
    if(sec>tl) {
        cout << 0 << endl;
        std::cerr << "TL: >=" << sec << " s." << endl;
        return 0;
    }
    cout << 1 << endl;
    cerr << "OK in " << sec << " s." << endl;
    file.close();
    input.close();
}