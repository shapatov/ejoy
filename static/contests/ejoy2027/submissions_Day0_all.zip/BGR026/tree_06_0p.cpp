#include "tree.h"
#include <bits/stdc++.h>


using namespace std;


const int MAXN = 1e5;

int par[MAXN + 5];
vector<int>graph[MAXN + 5];

void dfs(int node, int parent)
{
    par[node] = parent;

    for(auto i: graph[node])
    {
        if(i == parent)continue;
        dfs(i, node);
    }
}

string encode(int n, vector<pair<int, int>> v)
{
    string ans;
    
    for(int i = 0; i < v.size(); i++)
    {
        graph[v[i].first].push_back(v[i].second);
        graph[v[i].second].push_back(v[i].first);
    }
    
    dfs(1, 0);

    for(int i = 2; i <= n; i++)
    {
        int node = par[i];

        for(int bit = 0; bit < 17; bit++)
        {
            if((1 << bit) & node)
            {
                ans.push_back('1');
            }
            else ans.push_back('0');
        }
    }
    
    return ans;
}

vector<pair<int, int>> decode(int n, string s)
{
    vector<pair<int,int>>ans;

    int node = 2;
    for(int i = 0; i < s.size(); i += 17)
    {
        int parent = 0;
        for(int bit = 0; bit < 17; bit++)
            parent += (s[i + bit] - '0') * (1 << bit);
    }

    return ans;
}
