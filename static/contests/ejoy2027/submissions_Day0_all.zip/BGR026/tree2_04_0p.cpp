#include "tree2.h"
#include <bits/stdc++.h>

using namespace std;

const int MAXN = 1e5;

vector<int>tour;
vector<int>graph[MAXN + 5];
int dp[MAXN + 5], par[MAXN + 5];

void dfs(int node, int parent)
{
    tour.push_back(node);
    for(auto i: graph[node])
    {
        if(i == parent) continue;
        dfs(i, node);
    }
}

std::vector<int> encode(int n, std::vector<std::pair<int, int>> v)
{
    for(auto i: v)
    {
        graph[i.first].push_back(i.second);
        graph[i.second].push_back(i.first);
    }

    dfs(1, 0);
    int maxi = 0, endd = 0;

    for(int i = 0; i < tour.size(); i++)
    {
        for(int j = 0; j < i; j++)
        {
            if(tour[i] > tour[j] && dp[i] < dp[j] + 1)
            {
                par[i] = j;
                dp[i] = dp[j] + 1;
            }
        }

        if(dp[i] > maxi)
        {
            endd = i;
            maxi = dp[i];
        }
    }

    vector<int>ans;

    int node = endd;
    while(node != 0)
    {
        ans.push_back(node);
        node = par[node];
    }


    reverse(ans.begin(), ans.end());
    return ans;
}

vector<int>tour1;
unordered_map<int, bool>iz;
map<int, vector<int>>graph1;
unordered_map<int, int>used;

void dfs1(int node, int parent)
{
    tour1.push_back(node);
    for(auto i: graph1[node])
    {
        if(i == parent) continue;
        dfs1(i, node);
    }
}

std::vector<std::pair<int, int>> decode(int n, std::vector<std::pair<int,int>> v)
{
    vector<pair<int, int>>ans;

    for(int i = 0; i < v.size(); i++)
    {
        int x = v[i].first, y = v[i].second;

        if(x > 0)iz[x] = true;
        if(y > 0)iz[y] = true;

        graph1[x].push_back(y);
        graph1[y].push_back(x);
    }

    int r = 1;
    if(!iz[1])r = -1;

    dfs1(r, 0);

    vector<int>m;
    for(int i = 1; i <= n; i++)
    {
        if(!iz[i])
            m.push_back(i);
    }

    vector<int>ve;
    for(int i : tour1)
    {
        if(i < 0)
            ve.push_back(i);
    }

    for(int i = 1; i <= n; i++)
        if(iz[i])used[i] = i;

    for(int i = 0; i < ve.size(); i++)
        used[ve[i]] = m[i];


    for(int i = 0; i < v.size(); i++)
        ans.push_back({used[v[i].first], used[v[i].second]});


    return ans;
}
