#include "tree2.h"
#include <bits/stdc++.h>


using namespace std;


const int MAXN = 1e5;

int par[MAXN + 5];
vector<int>tour;
vector<int>graph[MAXN + 5];


std::vector<int> encode(int N, std::vector<std::pair<int, int>> v);
{
    for(auto i: v)
    {
        graph[i.first].push_back(i.second);
        graph[i.second].push_back(i.first);
    }
    
    //dfs(1);
    
    return {1};
}

std::vector<std::pair<int, int>> decode(int N, std::vector<std::pair<int,int>> v);
{
    vector<pair<int,int>>ans;
    for(int i = 0; i < v.size(); i++)
    {
        if(v[i].first == -1)
        {
            ans.push_back({1, v[i].second});
        }
        if(v[i].second == -1)
        {
            ans.push_back({1, v[i].first});
        }
    }
    
    return ans;
}
