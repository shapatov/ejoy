#include "guess.h"
#include <iostream>


using namespace std;

int solve(int n)
{
    int l = 1, r = n, ans = -1;

    while(l <= r)
    {
        int mid = 0, mn = 1e9;
        for(int iter = 0; iter < 30; iter++)
        {
            int curr = min(l + (rand() % (r - l + 1)), r);
            
            if(mn > (curr - l) - (r - curr))
            {
                mn = (curr - l) - (r - curr);
                mid = curr;
            }
        }

        if(query(mid))
        {
            ans = mid;
            l = mid + 1;
        }
        else r = mid - 1;
    }
    return ans;
}