#include "guess.h"
#include <iostream>


using namespace std;

int find_mid(int l, int r)
{
    
    for(int mid = l; mid <= r; mid++)
    {
        if(mid - l == r - mid)
        {
            return mid;
        }
    }
    
    for(int mid = l; mid <= r; mid++)
    {
        if(mid - l == r - mid + 1)
        {
            return mid;
        }
    }
    
}

int solve(int n)
{
    int l = 1, r = n, ans = -1;
    
    while(l <= r)
    {
        int mid = find_mid(l, r);
        
        if(query(mid))
        {
            ans = mid;
            l = mid + 1;
        }
        else r = mid - 1;
    }
    return ans;
}
