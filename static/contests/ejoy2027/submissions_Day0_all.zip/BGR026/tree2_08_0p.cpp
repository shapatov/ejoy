#include "tree2.h"
#include <bits/stdc++.h>

using namespace std;

const int MAXN = 1e5;

vector<int>tour;
vector<int>graph[MAXN + 5];
int dp[MAXN + 5], par[MAXN + 5];
pair<int,int>tree[4 * MAXN + 5];

void dfs(int node, int parent)
{
    tour.push_back(node);
    for(auto i: graph[node])
    {
        if(i == parent) continue;
        dfs(i, node);
    }
}

void update(int v, int l, int r, int pos, pair<int,int>val)
{
    if(l == r)
    {
        tree[v] = max(tree[v], val);
        return;
    }

    int mid = (l + r) / 2;

    if(mid <= pos)update(v * 2, l, mid, pos,  val);
    else update(v * 2 + 1, mid + 1, r, pos,  val);

    tree[v] = max(tree[v * 2], tree[v * 2 + 1]);
}

pair<int,int> query(int v, int l, int r, int ql, int qr)
{
    if(ql > r || l > qr)return {0, -1};
    if(ql <= l && r <= qr)return tree[v];

    int mid = (l + r) / 2;
    return max(query(v * 2, l, mid, ql, qr), query(v * 2 + 1, mid + 1, r, ql, qr));
}

std::vector<int> encode(int n, std::vector<std::pair<int, int>> v)
{
    for(auto i: v)
    {
        graph[i.first].push_back(i.second);
        graph[i.second].push_back(i.first);
    }


    dfs(1, 0);
    int maxi = 0, endd = 0;

    for(int i = 0; i < tour.size(); i++)
        par[i] = -1;

    for(int i = 0; i < tour.size(); i++)
    {
        int val = tour[i];
        pair<int,int>curr = {0, -1};
        if(val > 1)
            curr = query(1, 1, n, 1, val - 1);

        dp[i] = curr.first + 1;
        par[i] = curr.second;

        update(1, 1, n, val, {dp[i], i});

        if(dp[i] > maxi)
        {
            maxi = dp[i];
            endd = i;
        }

    }

    vector<int>ans;

    int node = endd;
    while(node != -1)
    {
        ans.push_back(tour[node]);
        node = par[node];
    }


    reverse(ans.begin(), ans.end());
    return ans;
}

vector<int>tour1;
unordered_map<int, bool>iz;
map<int, vector<int>>graph1;
unordered_map<int, int>used;

void dfs1(int node, int parent)
{
    tour1.push_back(node);
    for(auto i: graph1[node])
    {
        if(i == parent) continue;
        dfs1(i, node);
    }
}

std::vector<std::pair<int, int>> decode(int n, std::vector<std::pair<int,int>> v)
{
    vector<pair<int, int>>ans;

    for(int i = 0; i < v.size(); i++)
    {
        int x = v[i].first, y = v[i].second;

        if(x > 0)iz[x] = true;
        if(y > 0)iz[y] = true;

        graph1[x].push_back(y);
        graph1[y].push_back(x);
    }

    int r = 1;
    if(!iz[1])r = -1;

    dfs1(r, 0);

    vector<int>m;
    for(int i = 1; i <= n; i++)
    {
        if(!iz[i])
            m.push_back(i);
    }

    vector<int>ve;
    for(int i : tour1)
    {
        if(i < 0)
            ve.push_back(i);
    }

    for(int i = 1; i <= n; i++)
        if(iz[i])used[i] = i;

    for(int i = 0; i < ve.size(); i++)
        used[ve[i]] = m[i];


    for(int i = 0; i < v.size(); i++)
        ans.push_back({used[v[i].first], used[v[i].second]});


    return ans;
}
