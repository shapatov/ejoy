#include <iostream>
#include <vector>
#include "tree.h"
using namespace std;

string encode(int n, vector<pair<int, int>> v) {
    return "";
}

vector<pair<int, int>> decode(int n, string s) {
    return {};
}