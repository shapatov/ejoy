#include "guess.h"
#include <iostream>


using namespace std;

int solve(int n)
{
    srand(time(0));
    int l = 1, r = n, ans = -1;

    while(l <= r)
    {
        int mid = l + (rand() % (r - l + 1)) + 670;
        
        if(mid > r)
        {
            mid = r;
            r -= 6700;
        }
        
        mid = max(mid, l);

        if(query(mid))
        {
            ans = mid;
            l = mid + 1;
        }
        else r = mid - 1;
    }
    return ans;
}
