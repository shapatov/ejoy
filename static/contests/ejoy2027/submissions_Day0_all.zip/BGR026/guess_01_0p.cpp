#incldude "guess.h"
#include <bits/stdc++.h>


using namespace std;


int solve(int n)
{
    int l = 1, r = 1e6, ans = -1;
    
    
    while(l <= r)
    {
        int mid = (l + r) / 2;
        
        if(query(mid))
        {
            ans = mid;
            l = mid + 1;
        }
        else r = mid - 1;
    }
    return ans;
}
