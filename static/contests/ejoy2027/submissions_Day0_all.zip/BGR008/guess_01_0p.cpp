#include "guess.h"
int solve(int n) {
    int l = 1, r = n;
    while (l < r) {
        int m = (l + r) / 2;
        if (query(m)) {
            l = m;
        } else {
            r = m - 1;
        }
    }
    return l;
}