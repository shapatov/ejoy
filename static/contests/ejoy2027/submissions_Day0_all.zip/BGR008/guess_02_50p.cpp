#include "guess.h"
int solve(int n) {
    int l = 1, r = n;
    while (l < r) {
        int d = r - l;
        int m = l;
        int step = d;
        while (step > 1) {
            step = step - 2;
            m = m + 1;
        }
        if (query(m)) {
            l = m;
        } else {
            r = m - 1;
        }
    }
    return l;
}