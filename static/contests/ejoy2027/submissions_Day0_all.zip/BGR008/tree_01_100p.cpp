#include <bits/stdc++.h>
std :: string encode(int n, std :: vector<std :: pair<int, int>> edges) {
    std :: vector<std :: vector<int>> graph(n + 1);
    std :: vector<int> deg(n + 1, 0);
    for (auto [a, b] : edges) {
        graph[a].push_back(b);
        graph[b].push_back(a);
        deg[a]++;
        deg[b]++;
    }
    int k = 0;
    while ((1LL << k) < n) {
        k++;
    }
    std :: priority_queue<int, std :: vector<int>, std :: greater<int>> leaves;
    for (int i = 1; i <= n; i++) {
        if (deg[i] == 1) {
            leaves.push(i);
        }
    }
    std :: string s;
    s.reserve((n - 2) * k);
    for (int step = 0; step < n - 2; step++) {
        while (!leaves.empty() && deg[leaves.top()] != 1) {
            leaves.pop();
        }
        int v = leaves.top();
        leaves.pop();
        int u = -1;
        for (int to : graph[v]) {
            if (deg[to] > 0) {
                u = to;
                break;
            }
        }
        int code = u - 1;
        for (int bit = k - 1; bit >= 0; bit--) {
            s.push_back(((code >> bit) & 1) ? '1' : '0');
        }
        deg[v] = 0;
        deg[u]--;
        if (deg[u] == 1) {
            leaves.push(u);
        }
    }
    return s;
}
std :: vector<std :: pair<int, int>> decode(int n, std :: string s) {
    int k = 0;
    while ((1LL << k) < n) {
        k++;
    }
    int l = n - 2;
    std :: vector<int> seq(l);
    int pos = 0;
    for (int i = 0; i < l; i++) {
        int x = 0;
        for (int j = 0; j < k; j++) {
            x = (x << 1) | (s[pos++] - '0');
        }
        seq[i] = x + 1;
    }
    std :: vector<int> deg(n + 1, 0);
    for (int x : seq) {
        deg[x]++;
    }
    for (int i = 1; i <= n; i++) {
        deg[i]++;
    }
    std :: priority_queue<int, std :: vector<int>, std :: greater<int>> leaves;
    for (int i = 1; i <= n; i++) {
        if (deg[i] == 1) {
            leaves.push(i);
        }
    }
    std :: vector<std :: pair<int, int>> ans;
    ans.reserve(n - 1);
    for (int i = 0; i < l; i++) {
        while (!leaves.empty() && deg[leaves.top()] != 1) {
            leaves.pop();
        }
        int v = leaves.top();
        leaves.pop();
        int u = seq[i];
        ans.push_back({v, u});
        deg[v]--;
        deg[u]--;
        if (deg[u] == 1) {
            leaves.push(u);
        }
    }
    std :: vector<int> remaining;
    for (int i = 1; i <= n; i++) {
        if (deg[i] == 1) {
            remaining.push_back(i);
        }
    }
    ans.push_back({remaining[0], remaining[1]});
    return ans;
}