#include "guess.h"
int solve(int n) {
    long long poers[64];
    long long cnt = 0;
    long long p = 1;
    while (p <= n) {
        poers[cnt++] = p;
        p += p;
    }
    long long l = 1, r = n;
    while (l < r) {
        long long d = r - l;
        long long half_d = 0;
        long long rem = d;
        for (long long i = cnt - 1; i >= 0; i--) {
            long long bit = poers[i];
            long long two_bit = bit + bit;
            if (rem >= two_bit) {
                half_d = half_d + bit;
                rem = rem - two_bit;
            }
        }
        long long m = l + half_d;
        if (query(m)) {
            l = m;
        } else {
            r = m - 1;
        }
    }
    return l;
}