#include "guess.h"
int solve(int n) {
    int powers[32];
    int cnt = 0;
    int p = 1;
    while (p <= n) {
        powers[cnt++] = p;
        p += p;
    }
    int l = 1, r = n;
    while (l < r) {
        int d = r - l;
        int half_d = 0;
        int rem = d;
        for (int i = cnt - 1; i >= 0; i--) {
            int bit = powers[i];
            int two_bit = bit + bit;
            if (rem >= two_bit) {
                half_d = half_d + bit;
                rem = rem - two_bit;
            }
        }
        int m = l + half_d;
        if (query(m)) {
            l = m;
        } else {
            r = m - 1;
        }
    }
    return l;
}