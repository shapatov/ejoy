#include<bits/stdc++.h>
using namespace std;

const int MAXN = 1e5+7;
int p[MAXN];
vector<int> adj[MAXN];

void dfs(int u, int pp)
{
    p[u] = pp;
    for(int v: adj[u])
    {
        if(v == pp) continue;
        dfs(v, u);
    }
    return;
}

string encode(int n, vector<pair<int, int> > v)
{
    for(int i = 0; i < v.size(); i++)
    {
        adj[v[i].first].push_back(v[i].second);
        adj[v[i].second].push_back(v[i].first);
    }
    dfs(1, 0);
    string s;
    int len = floor(log2(n))+1;
    for(int i = 2; i <= n; i++)
    {
        int cp = p[i];
        for(int j = 0; j < len; j++)
        {
            if(cp%2 == 1) s += '1';
            else s += '0';
            cp /= 2;
        }
    }
    return s;
}

vector<pair<int, int> > decode(int n, string s)
{
    vector<pair<int, int> > ans;
    int len = floor(log2(n))+1;
    for(int i = 0; i <= n-1; i++)
    {
        int a = 0, curr = 1;
        for(int j = len*i; j < len*(i+1); j++)
        {
            a += curr*(s[j]-'0');
            curr *= 2;
        }
        ans.push_back({a, i+2});
    }
    return ans;
}
