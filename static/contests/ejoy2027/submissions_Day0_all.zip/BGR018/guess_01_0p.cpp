#include "guess.h"
#include<bits/stdc++.h>
using namespace std;

int solve(int N)
{
    int l = 0, r = N+1, mid;
    while(l < r-1)
    {
        mid = (l+r)/2;
        if(guess(mid)) l = mid;
        else r = mid;
    }
    return l;
}
