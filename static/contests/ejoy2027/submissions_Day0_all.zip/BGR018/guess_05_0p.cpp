#include "guess.h"
#include<iostream>
using namespace std;

const int MAXN = 1e6+7;
int half[MAXN];

int solve(int N)
{
    half[0] = 0;
    half[1] = 0;
    for(int i = 2; i <= N+N; i++)
    {
        if(half[i-1] == half[i-2]) half[i] = half[i-1]+1;
        else half[i] = half[i-1];
    }
    int l = 0, r = N+1, mid;
    while(l < r-1)
    {
        mid = half[l+r];
        if(query(mid)) l = mid;
        else r = mid;
    }
    return l;
}
