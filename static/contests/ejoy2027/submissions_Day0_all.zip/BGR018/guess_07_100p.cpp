#include "guess.h"
#include<iostream>
using namespace std;

const long long MAXK = 34;
long long st[MAXK];

long long half(long long a)
{
    long long ans = 0, i = MAXK-1;
    while(a > 1)
    {
        while(st[i] > a) i--;
        ans += st[i-1];
        a -= st[i];
    }
    return ans;
}

int solve(int N)
{
    st[0] = 1;
    for(long long i = 1; i < MAXK; i++)
    {
        st[i] = st[i-1]+st[i-1];
    }
    long long l = 0, r = N+1, mid;
    while(l < r-1)
    {
        mid = half(l+r);
        if(query(mid)) l = mid;
        else r = mid;
    }
    return l;
}
