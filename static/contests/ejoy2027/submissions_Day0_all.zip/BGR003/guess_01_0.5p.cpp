#include "guess.h"

int solve(int N)
{
    for (int i = N; i >= 0; --i)
        if (query(i))
            return i;
    return 0;
}