#include "guess.h"
#include<cstdlib>
int solve(int N)
{
    int l = 0, r = N, ans = 0, mid;
    while (l <= r)
    {
        mid = div(l + r,2).quot;
        if (query(mid))
        {
            ans = mid;
            l = mid + 1;
        }
        else
            r = mid - 1;
    }
    return ans;
}