#include <iostream>
#include <vector>
#include "tree.h"
#include <set>
#include <cmath>
#include <functional>
using namespace std;
vector<vector<int>> G;
vector<int> pS;
string encode(int n, vector<pair<int, int>> V)
{
    G.clear();
    pS.clear();
    pS.resize(n + 1);
    G.resize(n + 1);
    for (auto [a, b] : V)
        G[a].push_back(b), G[b].push_back(a);
    int biggestNum = log2(n) + 1;
    function<void(int, int)> dfs = [&](int u, int p)
    {
        for (auto v : G[u])
        {
            if (v == p)
                continue;
            pS[v] = u;
            dfs(v, u);
        }
    };
    dfs(1, -1);
    string s = "";
    for (int j = 2; j <= n; ++j)
        for (int i = 0; i < biggestNum; ++i)
            s += char('0' + bool(pS[j] & (1 << i)));
    return s;
}

vector<pair<int, int>> decode(int n, string s)
{
    vector<pair<int, int>> out;
    int biggestNum = log2(n) + 1;
    int ptr_s = 0;
    for (int i = 2; i <= n; ++i)
    {
        int u = 0;
        for (int i = 0; i < biggestNum; ++i)
            u += (s[ptr_s++] == '1') * (1 << i);
        out.push_back({u, i});
    }
    return out;
}