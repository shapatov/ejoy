#include "guess.h"
#include <cstdlib>
#include <vector>
#include <iostream>
#include <bitset>
using namespace std;
std::vector<int> arr;
bool started = 0;
const int N = 1e7;
int divv(int a)
{
    bitset<32> aa(a);
    bitset<32> b;
    for(int i=0;i<31;++i)b[i]=aa[i+1];
    return b.to_ullong();
}
int solve(int n)
{
    int l = 0, r = n, ans = 0, mid;
    while (l <= r)
    {
        mid = l + divv(r - l);
        if (query(mid))
        {
            ans = mid;
            l = mid + 1;
        }
        else
            r = mid - 1;
    }
    return ans;
}