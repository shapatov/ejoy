#include "tree2.h"
using namespace std;
std::vector<int> encode(int N, std::vector<std::pair<int, int>> v)
{
    return {1};
}

std::vector<std::pair<int, int>> decode(int N, std::vector<std::pair<int, int>> v)
{
    for (auto &[a, b] : v)
    {
        if (a == -1)
            a = 1;
        if (b == -1)
            b = 1;
    }
    return v;
}