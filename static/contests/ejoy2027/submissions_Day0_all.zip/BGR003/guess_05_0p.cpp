#include "guess.h"
#include <cstdlib>
#include <vector>
#include <iostream>
using namespace std;
std::vector<int> arr;
bool started = 0;
const int N = 1e6;
void start()
{
    if (started)
        return;
    started = 1;
    arr.resize(N);
    arr[0] = arr[1] = 0;
    for (int i = 2; i < N; ++i)
    {
        if (i % 2 == 0)
        arr[i] = arr[i - 1] + 1;
        else
        arr[i] = arr[i - 1];
        // cerr << arr[i] << " ";
    }
    // cerr << "\n";
}
int solve(int n)
{
    start();
    int l = 0, r = n, ans = 0, mid;
    while (l <= r)
    {
        mid = arr[(r + l)];
        if (query(mid))
        {
            ans = mid;
            l = mid + 1;
        }
        else
            r = mid - 1;
    }
    return ans;
}