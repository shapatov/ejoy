#include <iostream>
#include <vector>
#include "tree.h"
#include <set>
using namespace std;

string encode(int n, vector<pair<int, int>> V)
{
    set<pair<int, int>> st;
    for (auto [a, b] : V)
        st.insert({min(a, b), max(a, b)});
    string s = "";
    for (int i = 1; i <= n; ++i)
        for (int j = i; j <= n; ++j)
            s += char('0' + st.count({i, j}));
    return s;
}

vector<pair<int, int>> decode(int n, string s)
{
    vector<pair<int, int>> v;
    int cnt = 0;
    for (int i = 1; i <= n; ++i)
        for (int j = i; j <= n; ++j)
            if (s[cnt++] == '1')
                v.push_back({i, j});
    return v;
}