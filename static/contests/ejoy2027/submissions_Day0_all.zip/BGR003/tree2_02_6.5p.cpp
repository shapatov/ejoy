#include "tree2.h"
using namespace std;
std::vector<int> encode(int N, std::vector<std::pair<int, int>> v)
{
    return {1,2};
}

std::vector<std::pair<int, int>> decode(int N, std::vector<std::pair<int, int>> v)
{
    for (auto &[a, b] : v)
    {
        if (a == -1)
            a = 1;
        if (b == -1)
            b = 1;
        if(a<0)a=2;
        if(b<0)b=2;
    }
    return v;
}