#include "tree2.h"
#include <functional>
#include <cmath>
#include <set>
using namespace std;
std::vector<int> encode(int n, std::vector<std::pair<int, int>> V)
{
    vector<vector<int>> G(n + 1);
    vector<int> pS(n + 1), leafS(n + 1);
    for (auto [a, b] : V)
        G[a].push_back(b), G[b].push_back(a);
    int maxLeafs = 0;
    vector<int> ans;
    function<bool(int, int)> dfs = [&](int u, int p)
    {
        int sum = 0, cnt = 0;
        for (auto v : G[u])
        {
            if (v == p)
                continue;
            pS[v] = u;
            sum += dfs(v, u);
            ++cnt;
        }
        if (sum > maxLeafs)
        {
            maxLeafs = sum;
            ans.clear();
            for (auto v : G[u])
            {
                if (leafS[v])
                    ans.push_back(v);
            }
        }
        // cerr << u << " " << cnt << "\n";
        leafS[u] = !cnt;
        return !cnt;
    };
    dfs(1,-1);
    ans.push_back(1);
    return ans;
}

std::vector<std::pair<int, int>> decode(int n, std::vector<std::pair<int, int>> v)
{
    set<int> nizp;
    for (int i = 1; i <= n; ++i)
        nizp.insert(i);
    for (auto &[a, b] : v)
    {
        if (a == -1)
            a = 1;
        if (b == -1)
            b = 1;
        if (a > 0)
            nizp.erase(a);
        if (b > 0)
            nizp.erase(b);
    }
    for (auto &[a, b] : v)
    {
        if (a < 0)
        {
            a = *nizp.begin();
            nizp.erase(nizp.begin());
        }
        if (b < 0)
        {
            b = *nizp.begin();
            nizp.erase(nizp.begin());
        }
    }
    return v;
}