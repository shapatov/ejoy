#include <iostream>
#include <vector>
#include "tree.h"
#include <set>
#include <cmath>
using namespace std;

string encode(int n, vector<pair<int, int>> V)
{
    int biggestNum = log2(n) + 1;
    string s = "";
    for (auto [u, v] : V)
    {
        // cerr << u << " " << v << "\n";
        for (int i = 0; i < biggestNum; ++i)
            s += char('0' + bool(u & (1 << i)));
        for (int i = 0; i < biggestNum; ++i)
            s += char('0' + bool(v & (1 << i)));
    }
    return s;
}

vector<pair<int, int>> decode(int n, string s)
{
    vector<pair<int, int>> out;
    int biggestNum = log2(n) + 1;
    int ptr_s = 0;
    for (int i = 0; i < n - 1; ++i)
    {
        int u = 0, v = 0;
        for (int i = 0; i < biggestNum; ++i)
            u += (s[ptr_s++] == '1') * (1 << i);
        for (int i = 0; i < biggestNum; ++i)
            v += (s[ptr_s++] == '1') * (1 << i);
        out.push_back({u, v});
    }
    return out;
}