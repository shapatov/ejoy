#include <iostream>
#include <vector>
#include <cmath>
#include "tree.h"
using namespace std;
const int maxn=1e5+7;
int par[maxn];
vector<int>v2[maxn];
void DFS(int beg, int pr)
{
    par[beg]=pr;
    for(auto nb:v2[beg])
    {
        if(nb==pr)continue;
        DFS(nb,beg);
    }
}
string encode(int n, vector<pair<int, int>> v)
{
    string s="";
    for(auto i:v)
    {
        v2[i.first].push_back(i.second);
        v2[i.second].push_back(i.first);
    }
    DFS(1,0);
    int sz=log2(n)+1;
    for(int i=2;i<=n;i++)
    {
        for(int j=0;j<sz;j++)
        {
            bool add=(par[i]&(1<<j));
            s+=add+'0';
        }
    }
    return s;
}

vector<pair<int, int>> decode(int n, string s)
{
    vector<pair<int,int>>v;
    int sz=log2(n)+1;
    int p=0;
    for(int i=2;i<=n;i++)
    {
        int pp=0;
        for(int j=0;j<sz;j++)
        {
            if(s[p]=='1')pp+=(1<<j);
            p++;
        }
        v.push_back({pp,i});
    }
    return v;
}
