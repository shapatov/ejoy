#include <bits/stdc++.h>
#include "tree2.h"
using namespace std;

vector<int> encode(int n, vector<pair<int, int>> v) {
    vector <int> m;
    m.push_back(1);
    return m;
}

vector<pair<int, int>> decode(int n, vector<pair<int,int>> v) {
    for (int i=0;i<v.size();i+=1) {
        if (v[i].first==-1) v[i].first=1;
        if (v[i].second==-1) v[i].second=1;
    }
    return v;
}