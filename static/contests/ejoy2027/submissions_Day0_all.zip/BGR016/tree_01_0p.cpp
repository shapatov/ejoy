#include <bits/stdc++.h>
#include "tree.h"
using namespace std;

string encode(int n, vector<pair<int, int>> v) {
    string s="";
    for (pair <int, int> p:v) {
        s+=to_string(p.first)+" "+to_string(p.second)+";";
    }
    return s;
}

vector<pair<int, int>> decode(int n, string s) {
    vector <pair <int, int>> v;
    int i=0;
    bool t=0;
    v.push_back({0, 0});
    for (char c:s) {
        if (c==' ') {
            t=1;
            continue;
        }
        if (c==';') {
            t=0;
            v.push_back({0, 0});
            i+=1;
            continue;
        }
        if (t==0) {
            v[i].first*=10;
            v[i].first+=c-'0';
        }
        if (t==1) {
            v[i].second*=10;
            v[i].second+=c-'0';
        }
    }
    v.pop_back();
    return v;
}