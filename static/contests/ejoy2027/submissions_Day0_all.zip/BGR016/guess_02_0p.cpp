#include <bits/stdc++.h>
#include "guess.h"
using namespace std;

int solve(int n) {
    int l=1, r=n+1,  m=0;
    while (l+1<r) {
        m=(l+r)/2;
        if (query(m)) l=m;
        else r=m;
    }
    return l;
}