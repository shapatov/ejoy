#include <bits/stdc++.h>
#include "tree2.h"
using namespace std;

vector<int> encode(int n, vector<pair<int, int>> v) {
    vector <int> m;
    m.push_back(1);
    return m;
}

vector<pair<int, int>> decode(int n, vector<pair<int,int>> v) {
    vector <pair <int, int>> nv;
    for (pair <int, int> p:v) {
        if (p.first==-1) p.first=1;
        if (p.second==-1) p.second=1;
    }
    return nv;
}