#include <iostream>
#include "guess.h"
using namespace std;

long long int f(long long int x=0) {
    long long int p=0;
    while (x>=2) {
        long long int o=1, t=2;
        while (t+t<=x){
            t+=t;
            o+=o;
        }
        x-=t;
        p+=o;
    }
    return p;
}

long long int solve(int n) {
    long long int l=1, r=n+1,  m=0;
    while (l+1<r) {
        m=f(l+r);
        if (query(m)) l=m;
        else r=m;
    }
    return l;
}