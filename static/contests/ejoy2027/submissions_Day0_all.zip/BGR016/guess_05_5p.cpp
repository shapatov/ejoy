#include <iostream>
#include "guess.h"
using namespace std;

int f(int x=0) {
    int p=0;
    while (x>=2) {
        int o=1, t=2;
        while (t+t<=x){
            t+=t;
            o+=o;
        }
        x-=t;
        p+=o;
    }
    return p;
}

int solve(int n) {
    int l=1, r=n+1,  m=0;
    while (l+1<r) {
        m=f(l+r);
        if (query(m)) l=m;
        else r=m;
    }
    return l;
}