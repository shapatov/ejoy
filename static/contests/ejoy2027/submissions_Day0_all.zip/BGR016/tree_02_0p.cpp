#include <bits/stdc++.h>
#include "tree.h"
using namespace std;

string encode(int n, vector<pair<int, int>> v) {
    string s="";
    bool brm[n+1][n+1]{};
    for (pair <int, int> p:v) {
        brm[p.first][p.second]=1;
        brm[p.second][p.first]=1;
    }
    for (int i=1;i<=n;i+=1) {
        for (int j=i+1;j<=n;j+=1) {
            s+=to_string(int(brm[i][j]));
        }
    }
    return s;
}

vector<pair<int, int>> decode(int n, string s) {
    vector <pair <int, int>> v;
    int l=0;
    for (int i=1;i<=n;i+=1) {
        for (int j=i+1;j<=n;j+=1) {
            if (s[l]-'0') v.push_back({i, j});
            l+=1;
        }
    }
    return v;
}