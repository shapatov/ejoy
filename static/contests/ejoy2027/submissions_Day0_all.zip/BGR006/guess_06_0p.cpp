#include <random>
#include "guess.h"
using namespace std;

static mt19937 gen(random_device{}());

int Rand(int l, int r)
{
    uniform_int_distribution<int> dist(l, r);
    return dist(gen);
}

int solve(int n)
{
    srand(time(nullptr));
    int l = 0, r = n + 1, mid;
    while (r - l > 1)
    {
        mid = Rand(l + 1, r - 1);
        if (query(mid))
            l = mid;
        else
            r = mid;
    }
    return l;
}