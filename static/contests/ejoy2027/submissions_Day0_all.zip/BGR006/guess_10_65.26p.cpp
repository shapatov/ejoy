#include <random>
#include "guess.h"
using namespace std;

static mt19937 gen(random_device{}());

int Rand(int l, int r)
{
    uniform_int_distribution<int> dist(l, r);
    return dist(gen);
}

int solve(int n)
{
    int l = 0, r = n + 1, mid, op = (1e5),op2 = (2e5);
    while (r - l > 1)
    {
        if (r - l <= op2)
            op = 1;
        mid = Rand(l + op, r - op);
        if (query(mid))
            l = mid;
        else
            r = mid;
    }
    return l;
}