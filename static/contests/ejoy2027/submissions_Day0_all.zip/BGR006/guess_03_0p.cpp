#include <random>
#include "guess.h"
using namespace std;

int solve(int n)
{
    srand(time(nullptr));
    int l = 0, r = n + 1, mid;
    while (r - l > 1)
    {
        mid = rand() % (r - l + 1) + l;
        if (query(mid))
            l = mid;
        else
            r = mid;
    }
    return l;
}