#include "tree2.h"
#include <bits/stdc++.h>
using namespace std;
vector <int> v[262144];
vector <int> ret,ord;
map <int,int> u,used;
int ti=0,last[262144],c[262144];
void dfs(int beg,int par)
{
    ti++;
    ord.push_back(beg);
    for(auto nb:v[beg])
    {
        if(nb!=par)dfs(nb,beg);
    }
}
std::vector<int> encode(int N, std::vector<std::pair<int, int>> v)
{
    int n=N;
    for(int i=1;i<=N;i++)::v[i].clear();
    for(auto i:v)
    {
        ::v[i.first].push_back(i.second);
        ::v[i.second].push_back(i.first);
    }
    ti=0;
    dfs(1,-1);
    int l=0,br=0;
    ret.clear();
    last[1]=1;
    for(auto i:ord)
    {
        int mx=0,pos=0;
        for(int j=i+1;j<=N;j++)
        {
            if(mx<c[j])
            {
                mx=c[j]+1;
                pos=j;
            }
        }
        last[i]=pos;
        c[i]=mx;
        if(mx==16)
        {
            int st=i;
            while(st!=0)
            {
                ret.push_back(st);
                st=last[st];
            }
            return ret;
        }
    }
    l=N+1,br=0;
    ret.clear();
    for(auto i:ord)
    {
        int mx=0,pos=0;
        for(int j=i-1;j>0;j--)
        {
            if(mx<c[j])
            {
                mx=c[j]+1;
                pos=j;
            }
        }
        last[i]=pos;
        c[i]=mx;
        if(mx==17)
        {
            int st=i;
            while(st!=0)
            {
                ret.push_back(st);
                st=last[st];
            }
            return ret;
        }
    }
}
int t1=0,n;
void dfs1(int beg,int par)
{
    t1++;
    ord.push_back(beg);
    for(auto nb:v[beg])
    {
        if(nb!=par)dfs1(nb,beg);
    }
}
std::vector<std::pair<int, int>> decode(int N, std::vector<std::pair<int,int>> v)
{
    n=N;
    for(int i=0;i<=2*N;i++)::v[i].clear();
    u.clear();
    for(auto i:v)
    {
        if(i.first>0)u[i.first+N]=i.first;
        if(i.first>0)u[i.second+N]=i.second;
        ::v[i.first+N].push_back(i.second+N);
        ::v[i.second+N].push_back(i.first+N);
    }
    u[N-1]=1;
    t1=0;
    dfs1(N-1,-1);
    int cnt=0;
    for(auto i:ord)
    {
        if(i<N)cnt++;
    }
    used.clear();
    if(cnt==16)
    {
        for(auto i:ord)if(i>N)used[i-N]=1;
        int l=1;
        for(auto i:ord)
        {
            if(i<N)
            {
                while(used[l])l++;
                u[i]=l;
                used[l]=1;
            }
        }
    }
    else
    {
        for(auto i:ord)if(i>N)used[i-N]=1;
        int l=n;
        for(auto i:ord)
        {
            if(i<N)
            {
                while(used[l])l--;
                u[i]=l;
                used[l]=1;
            }
        }
    }
    vector <pair <int,int>> ans;
    for(auto i:v)
    {
        ans.push_back({u[i.first+N],u[i.second+N]});
    }
    return ans;
}
