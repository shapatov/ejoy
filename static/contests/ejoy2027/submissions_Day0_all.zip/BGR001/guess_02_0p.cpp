#include "guess.h"
#include <iostream>
using namespace std;
int solve(int N)
{
    srand(time(0));
    int l=1,r=N,mid,ans;
    while(l<=r)
    {
        mid=l+rand()%(r-l+1);
        if(query(mid))
        {
            ans=mid;
            l=mid+1;
        }
        else r=mid-1;
    }
    return ans;
}
