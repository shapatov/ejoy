#include <iostream>
#include <vector>
#include "tree.h"
using namespace std;
vector <int> v[131072];
int par[131072];
void dfs(int beg,int par)
{
    ::par[beg]=par;
    for(auto nb:v[beg])
    {
        if(nb!=par)dfs(nb,beg);
    }
}
string encode(int n, vector<pair<int, int>> v)
{
    int log=0;
    while((1<<log)<=n)log++;
    log--;
    for(int i=1;i<=n;i++)::v[i].clear();
    for(auto i:v)
    {
        ::v[i.first].push_back(i.second);
        ::v[i.second].push_back(i.first);
    }
    dfs(1,-1);
    string s="";
    for(int i=2;i<=n;i++)
    {
        int p=par[i];
        for(int j=0;j<=log;j++)
        {
            if((1<<j)&p)s+='1';
            else s+='0';
        }
    }
    return s;
}

vector<pair<int, int>> decode(int n, string s)
{
    int log=0;
    while((1<<log)<=n)log++;
    log--;
    int p=0;
    vector <pair <int,int>> v;
    v.clear();
    for(int i=2;i<=n;i++)
    {
        int par=0;
        for(int j=0;j<=log;j++)
        {
            if(s[p]=='1')par+=(1<<j);
            p++;
        }
        v.push_back({i,par});
    }
    return v;
}
