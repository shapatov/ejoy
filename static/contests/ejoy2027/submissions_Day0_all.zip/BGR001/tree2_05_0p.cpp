#include "tree2.h"
#include <bits/stdc++.h>
using namespace std;
vector <int> v[262144];
vector <int> ret;
map <int,int> u;
int ti=0;
void dfs(int beg,int par)
{
    ti++;
    if(beg==ti)ret.push_back(beg);
    for(auto nb:v[beg])
    {
        if(nb!=par)dfs(nb,beg);
    }
}
std::vector<int> encode(int N, std::vector<std::pair<int, int>> v)
{
    for(int i=1;i<=N;i++)::v[i].clear();
    for(auto i:v)
    {
        ::v[i.first].push_back(i.second);
        ::v[i.second].push_back(i.first);
    }
    ret.clear();
    ti=0;
    dfs(1,-1);
    return ret;
}
int t1=0,n;
void dfs1(int beg,int par)
{
    t1++;
    if(beg<=n)u[beg]=t1;
    for(auto nb:v[beg])
    {
        if(nb!=par)dfs1(nb,beg);
    }
}
std::vector<std::pair<int, int>> decode(int N, std::vector<std::pair<int,int>> v)
{
    n=N;
    for(int i=1;i<=2*N;i++)::v[i].clear();
    u.clear();
    for(auto i:v)
    {
        if(i.first>0)u[i.first+N]=i.first;
        if(i.first>0)u[i.second+N]=i.second;
        ::v[i.first+N].push_back(i.second+N);
        ::v[i.second+N].push_back(i.first+N);
    }
    u[N-1]=1;
    t1=0;
    dfs1(N-1,-1);
    vector <pair <int,int>> ans;
    for(auto i:v)
    {
        ans.push_back({u[i.first+N],u[i.second+N]});
    }
    return ans;
}
