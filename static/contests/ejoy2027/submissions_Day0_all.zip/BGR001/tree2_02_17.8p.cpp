#include "tree2.h"
#include <bits/stdc++.h>
using namespace std;
vector <int> v[262144];
std::vector<int> encode(int N, std::vector<std::pair<int, int>> v)
{
    for(int i=1;i<=N;i++)::v[i].clear();
    for(auto i:v)
    {
        ::v[i.first].push_back(i.second);
        ::v[i.second].push_back(i.first);
    }
    vector <int> ret;
    for(int i=2;i<=N;i++)
    {
        int mn=1e9;
        for(auto nb: ::v[i])
        {
            mn=min(mn,nb);
        }
        if(i==mn+1)ret.push_back(i);
    }
    return ret;
}

std::vector<std::pair<int, int>> decode(int N, std::vector<std::pair<int,int>> v)
{
    for(int i=1;i<=2*N;i++)::v[i].clear();
    map <int,int> used,u;
    vector <int> nou;
    for(auto i:v)
    {
        if(i.first>0)used[i.first]=1;
        else nou.push_back(i.first+N);
        if(i.second>0)used[i.second]=1;
        else nou.push_back(i.second+N);
        ::v[i.first+N].push_back(i.second+N);
        ::v[i.second+N].push_back(i.first+N);
    }
    u[N+1]=1;
    for(int i=2;i<=N;i++)
    {
        if(!used[i])
        {
            for(auto j:nou)
            {
                if(u[j])continue;
                int mn=1e9;
                for(auto nb: ::v[j])
                {
                    if(u[nb])
                    {
                        mn=min(mn,u[nb]);
                    }
                }
                if(mn+1==i)
                {
                    u[j]=i;
                    break;
                }
            }
        }
        else u[i+N]=i;
    }
    vector <pair <int,int>> ans;
    for(auto i:v)
    {
        ans.push_back({u[i.first+N],u[i.second+N]});
    }
    return ans;
}
