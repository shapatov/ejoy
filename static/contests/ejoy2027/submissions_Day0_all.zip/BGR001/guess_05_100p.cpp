#include "guess.h"
#include <iostream>
using namespace std;
int solve(int N)
{
    srand(time(0));
    long long l=1,r=N,mid,ans;
    while(l<=r)
    {
        long long x=l+r;
        long long l1=l,r1=r,ans1;
        while(l1<=r1)
        {
            mid=l1+rand()%(r1-l1+1);
            if(mid+mid<=x)
            {
                ans1=mid;
                l1=mid+1;
            }
            else r1=mid-1;
        }
        mid=ans1;
        if(query(mid))
        {
            ans=mid;
            l=mid+1;
        }
        else r=mid-1;
    }
    return ans;
}
