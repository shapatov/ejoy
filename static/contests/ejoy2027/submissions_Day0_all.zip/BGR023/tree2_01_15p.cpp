#include "tree2.h"
#include <bits/stdc++.h>
using namespace std;

vector<int> maxIdx;
vector<int> vals;

void update(int idx, int l, int r, int pos, int val) {
    if(l == r) {
        vals[pos] = min(vals[pos], val);
        maxIdx[idx] = l;
        return;
    }
    int mid = (l + r) >> 1;
    if(pos <= mid) {
        update(2 * idx, l, mid, pos, val);
    }
    else {
        update(2 * idx + 1, mid + 1, r, pos, val);
    }
    maxIdx[idx] = (vals[maxIdx[2 * idx]] > vals[maxIdx[2 * idx + 1]] ?
                   maxIdx[2 * idx] : maxIdx[2 * idx + 1]);
}

int query(int idx, int l, int r, int lq, int rq) {
    if(l > rq || r < lq) {
        return vals.size() - 1;
    }
    if(lq <= l && r <= rq) {
        return maxIdx[idx];
    }
    int mid = (l + r) >> 1;
    int L = query(2 * idx, l, mid, lq, rq);
    int R = query(2 * idx + 1, mid + 1, r, lq, rq);
    return (vals[L] > vals[R] ? L : R);
}

vector<vector<int>> to;

vector<int> encode(int N, vector<pair<int, int>> v) {
    to.resize(N + 1);
    for(auto [u, v1] : v) {
        to[u].push_back(v1);
        to[v1].push_back(u);
    }
    maxIdx.resize(3 * N + 11);
    vals.resize(N + 11);
    vector<int> dp(N + 11);
    vector<int> revert(N + 11);
    for(int i = 0; i < revert.size(); i++) {
        revert[i] = -1;
    }
    int maxx = -1, idx;
    for(int i = 1; i <= N; i++) {
        for(int j = 1; j < i; j++) {
            if(to[i].size() > to[j].size()) {
                if(dp[i] < dp[j] + 1) {
                    revert[i] = j;
                    dp[i] = dp[j] + 1;
                }
            }
        }
        if(maxx < dp[i]) {
            idx = i;
            maxx = dp[i];
        }
    }
    vector<int> ans;
    while(revert[idx] != -1) {
        ans.push_back(idx);
        idx = revert[idx];
    }
    return ans;
}

vector<pair<int, int>> decode(int N, vector<pair<int,int>> v) {
    unordered_map<int, vector<int>> unto;
    unordered_set<int> haha;
    vector<bool> res(N + 1);
    for(auto [u, v1] : v) {
        unto[u].push_back(v1);
        unto[v1].push_back(u);
        if(v1 > 0) res[v1] = true;
        if(u > 0) res[u] = true;
        haha.insert(u);
        haha.insert(v1);
    }
    vector<pair<int, int>> vec;
    for(int k : haha) {
        vec.push_back({unto[k].size(), k});
    }
    sort(vec.begin(), vec.end());
    vector<int> sd;
    int jk = 0;
    for(int i = 1; i <= N; i++) {
        if(!res[i]) {
            sd.push_back(i);
        }
    }
    unordered_map<int, int> disc;
    for(int i = 0; i < vec.size(); i++) {
        if(vec[i].second < 0) {
            disc[vec[i].second] = sd[jk++];
        }
    }
    for(auto& [u, v1] : v) {
        if(u < 0) u = disc[u];
        if(v1 < 0) v1 = disc[v1];
    }
    return v;
}










