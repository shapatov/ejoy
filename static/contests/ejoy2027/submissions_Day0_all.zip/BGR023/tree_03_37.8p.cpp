#include <iostream>
#include <vector>
#include "tree.h"
using namespace std;

vector<int> parents;
vector<vector<int>> to;

void dfs(int curr, int prev) {
    for(int next : to[curr]) {
        if(next != prev) {
            parents[next] = curr;
            dfs(next, curr);
        }
    }
}

string encode(int n, vector<pair<int, int>> v) {
    to.resize(n + 1);
    parents.resize(n + 1);
    for(auto [u, v1] : v) {
        to[u].push_back(v1);
        to[v1].push_back(u);
    }
    dfs(1, 0);
    string ans = "";
    for(int i = 2; i <= n; i++) {
        for(int j = 15; j >= 0; j--) {
            ans += (((parents[i] >> j) & 1) ? "1" : "0");
        }
    }
    return ans;
}

vector<pair<int, int>> decode(int n, string s) {
    vector<pair<int, int>> ans;
    int j = 0;
    for(int i = 2; i <= n; i++) {
        int par = 0;
        for(int k = j; k <= j + 15; k++) {
            par = 2 * par + (s[k] == '1');
        }
        j += 16;
        ans.push_back({i, par});
    }
    return ans;
}













