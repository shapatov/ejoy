#include "guess.h"
#include <bits/stdc++.h>
using namespace std;

int half(int n) {
    int result = 0;

    while (n >= 2) {
        n -= 2;
        result++;
    }

    return result;
}

int solve(int N) {
    int l = 1, r = N, mid, ans = -1;
    while(l <= r) {
        mid = half(l + r);
        if(query(mid)) {
            ans = mid;
            l = mid + 1;
        }
        else {
            r = mid - 1;
        }
    }
    return ans;
}
