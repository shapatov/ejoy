#include "guess.h"
#include <bits/stdc++.h>
using namespace std;

int half(int n) {
    int result = 0;

    while (n >= (int)1e8) {
        n -= (int)1e8;
        result += (int)5e7;
    }

    while (n >= (int)1e7) {
        n -= (int)1e7;
        result += (int)5e6;
    }

    while (n >= (int)1e5) {
        n -= (int)1e5;
        result += (int)5e4;
    }

    while (n >= (int)1e4) {
        n -= (int)1e4;
        result += (int)5e3;
    }

    while (n >= (int)1e3) {
        n -= (int)1e3;
        result += (int)5e2;
    }

    while (n >= 100) {
        n -= 100;
        result += 50;
    }

    while (n >= 10) {
        n -= 10;
        result += 5;
    }

    while (n >= 2) {
        n -= 2;
        result += 1;
    }

    return result;
}

int solve(int N) {
    int l = 1, r = N, mid, ans = -1;
    while(l <= r) {
        mid = half(l + r);
        if(query(mid)) {
            ans = mid;
            l = mid + 1;
        }
        else {
            r = mid - 1;
        }
    }
    return ans;
}
