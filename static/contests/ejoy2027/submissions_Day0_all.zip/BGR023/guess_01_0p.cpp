#include "guess.h"
#include <bits/stdc++.h>
using namespace std;

int solve(int N) {
    int l = 1, r = N, mid, ans = -1;
    while(l <= r) {
        mid = (l + r) >> 1;
        if(query(mid)) {
            ans = mid;
            l = mid + 1;
        }
        else {
            r = mid - 1;
        }
    }
    return ans;
}
