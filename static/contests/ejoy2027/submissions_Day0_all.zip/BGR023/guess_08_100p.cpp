#include "guess.h"
#include <iostream>
using namespace std;

long long half(long long n) {
    int result = 0;

    while (n >= (int)2e9) {
        n -= (int)2e9;
        result += (int)1e9;
    }

    while (n >= (int)1e9) {
        n -= (int)1e9;
        result += (int)5e8;
    }

    while (n >= (int)1e8) {
        n -= (int)1e8;
        result += (int)5e7;
    }

    while (n >= (int)1e8) {
        n -= (int)1e8;
        result += (int)5e7;
    }

    while (n >= (int)1e7) {
        n -= (int)1e7;
        result += (int)5e6;
    }

    while (n >= (int)1e5) {
        n -= (int)1e5;
        result += (int)5e4;
    }

    while (n >= (int)1e4) {
        n -= (int)1e4;
        result += (int)5e3;
    }

    while (n >= (int)1e3) {
        n -= (int)1e3;
        result += (int)5e2;
    }

    while (n >= 100) {
        n -= 100;
        result += 50;
    }

    while (n >= 10) {
        n -= 10;
        result += 5;
    }

    while (n >= 2) {
        n -= 2;
        result += 1;
    }

    return result;
}

int solve(int N) {
    long long l = 1, r = N, mid, ans = -1;
    while(l <= r) {
        mid = half(l + r);
        if(query(mid)) {
            ans = mid;
            l = mid + 1;
        }
        else {
            r = mid - 1;
        }
    }
    return ans;
}
