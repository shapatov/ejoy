#include "guess.h"


int solve(int n)
{
    int l = 1 , r = n + 1;
    while (l < r)
    {
        int mid = (int)((double)(l + r) * 0.5);

        if (query(mid))
            l = mid + 1;
        else
            r = mid;
    }

    return l - 1;
}