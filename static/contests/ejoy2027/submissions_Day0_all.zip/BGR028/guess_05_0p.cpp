#include "guess.h"


int solve(int n)
{
    int l = 1 , r = n + 1;
    while (l < r)
    {
        int mid = (l + r) >> 1;

        if (query(mid))
            l = mid + 1;
        else
            r = mid;
    }

    return l - 1;
}