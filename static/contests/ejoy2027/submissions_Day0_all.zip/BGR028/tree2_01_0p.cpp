#include "tree2.h"

/**
____    ____    ____    __________________    ____    ____    ____
||I ||  ||c ||  ||e ||  ||                ||  ||M ||  ||a ||  ||n ||
||__||  ||__||  ||__||  ||________________||  ||__||  ||__||  ||__||
|/__\|  |/__\|  |/__\|  |/________________\|  |/__\|  |/__\|  |/__\|

*/

#include <algorithm>
#include <iostream>
#include <vector>
#include <set>
#include <unordered_map>

#define maxn 200005
#define maxlog 21
#define PB push_back
#define X first
#define Y second
#define control cout<<"passed"<<endl;

typedef long long ll;
typedef std::pair<int, int> pii;
typedef std::pair<ll, ll> pll;
typedef std::pair<int, ll> pil;
typedef std::pair<ll, int> pli;
typedef long double ld;

#pragma GCC optimize("O3" , "Ofast" , "unroll-loops" , "fast-math")
#pragma GCC target("avx2")


const ll mod = 1e9 + 7;
const ll INF = 4e18;
const double eps = 1e-12;

std::vector <int> calclis(std::vector <int> a)
{
    std::vector <int> ta , taidx , par(a.size() , -1);

    for (int i = 0; i < a.size(); i++)
    {
        auto it = std::lower_bound(ta.begin(), ta.end(), a[i]);
        if (it == ta.end())
        {
            if (ta.size() > 0)
                par[i] = taidx.back();
            ta.PB(a[i]);
            taidx.PB(i);
        }
        else
        {
            int idx = std::distance(ta.begin(), it);
            if (idx > 0)
                par[i] = taidx[idx - 1];
            ta[idx] = a[i];
            taidx[idx] = i;
        }
    }

    std::vector <int> ret;
    if (taidx.size() == 0)
        return ret;

    int curr = taidx.back();
    while (curr != -1)
    {
        ret.PB(a[curr]);
        curr = par[curr];
    }
    std::reverse(ret.begin(), ret.end());
    return ret;
}


void dfs(int node , int pp , std::vector <std::vector <int>>& v , std::vector <int>& c)
{
    for (auto& nb : v[node])
    {
        if (nb == pp)
            continue;

        if (c[node] == 0)
            c[nb] = 1;
        else
            c[nb] = 0;
        dfs(nb , node , v , c);
    }
}

std::vector<int> encode(int N, std::vector<std::pair<int, int>> vvv)
{
    int n = N;


    std::vector <std::vector <int>> v(n + 1);

    for (auto& e : vvv)
    {
        v[e.X].PB(e.Y);
        v[e.Y].PB(e.X);
    }

    std::vector <int> c(n + 1 , -1);
    c[1] = 0;
    dfs(1 , 0 , v , c);

    std::vector <int> best;
    for (int col = 0; col <= 1; col++)
    {
        std::vector <int> ii;
        for (int i = 1; i <= n; i++)
            if (c[i] == col)
                ii.PB(i);

        std::vector <std::pair <std::vector <int> , int>> ite;
        for (auto& e : ii)
        {
            std::vector <int> nb = v[e];
            std::sort(nb.begin(), nb.end());
            ite.PB({nb , e});
        }
        std::sort(ite.begin(), ite.end());

        std::vector <int> aa;
        for (auto& it : ite)
            aa.PB(it.Y);

        std::vector <int> lis = calclis(aa);
        if (lis.size() % 2 != 0 && lis.size() > 0)
            lis.pop_back();
        if (lis.size() > best.size())
            best = lis;

        std::vector <int> neg = aa;
        for (auto& e : neg)
            e = -e;

        std::vector <int> _lds = calclis(neg) , lds;
        for (auto& e : _lds)
            lds.PB(-e);

        if (lds.size() % 2 == 0 && lds.size() > 0)
            lds.pop_back();
        if (lds.size() > best.size())
            best = lds;
    }

    while (best.size() > 256)
        best.pop_back();

    return best;
}

std::vector<std::pair<int, int>> decode(int N, std::vector<std::pair<int,int>> vvv)
{
    int n = N;

    std::vector <int> neg;
    std::set <int> pre;

    for (auto& e : vvv)
    {
        if(e.X < 0)
            neg.PB(e.X);
        else
            pre.insert(e.X);

        if (e.Y < 0)
            neg.PB(e.Y);
        else
            pre.insert(e.Y);
    }

    std::sort(neg.begin(), neg.end());
    neg.erase(std::unique(neg.begin(), neg.end()), neg.end());

    if (neg.size() == 0)
        return vvv;

    bool lamp = true;
    if (neg.size() % 2 == 1)
        lamp = false;

    std::vector <int> miss;
    for (int i = 1; i <= n; i++)
        if (pre.find(i) == pre.end())
            miss.PB(i);
    std::sort(miss.begin(), miss.end());

    if (lamp == false)
        std::reverse(miss.begin(), miss.end());

    std::vector <std::vector <int>> v(neg.size());
    for (auto& e : vvv)
        for (int i = 0; i < neg.size(); i++)
        {
            if (e.X == neg[i])
                v[i].PB(e.Y);
            if (e.Y == neg[i])
                v[i].PB(e.X);
        }

    std::vector <std::pair <std::vector <int> , int>> ite;
    for (int i = 0 ;i < neg.size(); i++)
    {
        std::sort(v[i].begin(), v[i].end());
        ite.PB({v[i] , neg[i]});
    }
    std::sort(ite.begin(), ite.end());


    std::unordered_map<int, int> rv;
    for (int i = 0; i < neg.size(); i++)
        rv[ite[i].Y] = miss[i];

    for (auto& e : vvv)
    {
        if (e.X < 0)
            e.X = rv[e.X];
        if (e.Y < 0)
            e.Y = rv[e.Y];
    }

    return v;
}

