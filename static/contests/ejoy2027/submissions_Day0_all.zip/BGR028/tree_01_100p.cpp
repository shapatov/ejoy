
#include "tree.h"

/**
____    ____    ____    __________________    ____    ____    ____
||I ||  ||c ||  ||e ||  ||                ||  ||M ||  ||a ||  ||n ||
||__||  ||__||  ||__||  ||________________||  ||__||  ||__||  ||__||
|/__\|  |/__\|  |/__\|  |/________________\|  |/__\|  |/__\|  |/__\|

*/

#include <iostream>
#include <vector>

#define maxn 200005
#define maxlog 21
#define PB push_back
#define X first
#define Y second
#define control cout<<"passed"<<endl;

typedef long long ll;
typedef std::pair<int, int> pii;
typedef std::pair<ll, ll> pll;
typedef std::pair<int, ll> pil;
typedef std::pair<ll, int> pli;
typedef long double ld;

#pragma GCC optimize("O3" , "Ofast" , "unroll-loops" , "fast-math")
#pragma GCC target("avx2")


const ll mod = 1e9 + 7;
const ll INF = 4e18;
const double eps = 1e-12;

int br(int x)
{
    int ret = 0;
    while (x > 1)
    {
        x /= 2;
        ret++;
    }
    return ret + 1;
}

void dfs(int node , int pp , std::vector <std::vector <int>>& v , std::vector <int>& par)
{
    par[node] = pp;

    for (auto& nb : v[node])
    {
        if (nb == pp)
            continue;
        dfs(nb , node , v , par);
    }
}


std::string encode(int n, std::vector <pii> vvv)
{
    std::vector <std::vector <int>> v(n + 1);

    for (auto& e : vvv)
    {
        v[e.X].PB(e.Y);
        v[e.Y].PB(e.X);
    }

    std::vector <int> par(n + 1 , 0);
    dfs(1 , -1 , v , par);

    std::string ret = "";
    int b = br(n);

    for (int i = 2; i <= n; i++)
        for (int bb = b - 1; bb >= 0; bb--)
            if((par[i] - 1) & (1 << bb))
                ret += '1';
            else
                ret += '0';

    return ret;
}

std::vector <pii> decode(int n, std::string s)
{
    int b = br(n);

    std::vector <pii> ret;
    int idx = 0;

    for (int i = 2; i <= n; i++)
    {
        int cc = 0;
        for (int bb = 0; bb < b; bb++)
            cc = (cc << 1) + (s[idx] - '0') , idx++;

        ret.PB({i , cc + 1});
    }


    return ret;
}