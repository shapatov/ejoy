#include "guess.h"
#include <vector>


int solve(int n)
{
    std::vector <int> p;
    int st = 1;

    while (st <= n)
    {
        p.push_back(st);
        if (st > n - st)
            break;
        st += st;
    }

    int ret = 0;
    for (int i = p.size() - 1; i >= 0; i--)
    {
        int pom = ret + p[i];
        if (pom <= n and query(pom))
            ret = pom;
    }

    return ret;
}