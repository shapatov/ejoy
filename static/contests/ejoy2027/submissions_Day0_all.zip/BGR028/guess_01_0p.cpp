#include "guess.h"

int solve(int n)
{
    ll l = 1 , r = n + 1;
    while (l < r)
    {
        ll mid = (l + r) / 2;

        if (query(mid))
            l = mid + 1;
        else
            r = mid;
    }

    return l - 1;
}