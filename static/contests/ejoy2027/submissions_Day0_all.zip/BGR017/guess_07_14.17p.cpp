#include <iostream>
#include <vector>
#include "guess.h"
using namespace std;

vector<long long> pr, halves;

long long split(long long x){
    pr.clear();
    halves.clear();
    long long p = 2, h = 1;
    while(p <= x) {
        pr.push_back(p);
        halves.push_back(h);
        p += p;
        h += h;
    }
    long long ans = 0;
    long long rem = x;
    for(long long i = (long long)pr.size() - 1; i >= 0; i--){
        if(rem >= pr[i]){
            rem -= pr[i];
            ans += halves[i];
        }
    }
    return ans;
}

int solve(int n) {
    long long l = 1, r = n + n, ans = 1;
    while(l <= r){
        long long m = split(l + r);
        if (query((int)m)){
            ans = m;
            l = m + 1;
        }
        else{
            r = m - 1;
        }
    }
    return (int)ans;
}
