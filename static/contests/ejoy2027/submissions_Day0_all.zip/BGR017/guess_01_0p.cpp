#include<bits/stdc++.h>
#include "guess.h"
using namespace std;

const int MAXN = 2e6;//1e6
int split[MAXN + 4];


int solve(int n){
    int a = 2, b = 1;
    while(a <= n + n){
        split[a] = b; split[a + 1] = b;
        a += a; b += b;
    }
    int l = 1, r = n, ans = 0;
    while(l <= r){
        int m = split[a + b];
        if(query(m)){// x >= y
            ans = m;
            l = m + 1;
        }
        else r = m - 1;
    }
    return ans;
}
