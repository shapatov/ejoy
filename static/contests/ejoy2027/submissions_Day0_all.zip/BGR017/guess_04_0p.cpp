#include<iostream>
#include <vector>
#include "guess.h"
#define int long long
using namespace std;
vector<int> powers, halves;

int split(int x) {
    int p = 2, h = 1;
    while(p <= x){
        powers.push_back(p);
        halves.push_back(h);
        p += p;
        h += h;
    }
    int ans = 0;
    int rem = x;
    for(int i = (int)powers.size() - 1; i >= 0; i--){
        if(rem >= powers[i]) {
            rem -= powers[i];
            ans += halves[i];
        }
    }
    return ans;
}


int32_t solve(int n){
    int l = 1, r = n, ans = 0;
    while(l <= r){
        int m = split(l + r);
        if(query(m)){
            ans = m;
            l = m + 1;
        }
        else r = m - 1;
    }
    return ans;
}
