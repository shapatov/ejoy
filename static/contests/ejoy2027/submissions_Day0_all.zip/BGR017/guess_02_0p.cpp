#include<bits/stdc++.h>
#include "guess.h"
using namespace std;

const int MAXN = 2e6;
int split[MAXN + 4];

int solve(int n){
    split[0] = 0;
    split[1] = 0;
    for(int i = 2; i <= n + n; i++) {
        split[i] = split[i - 2] + 1;
    }
    int l = 1, r = n, ans = 0;
    while(l <= r){
        int m = split[l + r];
        if(query(m)){
            ans = m;
            l = m + 1;
        }
        else r = m - 1;
    }
    return ans;
}
