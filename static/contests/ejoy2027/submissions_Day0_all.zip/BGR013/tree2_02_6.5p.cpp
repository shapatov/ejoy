#include<iostream>
#include<vector>
#include"tree2.h"
using namespace std;
vector<int> encode(int N, vector<pair<int, int>> v)
{
    return {1, 2};
}
vector<pair<int, int>> decode(int N, vector<pair<int,int>> v)
{
    for(int i = 0; i < v.size(); i++)
    {
        if(v[i].first == -1) v[i].first = 1;
        else if(v[i].first < -1) v[i].first = 2;
        if(v[i].second == -1) v[i].second = 1;
        else if(v[i].second < -1) v[i].second = 2;
    }
    return v;
}