#include<iostream>
#include<vector>
#include"guess.h"
using namespace std;
int div2[1000002];
int solve(int N)
{
    for(int i = 0; i <= 500000; i++)
    {
        div2[i+i] = i;
        div2[i+i+1] = i;
    }
    int l = 1, r = 1e6;
    while(l < r)
    {
        int m = div2[l+r+1];
        if(!query(m)) l = m+1;
        else r = m;
    } 
    return l;
}