#include<iostream>
#include<vector>
#include"tree2.h"
using namespace std;
vector<int> encode(int N, vector<pair<int, int>> v)
{
    return {1};
}
vector<pair<int, int>> decode(int N, vector<pair<int,int>> v)
{
    for(int i = 0; i < v.size(); i++)
    {
        if(v[i].first < 0) v[i].first = 1;
        if(v[i].second < 0) v[i].second = 1;
    }
    return v;
}