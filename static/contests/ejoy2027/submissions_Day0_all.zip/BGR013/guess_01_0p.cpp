#include<iostream>
#include<vector>
#include<fstream>
using namespace std;
int main()
{
    int a = 4, b = 2;
    cout<<a/b<<"\n";
    return 0;
}