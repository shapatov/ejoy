#include<iostream>
#include<vector>
#include<numeric>
#include<cmath>
#include"tree.h"
using namespace std;
string parent[100001];
vector<int> adj[100001];
void DFS(int cur, int prev, int log2N)
{
    int temp = prev;
    int bit = 0;
    while(prev)
    {
        if(prev&1) parent[cur][log2N-bit-1] = '1';
        else parent[cur][log2N-bit-1] = '0';
        bit++;
        prev = prev>>1;
    }
    prev = temp;
    for(int next : adj[cur])
    {
        if(next != prev) DFS(next, cur, log2N);
    }
}
string encode(int N, vector<pair<int, int>> v)
{
    string x = "";
    int log2N = floor(log2((double)N)) + 1;
    for(int i = 0; i < log2N; i++)
    {
        x+="0";
    }
    for(int i = 1; i <= N; i++)
    {
        parent[i] = x;
    }
    for(auto [a, b] : v)
    {
        adj[a].push_back(b);
        adj[b].push_back(a);
    }
    DFS(1, 0, log2N);
    string ans = "";
    for(int i = 2; i <= N; i++)
    {
        ans+=parent[i];
    }
    return ans;
}
vector<pair<int, int>> decode(int N, string s)
{
    int log2N = floor(log2((double)N)) + 1;
    vector<pair<int, int>> ans;
    for(int i = 0; i < N-1; i++)
    {
        int cur = 0;
        for(int j = 0; j < log2N; j++)
        {
            cur = cur<<1;
            if(s[i*log2N + j] == '1') cur+=1;
        }
        ans.push_back({i+2, cur});
    }
    return ans;
}