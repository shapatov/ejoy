#include<iostream>
#include<vector>
#include"guess.h"
using namespace std;
long long pow2[35];
long long div2(long long x)
{
    long long cur = 0;
    if(x % 2 == 1) x-=1;
    for(int i = 2; i <= 33; i++)
    {
        if(x%pow2[i]) cur+=pow2[i-2];
        if(x%pow2[i]) x-=pow2[i-1];
    }
    return cur;
}
long long solve(long long N)
{
    pow2[0] = 1;
    for(int i = 1; i <= 34; i++) pow2[i] = pow2[i-1] + pow2[i-1];
    long long l = 1, r = N;
    while(l < r)
    {
        long long m = div2(l+r+1);
        if(!query(m)) r = m-1;
        else l = m;
    } 
    return l;
}