#include<iostream>
#include<vector>
#include<set>
#include<algorithm>
#include"tree2.h"
using namespace std;
vector<pair<int, int>> longest;
vector<int> euler;
vector<int> adj[1400000];
vector<int> ans;
void DFS(int cur, int prev)
{
    if(cur != 1) euler.push_back(cur);
    for(int next : adj[cur])
    {
        if(next != prev) DFS(next, cur);
    }
}
void construct(int a, int b)
{
    ans.push_back(b);
    if(a == 1) return;
    construct(a-1, longest[b].second);
}
vector<int> lis(vector<int> x)
{
    longest.resize(x.size(), {1, 0});
    pair<int, int> end = {1, 0};
    for(int i = 1; i < x.size(); i++)
    {
        for(int j = i-1; j >= 0; j--)
        {
            if(longest[i].first < longest[j].first + 1)
            {
                longest[i].first = longest[j].first + 1;
                longest[i].second = j;
            }
        }
        if(end.first < longest[i].first)
        {
            end.first = longest[i].first;
            end.second = i;
        }
    }
    ans.resize(0);
    construct(end.first, end.second);
    return ans;
}
vector<int> encode(int N, vector<pair<int, int>> v)
{
    euler.resize(0);
    for(int i = 0; i <= 2*N; i++) adj[i].resize(0);
    for(auto [a, b] : v)
    {
        adj[a].push_back(b);
        adj[b].push_back(a);
    }
    DFS(1, 0);
    vector<int> inc = lis(euler);
    return inc;
}
vector<pair<int, int>> decode(int N, vector<pair<int,int>> v)
{
    set<int> removed;
    vector<int> needed(2*N, 0);
    euler.resize(0);
    for(int i = 0; i <= 2*N; i++) adj[i].resize(0);
    for(int i = 1; i <= N; i++) removed.insert(i);
    for(auto [a, b] : v)
    {
        if(a < 0) a = abs(a) + N;
        else removed.erase(a);
        if(b < 0) b = abs(b) + N;
        else removed.erase(b);
        adj[a].push_back(b);
        adj[b].push_back(a);
    }
    vector<int> find2;
    for(int x : removed) find2.push_back(x);
    sort(find2.begin(), find2.end());
    DFS(1, 0);
    int cur = 0;
    for(int i = 0; i < N-1; i++)
    {
        if(euler[i] > N)
        {
            needed[euler[i]] = find2[cur];
            cur++;
        }
    }
    for(int i = 0; i < v.size(); i++)
    {
        if(v[i].first < 0) v[i].first = needed[abs(v[i].first)+N];
        if(v[i].second < 0) v[i].second = needed[abs(v[i].second)+N];
    }
    return v;
}