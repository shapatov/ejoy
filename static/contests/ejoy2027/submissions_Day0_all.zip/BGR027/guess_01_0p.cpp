#include<bits/stdc++.h>
#include "guess.h"
using namespace std;

int solve (int MAX)
{
    int l=0,r=MAX,m;
    while(l<r)
    {
        m=(l+r+1)/2;
        //cout<<m<<endl;
        if(query(m))
        {
            l=m;
        }
        else
        {
            r=m+1;
        }
    }
    return l;
}
