
#include "guess.h"
using namespace std;

int solve(int MAX)
{
    int ans = 0;
    int jump = 1;

    while (ans + jump <= MAX and query(ans + jump))
    {
        ans += jump;
        jump += jump;
    }

    while (jump > 1)
    {
        int half = 0;
        int tmp = jump;
        int s = 1;
        while(s + s <= tmp)
        {
            s += s;
        }
        half = tmp - s;
        jump = half;

        if (ans + jump <= MAX and query(ans + jump))
        {
            ans += jump;
        }
    }
    return ans;
}