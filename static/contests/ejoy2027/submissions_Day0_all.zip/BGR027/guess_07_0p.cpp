#include "guess.h"

int solve(int MAX)
{
    int pos = 0;
    int step = 1;
    while (pos + step <= MAX and query(pos + step))
    {
        pos = pos + step;
        step = step + step;
    }
    while (step > 0)
    {
        step = step - 1;
        if (pos + step <= MAX and query(pos + step))
        {
            pos = pos + step;
        }
    }
    return pos;
}