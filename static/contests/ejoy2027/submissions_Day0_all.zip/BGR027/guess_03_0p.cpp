#include<bits/stdc++.h>
#include "guess.h"
using namespace std;

int ceil_div2(int x)
{
    int res = 0;
    while (x > 1)
    {
        x = x - 2;
        res = res + 1;
    }
    if (x == 1)
    {
        res = res + 1;
    }
    return res;
}

int solve (int MAX)
{
    int l = 0, r = MAX, m;
    while(l < r)
    {
        int total = l + r + 1;
        m = ceil_div2(total);
        
        if(query(m))
        {
            l = m;
        }
        else
        {
            r = m - 1;
        }
    }
    return l;
}