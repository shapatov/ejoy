#include "wordle.h"
#include <bits/stdc++.h>
using namespace std;
namespace gr {
    const string password = "0d97a8f1bc7e9ed10438a5065d8713aa8b3161fc20a6dfe71b61472df0becd91";
    int queries = 0;
    string a; 
    bool found = 0;
    string localQuery(string a1, string b1) {
        string result(5, 'b');
        vector<bool> used(5, 0);

        for (int i = 0; i < 5; i++) {
            if (b1[i] == a1[i]) {
                result[i] = 'g';
                used[i] = true;
            }
        }

        for (int i = 0; i < 5; i++) {
            if (result[i] == 'g') continue;
            for (int j = 0; j < 5; j++) {
                if (!used[j] && b1[i] == a1[j]) {
                    result[i] = 'y';
                    used[j] = true;
                    break;
                }
            }
        }

        return result;
    }
    void solve(vector<string> words);
    vector<string> words;
    bool stop = 0;
};

string query(string b) {
    if (gr::queries == 6 || b.size() != 5) return "";
    bool is = 0;
    for(auto x : gr::words) {
        is |= x==b;
        if(is) break;
    }
    if(!is) {gr::stop = 1; return "";}
    gr::queries++;

    string result(5, 'b');
    vector<bool> used(5, 0);

    for (int i = 0; i < 5; i++) {
        if (b[i] == gr::a[i]) {
            result[i] = 'g';
            used[i] = true;
        }
    }

    for (int i = 0; i < 5; i++) {
        if (result[i] == 'g') continue;
        for (int j = 0; j < 5; j++) {
            if (!used[j] && b[i] == gr::a[j]) {
                result[i] = 'y';
                used[j] = true;
                break;
            }
        }
    }
    if(result == "ggggg") gr::found = 1;
    return result;
}
void gr::solve(vector<string> words) { // author solution
    vector<string> possible = words, possible_old;
    for(int guess = 0; guess < 6; guess++) {
        if(possible.size()==1) {
            query(possible[0]);
            return;
        }
        double E_best = -1;
        string best = "";
        for(int i = 0; i < possible.size(); i++) { // fixate this word to be right
            unordered_map<string, int> cnt;
            for(int j = 0; j < possible.size(); j++) { // look at all other words
                cnt[localQuery(possible[i], possible[j])]++; // update the counter based on this word's pattern if we assume possible[i] is right
            }
            double E_current = 0; // current entropy
            // entropy = sum(p * log2(1/p)), p is the probability that pattern shows up
            for(pair<string,int> pattern : cnt) {
                double p = (double)pattern.second/(double)possible.size(); // possible.size() is the sum of the pattern counts
                E_current += p * log2(1.0 / p);
            }
            if(E_current > E_best) { // we want the word with best entropy as it gives us the most info
                E_best = E_current;
                best = possible[i];
            }
        }
        string res = query(best);
        if(res == "ggggg") return;
        possible_old = possible;
        possible.clear();
        for(auto &w : possible_old) { // delete words that can't be right
            if(localQuery(w, best)==res) {possible.push_back(w);}
        }
    }
}
int main() {
    int n;
    cin >> n;
    vector<string> words(n);
    for(int i = 0; i < n; i++) cin >> words[i];
    gr::words=words;
    cin >> gr::a;
    // run author solution to find x
    gr::solve(words);
    const double x = gr::queries;
    // reset
    gr::queries = 0;
    gr::found = 0;
    // run contestant solution
    solve(words);
    if(!gr::found) {
        cout << gr::password << " 0 Word not guessed correctly!" << endl;
        return 0;
    }
    if(gr::stop) {
        cout << gr::password << " 0 Query word not in list!" << endl;
        return 0;
    }
    cout << gr::password << " " << max(0.40, min(1.0, 1.0-(0.60*((double)gr::queries-x))/(6-x))) << " Used " << gr::queries << " guesses." << endl;
}
