#include <bits/stdc++.h>
#include "wordle.h"
using namespace std;

string getPattern(const string& guess, const string& target) {
    string res(5, 'b');
    vector<int> used(5, 0);

    for (int i = 0; i < 5; i++) {
        if (guess[i] == target[i]) {
            res[i] = 'g';
            used[i] = 1;
        }
    }

    for (int i = 0; i < 5; i++) {
        if (res[i] == 'g') continue;
        for (int j = 0; j < 5; j++) {
            if (!used[j] && guess[i] == target[j]) {
                res[i] = 'y';
                used[j] = 1;
                break;
            }
        }
    }
    return res;
}

string chooseNext(const vector<string>& candidates) {
    int sz = (candidates.size() > 10 ? candidates.size() / 2 : candidates.size());
    int idx = rand() % sz + (candidates.size() > 10 ? candidates.size() / 2 : 0);
    return candidates[idx];
}

void solve(vector<string> words) {
    random_shuffle(words.begin(), words.end());
    vector<string> candidates = words;

    for (int turn = 1; turn <= 6 && !candidates.empty(); turn++) {
        string guess = chooseNext(candidates);
        string res = query(guess);
        if (res == "ggggg") {
            return;
        }

        vector<string> new_candidates;
        for (auto& w : candidates) {
            if (getPattern(guess, w) == res)
                new_candidates.push_back(w);
        }
        candidates.swap(new_candidates);
    }
}
