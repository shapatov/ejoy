#include <iostream>
#include <vector>
#include <algorithm>
#include <unordered_map>
#include "wordle.h"
using namespace std;
string guessWhichIsNext(const string &a, const string &b) {
    string res(5, 'b');
    vector<int> cnt(26, 0);
    for (int i = 0; i < 5; i++) {
        if (a[i] != b[i]) {
            cnt[a[i] - 'a']++;
        }
    }
    for (int i = 0; i < 5; i++) {
        if (a[i] == b[i]) {
            res[i] = 'g';
        } else if (cnt[b[i] - 'a'] > 0) {
            res[i] = 'y';
            cnt[b[i] - 'a']--;
        }
    }
    return res;
}
string bestGuessIDK(const vector<string> &words) {
    int bestScore = 1000000000;
    string bestWord = words[0];
    for (auto &guess : words) {
        unordered_map<string, int> patternCount;
        for (auto &secret : words) {
            string p = guessWhichIsNext(secret, guess);
            patternCount[p]++;
        }
        int worstCase = 0;
        for (auto &pr : patternCount) {
            worstCase = max(worstCase, pr.second);
        }
        if (worstCase < bestScore) {
            bestScore = worstCase;
            bestWord = guess;
        }
    }
    return bestWord;
}
void solve(vector<string> words) {
    for (int step = 0; step < 6 && !words.empty(); step++) {
        string guess = bestGuessIDK(words);
        string ans = query(guess);
        if (ans == "ggggg" || ans == "") {
            return;
        }
        vector<string> next;
        for (auto &w : words) {
            if (guessWhichIsNext(w, guess) == ans) {
                next.push_back(w);
            }
        }
        words.swap(next);
    }
}
