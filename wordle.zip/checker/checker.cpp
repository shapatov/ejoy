/* the checker has three arguments:
    - first - name of the input file
    - second - name of the correct output file
    - third - name of the contestant output file */
#include<iostream>
#include<fstream>
using namespace std;

const string password = "0d97a8f1bc7e9ed10438a5065d8713aa8b3161fc20a6dfe71b61472df0becd91";

void output_message(double points, string message){
	cout << points << endl;
	cerr << message << endl;
	exit(0);
}

int main (int argc, char** argv) {
	if(argc < 4){ output_message(0, "Insufficient arguments!"); return 1; }
	fstream input(argv[1]), output(argv[2]), contestant(argv[3]);
	if(!input.is_open()){ output_message(0, "Couldn't open input file."); return 1; }
	if(!output.is_open()){ output_message(0, "Couldn't open output file."); return 1; }
	if(!contestant.is_open()){ output_message(0, "Couldn't open contestant file."); return 1; }
	string check;
	contestant >> check;
	if(check != password){ output_message(0, "Contestant wrote to cout."); return 1; }
	double res;
    contestant >> res;
    cout << res << endl;
    string message;
    while(contestant >> message) {
        cerr << message << " ";
    }
    cout << endl;
	exit(0);
	return 0;
}
