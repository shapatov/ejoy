#include "wordle.h"
#include <bits/stdc++.h>
using namespace std;
void solve(vector<string> words) {
    return;
}
