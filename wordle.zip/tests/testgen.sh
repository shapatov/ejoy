#!/bin/bash

# Path to the words.txt file
words_file="words.txt"

# Check if the words.txt file exists
if [ ! -f "$words_file" ]; then
    echo "Error: $words_file not found!"
    exit 1
fi

# Function to generate a random word from the file
get_random_word() {
    shuf -n 1 "$words_file"
}

# Loop to create files 8.in to 141.in and corresponding .out files
for i in {8..141}; do
    # Generate a random number N between 1 and 6
    N=$((RANDOM % 1066 + 1))

    # Select N unique random words from the file
    words=($(shuf -n "$N" "$words_file"))

    # Select a random word from the selected words
    random_word=${words[$((RANDOM % N))]}

    # Write to the .in file
    {
        echo "$N"
        echo "${words[*]}"
        echo "$random_word"
    } > "$i.in"

    # Create an empty .out file
    touch "$i.out"
done

echo "Files 8.in to 141.in and corresponding .out files have been created."
