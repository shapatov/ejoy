#include "wordle.h"
#include <bits/stdc++.h>
using namespace std;
string localQuery(string a, string b) {
    string result(5, 'b');
    vector<bool> used(5, 0);

    for (int i = 0; i < 5; i++) {
        if (b[i] == a[i]) {
            result[i] = 'g';
            used[i] = true;
        }
    }

    for (int i = 0; i < 5; i++) {
        if (result[i] == 'g') continue;
        for (int j = 0; j < 5; j++) {
            if (!used[j] && b[i] == a[j]) {
                result[i] = 'y';
                used[j] = true;
                break;
            }
        }
    }

    return result;
}
void solve(vector<string> words) {
    int queries = 0;
    vector<string> possible = words, possible_old;
    while(possible.size() && queries < 6) {
        string guess = possible[0];
        string fb = query(guess);
        if(fb=="ggggg") return;
        possible_old = possible;
        possible.clear();
        for(auto &w : possible_old) {
            if(localQuery(w, guess)==fb) {possible.push_back(w);}
        }
    }
}