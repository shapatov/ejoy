#include "wordle.h"
#include <bits/stdc++.h>
using namespace std;
string localQuery(string a, string b) {
    string result(5, 'b');
    vector<bool> used(5, 0);

    for (int i = 0; i < 5; i++) {
        if (b[i] == a[i]) {
            result[i] = 'g';
            used[i] = true;
        }
    }

    for (int i = 0; i < 5; i++) {
        if (result[i] == 'g') continue;
        for (int j = 0; j < 5; j++) {
            if (!used[j] && b[i] == a[j]) {
                result[i] = 'y';
                used[j] = true;
                break;
            }
        }
    }

    return result;
}
void solve(vector<string> words) {
    vector<string> possible = words, possible_old;
    for(int guess = 0; guess < 6; guess++) {
        if(possible.size()==1) {
            query(possible[0]);
            return;
        }
        double E_best = -1;
        string best = "";
        for(int i = 0; i < possible.size(); i++) { // fixate this word to be right
            unordered_map<string, int> cnt;
            for(int j = 0; j < possible.size(); j++) { // look at all other words
                cnt[localQuery(possible[i], possible[j])]++; // update the counter based on this word's pattern if we assume possible[i] is right
            }
            double E_current = 0; // current entropy
            // entropy = sum(p * log2(1/p)), p is the probability that pattern shows up
            for(pair<string,int> pattern : cnt) {
                double p = (double)pattern.second/(double)possible.size(); // possible.size() is the sum of the pattern counts
                E_current += p * sqrt(1.0 / p);
            }
            if(E_current > E_best) { // we want the word with best entropy as it gives us the most info
                E_best = E_current;
                best = possible[i];
            }
        }
        string res = query(best);
        if(res == "ggggg") return;
        possible_old = possible;
        possible.clear();
        for(auto &w : possible_old) { // delete words that can't be right
            if(localQuery(w, best)==res) {possible.push_back(w);}
        }
    }
}