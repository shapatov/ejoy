#include "wordle.h"
#include <bits/stdc++.h>
using namespace std;
void solve(vector<string> words) {
    for(auto x : words) {
        if(query(x)=="ggggg") return;
    }
}