#include <bits/stdc++.h>
#include "wordle.h"
using namespace std;



string feedback(const string &guess, const string &target) {
    string res(5, 'b');
    vector<int> freq(26, 0);
    for (char c : target) freq[c-'a']++;
    for (int i = 0; i < 5; i++) {
        if (guess[i] == target[i]) {
            res[i] = 'g';
            freq[guess[i]-'a']--;
        }
    }
    for (int i = 0; i < 5; i++) {
        if (res[i] == 'g') continue;
        if (freq[guess[i]-'a'] > 0) {
            res[i] = 'y';
            freq[guess[i]-'a']--;
        }
    }
    return res;
}

string bestGuess(const vector<string> &words) {
    int bestScore = -1;
    string best = words[0];
    for (auto &w : words) {
        unordered_set<string> patterns;
        for (auto &c : words) {
            if (c == w) continue;
            patterns.insert(feedback(w, c));
        }
        if ((int)patterns.size() > bestScore) {
            bestScore = patterns.size();
            best = w;
        }
    }
    return best;
}

void solve(vector<string> words) {
    vector<string> candidates = words;
    for (int attempt = 0; attempt < 6 && !candidates.empty(); attempt++) {
        string guess = bestGuess(candidates);
        string res = query(guess);
        if (res == "ggggg") return;
        vector<string> next;
        for (auto &w : candidates) {
            if (feedback(guess, w) == res) next.push_back(w);
        }
        candidates = next;
    }
}